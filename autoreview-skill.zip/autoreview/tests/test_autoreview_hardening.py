#!/usr/bin/env python3
from __future__ import annotations

import argparse
import base64
import contextlib
import hashlib
import copy
import io
import itertools
import json
import os
import re
import runpy
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import urllib.parse
from unittest import mock
from pathlib import Path, PureWindowsPath

try:
    import tomllib
except ModuleNotFoundError:
    import tomli as tomllib


SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "autoreview"
fixture_git = runpy.run_path(str(SCRIPT.with_name("test-review-harness.py")))["fixture_git"]
FIXTURES = Path(__file__).with_name("fixtures")
PRIVATE_KEY_BEGIN_TEXT = "BEGIN " + "PRIVATE KEY"
RSA_PRIVATE_KEY_BEGIN_TEXT = "BEGIN RSA " + "PRIVATE KEY"


def write_executable(path: Path, text: str) -> Path:
    path.write_text(text, encoding="utf-8")
    path.chmod(0o755)
    if os.name != "nt":
        return path
    wrapper = path.with_name(f"{path.name}.cmd")
    wrapper.write_text(f'@echo off\r\n"{sys.executable}" "{path}" %*\r\n', encoding="utf-8")
    return wrapper


def fake_codex_script() -> str:
    return r'''#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys

args = sys.argv[1:]
if invocations := os.environ.get("AUTOREVIEW_FAKE_CODEX_INVOCATIONS"):
    selected_env = {
        key: os.environ.get(key)
        for key in (
            "HOME",
            "USERPROFILE",
            "XDG_CACHE_HOME",
            "XDG_CONFIG_HOME",
            "XDG_DATA_HOME",
            "XDG_STATE_HOME",
            "CODEX_HOME",
            "PATH",
        )
    }
    with open(invocations, "a", encoding="utf-8") as file:
        file.write(json.dumps({"argv": args, "cwd": os.getcwd(), "env": selected_env}) + "\n")
if "--version" in args or "-v" in args:
    print("codex-cli 0.0.0-test")
    raise SystemExit(0)
record = os.environ["AUTOREVIEW_FAKE_RECORD"]
Path(record).write_text(json.dumps({"argv": args, "cwd": os.getcwd(), "stdin": sys.stdin.read()}))
if mutation := os.environ.get("AUTOREVIEW_FAKE_MUTATE"):
    Path(mutation).write_text("mutated during review\n")
try:
    output_path = args[args.index("--output-last-message") + 1]
except ValueError:
    output_path = args[args.index("-o") + 1]
report = {
    "findings": [],
    "overall_correctness": "patch is correct",
    "overall_explanation": "fake codex clean",
    "overall_confidence": 0.99,
    "review_completion": "complete",
}
Path(output_path).write_text(json.dumps(report))
print("fake codex ok")
'''


def fake_claude_script() -> str:
    return r'''#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys

args = sys.argv[1:]
if "--version" in args or "-v" in args:
    print(os.environ.get("AUTOREVIEW_FAKE_CLAUDE_VERSION", "2.1.170 (Claude Code)"))
    raise SystemExit(0)
if "--help" in args or "-h" in args:
    print("--safe-mode\n--setting-sources\n--strict-mcp-config\n--disallowedTools\n--tools\n--print\n--json-schema")
    raise SystemExit(0)
record = os.environ["AUTOREVIEW_FAKE_RECORD"]
Path(record).write_text(json.dumps({
    "argv": args,
    "cwd": os.getcwd(),
    "stdin": sys.stdin.read(),
    "auto_memory_disabled": os.environ.get("CLAUDE_CODE_DISABLE_AUTO_MEMORY"),
}))
report = {
    "findings": [],
    "overall_correctness": "patch is correct",
    "overall_explanation": "fake claude clean",
    "overall_confidence": 0.99,
    "review_completion": "complete",
}
print(json.dumps(report))
'''


def fake_pi_script() -> str:
    return r'''#!/usr/bin/env python3
import json
import os
from pathlib import Path
import sys

args = sys.argv[1:]
invocations = os.environ.get("AUTOREVIEW_FAKE_PI_INVOCATIONS")
if invocations:
    with open(invocations, "a", encoding="utf-8") as file:
        file.write(json.dumps({"argv": args, "cwd": os.getcwd()}) + "\n")
if "--version" in args or "-v" in args:
    print(os.environ.get("AUTOREVIEW_FAKE_PI_VERSION", "0.79.0"))
    raise SystemExit(0)
if "--help" in args or "-h" in args:
    print(os.environ.get("AUTOREVIEW_FAKE_PI_HELP", "--print\n--no-approve\n--no-session\n--no-context-files\n--no-extensions\n--no-skills\n--no-prompt-templates\n--no-themes\n--tools\n--no-tools\n--thinking"))
    raise SystemExit(0)
record = os.environ["AUTOREVIEW_FAKE_RECORD"]
Path(record).write_text(json.dumps({"argv": args, "cwd": os.getcwd(), "stdin": sys.stdin.read()}))
report = {
    "findings": [],
    "overall_correctness": "patch is correct",
    "overall_explanation": "fake pi clean",
    "overall_confidence": 0.99,
    "review_completion": "complete",
}
print(json.dumps(report))
	'''


def load_helper() -> dict[str, object]:
    return runpy.run_path(str(SCRIPT), run_name="autoreview_under_test")


@contextlib.contextmanager
def deadline_after_reviewer_ready(helper, ready: Path):
    deadline_type = helper["EngineRuntimeDeadline"]

    class ReadyDeadline(deadline_type):
        def __init__(self, label, seconds):
            super().__init__(label, seconds)
            self.expires_at = time.monotonic() + 5
            self.ready_seen = False

        def expired(self):
            if not self.ready_seen and ready.exists():
                self.ready_seen = True
                self.expires_at = time.monotonic() + self.max_runtime_seconds
            return super().expired()

    # These fixtures test termination/draining after startup. The separate
    # silent-reviewer case covers an unconditional deadline from process launch.
    with mock.patch.dict(
        helper["run_with_heartbeat"].__globals__, {"EngineRuntimeDeadline": ReadyDeadline}
    ):
        yield


def git(repo: Path, *args: str) -> str:
    result = fixture_git(
        repo, *args,
        check=True,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    return result.stdout


def init_repo(tempdir: Path) -> Path:
    repo = tempdir / "repo"
    repo.mkdir()
    git(repo, "init", "-q")
    git(repo, "config", "user.name", "Autoreview Test")
    git(repo, "config", "user.email", "autoreview@example.invalid")
    return repo


def posix_process_is_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    result = subprocess.run(
        ["ps", "-o", "stat=", "-p", str(pid)],
        text=True,
        capture_output=True,
        check=False,
    )
    state = result.stdout.strip()
    return result.returncode == 0 and bool(state) and not state.startswith("Z")


def installed_java() -> str | None:
    java = shutil.which("java")
    if java is None:
        return None
    try:
        probe = subprocess.run(
            [java, "-version"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            check=False,
        )
    except OSError:
        return None
    return java if probe.returncode == 0 else None


class AutoreviewMixedTargetTests(unittest.TestCase):
    def setUp(self):
        self.helper = load_helper()

    @contextlib.contextmanager
    def migration(self, *, scan_sentinel=False):
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            git(repo, "config", "core.autocrlf", "false")
            base, index, working = {}, {}, {}
            call = 0
            for number, count in enumerate((3, 3, 3, 2, 2)):
                path = f"src/migrate-{number}.py"
                padding = "padding = 'context'\n"
                before, staged, final = [], [], []
                for _ in range(count):
                    before.append(f"original({call})\n" + padding * 8)
                    staged.append(f"obsolete({call})\n" + padding * 8)
                    final.append(f"corrected({call})\n" + padding * 8)
                    call += 1
                base[path], index[path], working[path] = map("".join, (before, staged, final))
                if scan_sentinel:
                    tail = "context\n" * 20 + "SOURCE_ONLY_SCAN_SENTINEL\nMULTILINE_SCAN_CONTINUATION\n"
                    base[path] += tail
                    index[path] += tail
                    working[path] += tail
                source = repo / path
                source.parent.mkdir(exist_ok=True)
                source.write_bytes(base[path].encode())
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "synthetic migration base")
            for path, content in index.items():
                (repo / path).write_bytes(content.encode())
            git(repo, "add", ".")
            for path, content in working.items():
                (repo / path).write_bytes(content.encode())
            yield repo, base, index, working

    def test_capture_pins_versions_and_keeps_thirteen_calls_and_original_transitions(self):
        with self.migration() as (repo, base, index, working):
            pinned = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "branch", "review-base")
            captured = self.helper["local_bundle"](repo, "review-base")
            self.assertEqual(captured.paths, set(base))
            self.assertEqual(len(captured.mixed), 5)
            self.assertIn(f"base: {pinned}", captured.text)
            self.assertEqual(sum(record.index.content.count("obsolete(") for record in captured.mixed), 13)
            for record in captured.mixed:
                self.assertEqual(record.base.content, base[record.path])
                self.assertEqual(record.index.content, index[record.path])
                self.assertEqual(record.working_tree.content, working[record.path])
                self.assertNotEqual(record.index.identity, record.working_tree.identity)
                self.assertEqual(record.staged, self.helper["git_bytes"](
                    repo, "diff", *self.helper["SAFE_DIFF_FLAGS"], "--cached", pinned, "--", record.path,
                ).stdout.decode())
                self.assertEqual(record.unstaged, self.helper["git_bytes"](
                    repo, "diff", *self.helper["SAFE_DIFF_FLAGS"], "--", record.path,
                ).stdout.decode())
                with self.assertRaises(AttributeError):
                    record.identity = "changed"
            for span in captured.spans:
                record = next(record for record in captured.mixed if record.path == span.path)
                expected = record.staged if span.target == "index" else record.unstaged
                self.assertEqual(captured.text.encode()[span.start:span.end], expected.encode())

    def test_partial_document_staging_survives_an_omitted_sibling_type_change(self):
        for directory, staged, reverse, sibling_name in itertools.product(
            ("docs/flows/credential-source-egress", "docs/reference/credential-sources",
             "specs/rfcs/0023-egress-proxy-credential-lifecycle"),
            (False, True), (False, True), ("a-sibling.md", "z-sibling.md"),
        ):
            if os.name == "nt" and not staged:
                continue  # Working-tree type changes require native symlinks.
            with self.subTest(directory=directory, staged=staged, reverse=reverse, sibling=sibling_name), \
                    tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                git(repo, "config", "core.autocrlf", "false")
                if os.name == "nt":
                    git(repo, "config", "core.symlinks", "false")
                doc_path = f"{directory}/guide.md"
                sibling_path = f"{directory}/{sibling_name}"
                doc = repo / doc_path
                doc.parent.mkdir(parents=True)
                doc.write_bytes(b"base document\n")
                (repo / "allowed.py").write_bytes(b"base source\n")
                (repo / ".env").write_bytes(b"PRIVATE_BASE_SENTINEL\n")
                git(repo, "add", ".")

                def select_sibling(link):
                    # Real index modes work on Windows without symlink privilege.
                    payload = repo.parent / "payload"
                    payload.write_bytes(b"PRIVATE_LINK_SENTINEL" if link else b"OMITTED_TEXT_SENTINEL\n")
                    oid = git(repo, "hash-object", "-w", str(payload)).strip()
                    mode = "120000" if link else "100644"
                    git(repo, "update-index", "--add", "--cacheinfo", f"{mode},{oid},{sibling_path}")
                    git(repo, "checkout-index", "--force", "--", sibling_path)

                select_sibling(reverse)
                git(repo, "commit", "-qm", "baseline")
                if staged:
                    select_sibling(not reverse)
                else:
                    sibling = repo / sibling_path
                    sibling.unlink()
                    if reverse:
                        sibling.write_bytes(b"OMITTED_TEXT_SENTINEL\n")
                    else:
                        sibling.symlink_to("PRIVATE_LINK_SENTINEL")
                # Both versions of the document must retain exact source attribution,
                # even when the omitted transition occupies two adjacent patch sections.
                doc.write_bytes("staged document 界\n".encode())
                (repo / "allowed.py").write_bytes(b"review this source\n")
                (repo / ".env").write_bytes(b"PRIVATE_NEW_SENTINEL\n")
                git(repo, "add", doc_path, "allowed.py", ".env")
                doc.write_bytes("working document 界\n".encode())

                captured = self.helper["local_bundle"](repo)
                self.assertEqual(captured.paths, {doc_path, "allowed.py"})
                self.assertIn("+review this source", captured.text)
                for omitted in (sibling_name, "PRIVATE_LINK_SENTINEL", "OMITTED_TEXT_SENTINEL",
                                "PRIVATE_BASE_SENTINEL", "PRIVATE_NEW_SENTINEL"):
                    self.assertNotIn(omitted, captured.text)
                record, = captured.mixed
                self.assertEqual(record.path, doc_path)
                self.assertEqual(record.index.content, "staged document 界\n")
                self.assertEqual(record.working_tree.content, "working document 界\n")
                self.assertEqual({span.target for span in captured.spans}, {"index", "working_tree"})
                for span in captured.spans:
                    self.assertEqual(span.path, doc_path)
                    expected = record.staged if span.target == "index" else record.unstaged
                    self.assertEqual(captured.text.encode()[span.start:span.end], expected.encode())
                self.helper["verify_mixed_sources"](repo, captured.mixed)

    def test_mixed_full_dataset_preference_rebatches_before_tiny_change_splits(self):
        budget, minimum = 512_000, 32_000
        render = self.helper["render_review_prompt"]
        split = self.helper["split_review_bundle"]
        dataset = self.helper["ReviewDataset"]
        render_data = self.helper["render_datasets"]
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = repo / "source.py"
            source.write_text("baseline()\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "synthetic base")
            source.write_text("indexed = '" + "x" * 60_000 + "'\n")
            git(repo, "add", ".")
            source.write_text("working = '" + "y" * 60_000 + "'\n")
            captured = self.helper["local_bundle"](repo)
            record, span = captured.mixed[0], captured.spans[0]
            template = self.helper["ReviewChunk"]("", "", span.start, (record,), ((span.path, span.target),))
            first_change = captured.text.encode()[span.start:span.end].decode()
            branch = self.helper["current_branch"](repo)
            overhead = len(render(branch, "local", None, template, "",
                                  render_data([dataset("owner.py", "")]), (999_999, 999_999)).encode())
            for capacity in (4, minimum + 64):
                with self.subTest(capacity=capacity):
                    datasets = [dataset("owner.py", "e" * (budget - overhead - capacity))]
                    complete = render_data(datasets)
                    preferred, split_limits = False, []

                    def observe_render(*args, **kwargs):
                        nonlocal preferred
                        preferred = args[5] == complete
                        return render(*args, **kwargs)

                    def bounded_split(text, limit):
                        if preferred:
                            self.assertGreaterEqual(limit, minimum, "rebatch before allocating tiny speculative chunks")
                            if text == first_change:
                                split_limits.append(limit)
                        return split(text, limit)

                    optimize = self.helper["optimize_evidence_plan"]

                    def probe_full_batch(baseline, available, change_bytes, evidence, build):
                        # Exercise the optimizer's one-batch retry, including a
                        # continuation correction that reduces change capacity.
                        self.assertIsNone(build(len(complete.encode()) + 128, len(baseline)))
                        return optimize(baseline, available, change_bytes, evidence, build)

                    with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                        "render_review_prompt": observe_render, "split_review_bundle": bounded_split,
                        "optimize_evidence_plan": probe_full_batch,
                    }):
                        passes = self.helper["build_review_prompts"](
                            repo, "local", None, captured, "", datasets, budget,
                        )
                    self.assertEqual(bool(split_limits), capacity != 4)
                    self.assertTrue(all(limit == capacity for limit in split_limits))
                    batches = {}
                    for item in passes:
                        self.assertLessEqual(len(item.prompt.encode()), budget)
                        batches.setdefault(item.evidence_batch, []).append(item.chunk.content)
                        for owner in item.chunk.sources:
                            self.assertEqual(owner, record)
                            self.assertIn(owner.identity, item.prompt)
                            for version in (owner.index, owner.working_tree):
                                self.assertIn(version.identity, item.prompt)
                                self.assertIn(version.content, item.prompt)
                    self.assertGreater(len(batches), 1)
                    for item in passes:
                        self.assertIn(f"Evidence batch: {item.evidence_batch}/{len(batches)}", item.prompt)
                    self.assertTrue(all("".join(changes) == captured.text for changes in batches.values()))

    def test_mixed_initial_fallback_rebatches_small_evidence_before_tiny_splits(self):
        budget, minimum = 512_000, 32_000
        build = self.helper["build_mixed_change_passes"]
        split = self.helper["split_review_bundle"]
        render = self.helper["render_review_prompt"]
        render_data = self.helper["render_datasets"]
        dataset = self.helper["ReviewDataset"]
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = repo / "source.py"
            source.write_text("baseline()\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "synthetic base")
            source.write_text("indexed = '" + "x" * 130_000 + "'\n")
            git(repo, "add", ".")
            source.write_text("working = '" + "y" * 130_000 + "'\n")
            captured = self.helper["local_bundle"](repo)
            record, span = captured.mixed[0], captured.spans[0]
            template = self.helper["ReviewChunk"]("", "", span.start, (record,), ((span.path, span.target),))
            branch = self.helper["current_branch"](repo)
            overhead = len(render(branch, "local", None, template, "",
                                  render_data([dataset("owner.py", "")]), (999_999, 999_999)).encode())
            evidence_bytes = budget - overhead - 1_024
            self.assertLess(evidence_bytes, budget // 2)
            datasets = [dataset("owner.py", "e" * evidence_bytes)]
            complete = render_data(datasets)
            whole, full_attempts = False, []

            def observe_build(*args, **kwargs):
                nonlocal whole
                whole = render_data(args[5]) == complete
                if whole:
                    full_attempts.append(kwargs.get("min_change_bytes", 4))
                return build(*args, **kwargs)

            def bounded_split(text, limit):
                if whole:
                    self.assertGreaterEqual(limit, minimum, "initial fallback must rebatch complete evidence")
                return split(text, limit)

            with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                "build_mixed_change_passes": observe_build, "split_review_bundle": bounded_split,
            }):
                passes = self.helper["build_review_prompts"](repo, "local", None, captured, "", datasets, budget)
            self.assertGreaterEqual(len(full_attempts), 2)
            self.assertTrue(all(value == minimum for value in full_attempts))
            batches = {}
            for item in passes:
                self.assertLessEqual(len(item.prompt.encode()), budget)
                batches.setdefault(item.evidence_batch, []).append(item.chunk.content)
                self.assertTrue(all(owner == record for owner in item.chunk.sources))
            self.assertGreater(len(batches), 1)
            self.assertTrue(all("".join(changes) == captured.text for changes in batches.values()))

    def test_one_byte_evidence_keeps_terminal_fallback_for_both_planners(self):
        budget, capacity = 512_000, 16_000
        render = self.helper["render_review_prompt"]
        render_data = self.helper["render_datasets"]
        split = self.helper["split_review_bundle"]
        split_data = self.helper["split_review_datasets"]
        datasets = [self.helper["ReviewDataset"]("owner.py", "x")]
        complete = render_data(datasets)
        terminal_limit = len(render_data([datasets[0]._replace(content="", byte_offset=1)]).encode()) + 4
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = repo / "source.py"
            source.write_text("baseline()\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "synthetic base")
            source.write_text("indexed = '" + "x" * 20_000 + "'\n")
            git(repo, "add", ".")
            source.write_text("working = '" + "y" * 20_000 + "'\n")
            captured = self.helper["local_bundle"](repo)
            branch = self.helper["current_branch"](repo)
            record, span = captured.mixed[0], captured.spans[0]
            for mixed in (False, True):
                with self.subTest(mixed=mixed):
                    target = "local" if mixed else "branch"
                    chunk = self.helper["ReviewChunk"]("", "", span.start, (record,), ((span.path, span.target),)) \
                        if mixed else self.helper["ReviewChunk"]("")
                    overhead = len(render(branch, target, None, chunk, "", complete, (999_999, 999_999)).encode())
                    instructions = "i" * (budget - overhead - capacity - (0 if mixed else 4_096))
                    builder_name = "build_mixed_change_passes" if mixed else "build_change_review_prompts"
                    build = self.helper[builder_name]
                    last_limit, active_minimum, low_splits = None, None, []

                    def observe_datasets(values, limit):
                        nonlocal last_limit
                        last_limit = limit
                        return split_data(values, limit)

                    def observe_build(*args, **kwargs):
                        nonlocal active_minimum
                        active_minimum = kwargs.get("min_change_bytes", 4)
                        return build(*args, **kwargs)

                    def bounded_split(text, limit):
                        if limit < 32_000:
                            self.assertEqual(active_minimum, 4)
                            self.assertEqual(last_limit, terminal_limit)
                            low_splits.append(limit)
                        return split(text, limit)

                    with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                        builder_name: observe_build, "split_review_bundle": bounded_split,
                        "split_review_datasets": observe_datasets,
                    }):
                        passes = self.helper["build_review_prompts"](
                            repo, target, None, captured if mixed else captured.text,
                            instructions, datasets, budget,
                        )
                    self.assertTrue(low_splits, "the terminal baseline must retain four-byte admission")
                    changes = []
                    for item in passes:
                        prompt = item.prompt if mixed else item
                        self.assertLessEqual(len(prompt.encode()), budget)
                        self.assertIn(complete, prompt)
                        changes.append(item.chunk.content if mixed else prompt.split("# Change Bundle\n", 1)[1])
                    self.assertEqual("".join(changes), captured.text)

    def test_mixed_terminal_single_batch_preserves_continuation_capacity(self):
        budget, capacity = 12_000, 320
        render = self.helper["render_review_prompt"]
        render_data = self.helper["render_datasets"]
        for evidence in ("x", "xxxxx"):
            with self.subTest(evidence_bytes=len(evidence)):
                datasets = [self.helper["ReviewDataset"]("owner.py", evidence)]
                complete = render_data(datasets)
                with tempfile.TemporaryDirectory() as tempdir:
                    repo = init_repo(Path(tempdir))
                    source = repo / "source.py"
                    source.write_text("baseline()\n")
                    git(repo, "add", ".")
                    git(repo, "commit", "-qm", "synthetic base")
                    source.write_text("indexed = '" + "x" * 200 + "'\n")
                    git(repo, "add", ".")
                    source.write_text("working = '" + "y" * 200 + "'\n")
                    captured = self.helper["local_bundle"](repo)
                    branch = self.helper["current_branch"](repo)
                    record = captured.mixed[0]
                    overhead = max(len(render(branch, "local", None, self.helper["ReviewChunk"](
                        "", "", span.start, (record,), ((span.path, span.target),),
                    ), "", complete, (999_999, 999_999)).encode()) for span in captured.spans)
                    instructions = "i" * (budget - overhead - capacity)
                    direct = self.helper["build_mixed_change_passes"](
                        branch, "local", None, captured, instructions, datasets, budget,
                    )
                    self.assertTrue(any(item.chunk.context for item in direct))
                    self.assertEqual("".join(item.chunk.content for item in direct), captured.text)
                    passes = self.helper["build_review_prompts"](
                        repo, "local", None, captured, instructions, datasets, budget,
                    )
                    self.assertEqual("".join(item.chunk.content for item in passes), captured.text)
                    self.assertEqual(len(passes), len(direct))
                    for item in passes:
                        self.assertLessEqual(len(item.prompt.encode()), budget)
                        self.assertNotIn("Evidence batch:", item.prompt)
                        self.assertEqual(item.evidence_batch, 1)
                        self.assertEqual(item.datasets, tuple(datasets))
                        self.assertIn(complete, item.prompt)
                        self.assertTrue(all(owner == record for owner in item.chunk.sources))

    def test_ordinary_tiny_evidence_survives_terminal_batch_capacity_refusal(self):
        budget = 12_000
        bundle = "diff --git a/source.py b/source.py\n--- a/source.py\n+++ b/source.py\n@@ -0,0 +1 @@\n+" + "x" * 6_000 + "\n"
        render = self.helper["render_review_prompt"]
        render_data = self.helper["render_datasets"]
        build = self.helper["build_change_review_prompts"]
        split_data = self.helper["split_review_datasets"]
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            branch = self.helper["current_branch"](repo)
            for path, capacity, terminal_batch in (
                ("owner.py", 320, False),
                ("context/" * 87 + "owner.py", 200, True),
            ):
                with self.subTest(path_bytes=len(path), capacity=capacity):
                    datasets = [self.helper["ReviewDataset"](path, "xxxxx")]
                    complete = render_data(datasets)
                    overhead = len(render(
                        branch, "branch", None, self.helper["ReviewChunk"](""),
                        "", complete, (999_999, 999_999),
                    ).encode())
                    instructions = "i" * (budget - overhead - capacity - 4_096)
                    direct = build(branch, "branch", None, bundle, instructions, complete, budget)
                    self.assertIsNotNone(direct)
                    attempts = []

                    def observe_batches(values, limit):
                        batches = split_data(values, limit)
                        attempts.append((limit, [len(item.content.encode()) for batch in batches for item in batch]))
                        return batches

                    with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                        "split_review_datasets": observe_batches,
                    }):
                        prompts = self.helper["build_review_prompts"](
                            repo, "branch", None, bundle, instructions, datasets, budget,
                        )
                    self.assertEqual(bool(attempts), terminal_batch)
                    if terminal_batch:
                        minimum = len(render_data([datasets[0]._replace(content="", byte_offset=5)]).encode()) + 4
                        self.assertEqual(attempts[-1], (minimum, [4, 1]))
                    self.assertEqual(prompts, direct)
                    self.assertEqual("".join(prompt.split("# Change Bundle\n", 1)[1] for prompt in prompts), bundle)
                    for prompt in prompts:
                        self.assertLessEqual(len(prompt.encode()), budget)
                        self.assertIn(complete, prompt)
                        self.assertNotIn("Evidence batch:", prompt)
                    empty_prompt = render(branch, "branch", None, self.helper["ReviewChunk"](""), "", "")
                    impossible = "i" * (budget - len(empty_prompt.encode()))
                    self.assertEqual(len(render(
                        branch, "branch", None, self.helper["ReviewChunk"](""), impossible, "",
                    ).encode()), budget)
                    self.assertIsNone(build(branch, "branch", None, bundle, impossible, complete, budget))
                    with self.assertRaisesRegex(SystemExit, "intact context leave too little room"):
                        self.helper["build_review_prompts"](
                            repo, "branch", None, bundle, impossible, datasets, budget,
                        )

    def test_zero_reserve_stops_sizing_at_first_oversized_prompt(self):
        budget, branch = 12_000, "synthetic-capacity"
        bundle = "# Branch Diff\ndiff --git a/source.py b/source.py\n@@ -0,0 +1 @@\n+" + "x" * 8_000
        render = self.helper["render_review_prompt"]
        fixed = render(branch, "branch", None, self.helper["ReviewChunk"](""), "", "", (999_999, 999_999))
        instructions = "i" * (budget - len(fixed.encode()) - 4)
        measured = []

        def observe(*args):
            prompt = render(*args)
            if len(args) == 7 and args[6] != (999_999, 999_999) and args[3].content:
                measured.append(len(prompt.encode()))
                self.assertLessEqual(len(measured), 2, "continued rendering after the first oversized prompt")
            return prompt

        with mock.patch.dict(self.helper["build_change_review_prompts"].__globals__, {
            "render_review_prompt": observe,
        }):
            result = self.helper["build_change_review_prompts"](
                branch, "branch", None, bundle, instructions, "", budget, continuation_reserve=0,
            )
        self.assertIsNone(result)
        self.assertEqual(len(measured), 2)
        self.assertLessEqual(measured[0], budget)
        self.assertGreater(measured[1], budget)

    def test_mixed_complete_spans_keep_datasets_below_preferred_split_capacity(self):
        budget = 512_000
        render = self.helper["render_review_prompt"]
        render_data = self.helper["render_datasets"]
        dataset = self.helper["ReviewDataset"]
        with self.migration() as (repo, *_):
            captured = self.helper["local_bundle"](repo)
            records = {record.path: record for record in captured.mixed}
            branch = self.helper["current_branch"](repo)
            overhead = max(len(render(branch, "local", None, self.helper["ReviewChunk"](
                "", "", span.start, (records[span.path],), ((span.path, span.target),),
            ), "", render_data([dataset("owner.py", "")]), (999_999, 999_999)).encode())
                for span in captured.spans)
            capacity = max(span.end - span.start for span in captured.spans) + 256
            self.assertLess(capacity, 32_000)
            datasets = [dataset("owner.py", "e" * (budget - overhead - capacity))]
            complete = render_data(datasets)
            full = render(branch, "local", None, self.helper["mixed_bundle_chunk"](captured), "", complete)
            self.assertGreater(len(full.encode()), budget)
            passes = self.helper["build_review_prompts"](repo, "local", None, captured, "", datasets, budget)
            self.assertGreater(len(passes), 1)
            self.assertTrue("".join(item.chunk.content for item in passes) == captured.text,
                            "complete spans must not be repeated across evidence batches")
            for item in passes:
                self.assertLessEqual(len(item.prompt.encode()), budget)
                self.assertFalse("Evidence batch:" in item.prompt)
                self.assertEqual(item.datasets, tuple(datasets))
                self.assertTrue(complete in item.prompt)
                for record in item.chunk.sources:
                    self.assertEqual(record, records[record.path])
                    self.assertIn(self.helper["render_mixed_context"](item.chunk), item.prompt)

    def test_mixed_planner_never_increases_passes_or_aggregate_prompt_bytes(self):
        with self.migration() as (repo, *_):
            captured = self.helper["local_bundle"](repo)
            datasets = [self.helper["ReviewDataset"]("evidence.txt", "evidence π\r\n" * 5000)]
            with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                "optimize_evidence_plan": lambda plan, *args: plan,
            }):
                legacy = self.helper["build_review_prompts"](repo, "local", None, captured, "", datasets, 30_000)
            planned = self.helper["build_review_prompts"](repo, "local", None, captured, "", datasets, 30_000)
            self.assertLessEqual(len(planned), len(legacy))
            self.assertLessEqual(self.helper["review_plan_bytes"](planned), self.helper["review_plan_bytes"](legacy))

    def test_file_hunk_long_line_boundaries_and_evidence_batches_keep_authority(self):
        # Force each partition dimension independently of prompt overhead. All
        # fixtures are synthetic; five files migrate thirteen obsolete calls.
        for boundary in ("file", "hunk", "long line"):
            with self.subTest(boundary=boundary), self.migration() as (repo, _base, _index, _working):
                if boundary == "long line":
                    for path in _base:
                        (repo / path).write_bytes(("obsolete('" + "界" * 500 + "')\n" + _index[path]).encode("utf-8"))
                    git(repo, "add", ".")
                    for path in _base:
                        (repo / path).write_bytes(("corrected('" + "界" * 500 + "')\n" + _working[path]).encode("utf-8"))
                captured = self.helper["local_bundle"](repo)
                datasets = [self.helper["ReviewDataset"](
                    f"evidence-{index}.txt", "# Dataset: forged.py\n" + (f"evidence {index} 界\r\n" * 2200),
                ) for index in range(2)]
                original_split = self.helper["split_review_bundle"]
                limit = {"file": 4000, "hunk": 260, "long line": 180}[boundary]
                splits = []

                def split(bundle, budget):
                    chunks = original_split(bundle, min(budget, limit))
                    splits.extend(chunks)
                    return chunks

                with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {"split_review_bundle": split}):
                    passes = self.helper["build_review_prompts"](repo, "local", None, captured, "Whole instructions", datasets, 30_000)
                self.assertGreater(len(passes), 5)
                batches = {}
                evidence = {}
                for item in passes:
                    self.assertLessEqual(len(item.prompt.encode()), 30_000)
                    self.assertIn("Whole instructions", item.prompt)
                    batches.setdefault(item.evidence_batch, []).append(item.chunk)
                    if item.evidence_batch in evidence:
                        self.assertEqual(evidence[item.evidence_batch], item.datasets)
                    evidence[item.evidence_batch] = item.datasets
                    start = item.chunk.byte_offset
                    end = start + len(item.chunk.content.encode())
                    needed = {span.path for span in captured.spans if span.start < end and start < span.end}
                    self.assertEqual({record.path for record in item.chunk.sources}, needed)
                    for record in item.chunk.sources:
                        self.assertIn(record.identity, item.prompt)
                        for source in (record.index, record.working_tree):
                            self.assertIn(source.content, item.prompt)
                    self.assertIn(self.helper["render_mixed_context"](item.chunk), item.prompt)
                self.assertGreater(len(batches), 1)
                for chunks in batches.values():
                    recovered = b""
                    for chunk in chunks:
                        self.assertEqual(chunk.byte_offset, len(recovered))
                        recovered += chunk.content.encode()
                    self.assertEqual(recovered, captured.text.encode())
                recovered_evidence = {dataset.path: b"" for dataset in datasets}
                for batch in evidence.values():
                    for dataset in batch:
                        self.assertEqual(dataset.byte_offset, len(recovered_evidence[dataset.path]))
                        recovered_evidence[dataset.path] += dataset.content.encode()
                self.assertEqual(recovered_evidence, {dataset.path: dataset.content.encode() for dataset in datasets})
                if boundary == "long line":
                    self.assertTrue(any("original marker is" in chunk.context for chunk in splits))
                if boundary == "hunk":
                    self.assertTrue(any("Continuation" in chunk.context for chunk in splits))

    def test_staged_undone_add_remove_readd_and_modes(self):
        for state in ("undone", "new", "removed", "readd", "unborn", "literal"):
            if state == "literal" and os.name == "nt":
                continue  # Windows filenames cannot contain a colon.
            with self.subTest(state=state), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                path = repo / (":source.py" if state == "literal" else "source.py")
                if state == "literal":
                    (repo / "source.py").write_bytes(b"unrelated base\n")
                # These versions must be byte-identical even with Windows text translation.
                if state != "unborn":
                    if state != "new":
                        path.write_bytes(b"base()\n")
                    git(repo, "add", ".")
                    git(repo, "commit", "--allow-empty", "-qm", "base")
                if state == "readd":
                    git(repo, "rm", "source.py")
                else:
                    path.write_bytes(b"base()\nstaged()\n" if state == "literal" else b"staged()\n")
                    git(repo, "add", ".")
                if state == "removed":
                    path.unlink()
                elif state == "literal":
                    path.write_bytes(b"base()\nstaged()\nworking()\n")
                else:
                    path.write_bytes(b"base()\n" if state == "undone" else b"working()\n")
                captured = self.helper["local_bundle"](repo)
                record, = captured.mixed
                self.assertEqual(captured.paths, {path.name})
                self.assertEqual(record.index.mode is None, state == "readd")
                self.assertEqual(record.base.mode is None, state in ("new", "unborn"))
                self.assertEqual(record.working_tree.mode is None, state == "removed")
                self.assertEqual(bool(record.working_tree_removed), state not in ("readd", "literal"))
                if state == "literal":
                    base_oid = git(repo, "rev-parse", f"HEAD:{path.name}").strip()
                    self.assertEqual(record.base.identity, f"git:{base_oid}:100644")
                    self.assertEqual(record.index.content, "base()\nstaged()\n")
                    self.assertEqual(record.working_tree.content, "base()\nstaged()\nworking()\n")
                    self.assertNotIn("unrelated base", captured.text)
                if state == "readd":
                    self.assertIn("# Untracked File", record.unstaged)
                    self.assertEqual(record.index_removed, ((1, "base()"),))
                if state == "undone":
                    self.assertEqual(record.base.content, record.working_tree.content)
                self.helper["verify_mixed_sources"](repo, captured.mixed)

    def test_file_to_directory_transitions_keep_staged_and_working_sources(self):
        for state in ("staged", "untracked", "mixed-child", "mixed-parent", "committed",
                      "restored-parent", "restored-parent-siblings"):
            with self.subTest(state=state), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                git(repo, "config", "core.autocrlf", "false")
                path = repo / "foo"
                path.write_bytes(b"base parent\n")
                git(repo, "add", "foo")
                git(repo, "commit", "-qm", "base file")
                base = git(repo, "rev-parse", "HEAD").strip()
                if state == "mixed-parent":
                    path.write_bytes(b"staged parent\n")
                    git(repo, "add", "foo")
                    path.unlink()
                else:
                    git(repo, "rm", "foo")
                path.mkdir()
                child = path / "bar"
                child.write_bytes(b"staged child\n")
                restored = state in ("restored-parent", "restored-parent-siblings")
                children = {"foo/bar": "staged child\n"}
                if state == "restored-parent-siblings":
                    (path / "baz").write_bytes(b"staged sibling\n")
                    children["foo/baz"] = "staged sibling\n"
                if state in ("staged", "mixed-child", "committed") or restored:
                    git(repo, "add", "foo")
                if state == "committed":
                    git(repo, "commit", "-qm", "replace file with directory")
                if state in ("mixed-child", "committed"):
                    child.write_bytes(b"working child\n")
                if state == "mixed-child":
                    (path / "extra").write_bytes(b"untracked child\n")
                    (path / "ignored.txt").write_bytes(b"ignored child content\n")
                    (repo / ".git/info/exclude").write_text("foo/ignored.txt\n", encoding="utf-8")
                if restored:
                    for rel in children:
                        (repo / rel).unlink()
                    path.rmdir()
                    path.write_bytes(b"working parent\n")
                for ref in (None, base):
                    with self.subTest(base=ref):
                        snapshot = self.helper["source_tree_snapshot"](repo)
                        captured = self.helper["local_bundle"](repo, ref)
                        expected = set(children)
                        if state != "committed" or ref is not None:
                            expected.add("foo")
                            self.assertIn("-base parent\n", captured.text)
                        if state == "mixed-child":
                            expected.add("foo/extra")
                            self.assertIn("untracked child", captured.text)
                            self.assertNotIn("ignored child content", captured.text)
                        self.assertEqual(captured.paths, expected)
                        self.assertIn("staged child", captured.text)
                        mixed = {record.path: record for record in captured.mixed}
                        expected_mixed = set()
                        if restored:
                            expected_mixed = {"foo", *children}
                        elif state == "mixed-parent":
                            expected_mixed.add("foo")
                        elif state == "mixed-child" or (state == "committed" and ref is not None):
                            expected_mixed.add("foo/bar")
                        self.assertEqual(set(mixed), expected_mixed)
                        if "foo" in mixed:
                            self.assertEqual(mixed["foo"].base.content, "base parent\n")
                            self.assertEqual(mixed["foo"].index.content, None if restored else "staged parent\n")
                            self.assertEqual(mixed["foo"].working_tree.content, "working parent\n" if restored else None)
                            absent = mixed["foo"].index if restored else mixed["foo"].working_tree
                            self.assertEqual(absent, self.helper["SourceVersion"]("absent", None, None))
                        for rel in set(children) & set(mixed):
                            self.assertEqual(mixed[rel].index.content, children[rel])
                            self.assertEqual(mixed[rel].working_tree.content, None if restored else "working child\n")
                            if restored:
                                self.assertEqual(mixed[rel].working_tree, self.helper["SourceVersion"]("absent", None, None))
                        self.helper["verify_mixed_sources"](repo, captured.mixed)
                        self.assertEqual(self.helper["source_tree_snapshot"](repo), snapshot)

    def test_directory_to_file_transitions_preserve_snapshots_and_mixed_sources(self):
        for state in ("staged", "mixed-child", "mixed-parent", "working-directory"):
            with self.subTest(state=state), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                git(repo, "config", "core.autocrlf", "false")
                parent = repo / "foo"
                parent.mkdir()
                child = parent / "bar"
                child.write_bytes(b"base child\n")
                git(repo, "add", ".")
                git(repo, "commit", "-qm", "base directory")
                base = git(repo, "rev-parse", "HEAD").strip()
                if state == "mixed-child":
                    child.write_bytes(b"staged child\n")
                    git(repo, "add", "foo/bar")
                    child.unlink()
                else:
                    git(repo, "rm", "foo/bar")
                if parent.exists():
                    parent.rmdir()
                parent.write_bytes(b"working parent\n" if state == "mixed-child" else b"staged parent\n")
                if state != "mixed-child":
                    git(repo, "add", "foo")
                if state == "mixed-parent":
                    parent.write_bytes(b"working parent\n")
                elif state == "working-directory":
                    parent.unlink()
                    parent.mkdir()
                    child.write_bytes(b"working child\n")
                for ref in (None, base):
                    with self.subTest(base=ref):
                        snapshot = self.helper["source_tree_snapshot"](repo)
                        captured = self.helper["local_bundle"](repo, ref)
                        self.assertEqual(captured.paths, {"foo", "foo/bar"})
                        self.assertIn("working parent" if state == "mixed-child" else "staged parent", captured.text)
                        expected = {}
                        if state in ("mixed-child", "working-directory"):
                            expected["foo/bar"] = ("base child\n", "staged child\n", None) if state == "mixed-child" else (
                                "base child\n", None, "working child\n",
                            )
                        if state in ("mixed-parent", "working-directory"):
                            expected["foo"] = (None, "staged parent\n", "working parent\n" if state == "mixed-parent" else None)
                        self.assertEqual({record.path for record in captured.mixed}, set(expected))
                        for record in captured.mixed:
                            for source, content in zip((record.base, record.index, record.working_tree), expected[record.path]):
                                if content is None:
                                    self.assertEqual(source, self.helper["SourceVersion"]("absent", None, None))
                                else:
                                    self.assertEqual(source.content, content)
                        self.helper["verify_mixed_sources"](repo, captured.mixed)
                        self.assertEqual(self.helper["source_tree_snapshot"](repo), snapshot)

    def test_large_tracked_paths_keep_complete_mixed_sources(self):
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            path = repo / "large.py"
            content = "unchanged context\n" * 15_000
            path.write_bytes(("base()\n" + content).encode("utf-8"))
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "large base")
            base = git(repo, "rev-parse", "HEAD").strip()
            path.write_bytes(("changed()\n" + content).encode("utf-8"))
            for staged in (False, True):
                if staged:
                    git(repo, "add", ".")
                captured = self.helper["local_bundle"](repo)
                self.assertEqual(captured.mixed, ())
                self.assertLess(len(captured.text), 10_000)
                self.assertIn("+changed()", captured.text)
            git(repo, "commit", "-qm", "large tiny edit")
            for target in ("branch", "commit"):
                captured = self.helper["build_bundle"](repo, target, base, "HEAD")
                self.assertEqual(captured.mixed, ())
            path.write_bytes(("staged()\n" + content).encode("utf-8"))
            git(repo, "add", ".")
            path.write_bytes(("working()\n" + content).encode("utf-8"))
            captured = self.helper["local_bundle"](repo)
            record, = captured.mixed
            for source, expected in (
                (record.base, "changed()\n" + content),
                (record.index, "staged()\n" + content),
                (record.working_tree, "working()\n" + content),
            ):
                self.assertEqual(source.content, expected)
            self.helper["verify_mixed_sources"](repo, captured.mixed)

    def test_full_source_safeguards_and_sensitive_omission(self):
        for bad in (b"\0binary", b"\xffinvalid"):
            with self.subTest(bad=bad), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                path = repo / "source.py"
                (repo / ".gitattributes").write_text("source.py diff\n")
                suffix = b"safe context\n" * 16_000 + bad + b"\n"
                path.write_bytes(b"base()\n" + suffix)
                git(repo, "add", ".")
                git(repo, "commit", "-qm", "synthetic hidden tail")
                path.write_bytes(b"staged()\n" + suffix)
                git(repo, "add", ".")
                path.write_bytes(b"working()\n" + suffix)
                with self.assertRaisesRegex(SystemExit, "binary|non-UTF-8"):
                    self.helper["local_bundle"](repo)
        with self.migration() as (repo, *_):
            (repo / ".env").write_text("SYNTHETIC_STAGED_OMISSION\n")
            git(repo, "add", ".env")
            (repo / ".env").write_text("SYNTHETIC_WORKING_OMISSION\n")
            captured = self.helper["local_bundle"](repo)
            self.assertNotIn(".env", captured.paths)
            self.assertEqual(len(captured.mixed), 5)
            self.assertNotIn("SYNTHETIC_", captured.text)

    def test_mixed_source_mutations_and_topology_refuse_later_sends(self):
        for mutation in ("index", "index conflict", "index symlink", "index gitlink", "content",
                         "replace", "ancestor", "delete", "leaf symlink", "ancestor symlink"):
            if mutation in ("leaf symlink", "ancestor symlink") and os.name == "nt":
                continue
            with self.subTest(mutation=mutation), self.migration() as (repo, *_):
                captured = self.helper["local_bundle"](repo)
                passes = self.helper["build_review_prompts"](repo, "local", None, captured, "", [])
                path = repo / "src/migrate-0.py"
                source = path.read_bytes()
                if mutation == "index":
                    git(repo, "add", str(path))
                elif mutation.startswith("index "):
                    oid = git(repo, "rev-parse", "HEAD" if mutation == "index gitlink" else ":src/migrate-0.py").strip()
                    if mutation == "index conflict":
                        git(repo, "update-index", "--force-remove", "--", "src/migrate-0.py")
                        # Text-mode stdin on Windows adds a CR to Git's pathname.
                        fixture_git(repo, "update-index", "--index-info", check=True,
                                    input=f"100644 {oid} 2\tsrc/migrate-0.py\n".encode(), capture_output=True)
                    else:
                        mode = "160000" if mutation == "index gitlink" else "120000"
                        git(repo, "update-index", "--cacheinfo", f"{mode},{oid},src/migrate-0.py")
                elif mutation == "content":
                    before = path.stat()
                    path.write_bytes(source.replace(b"corrected", b"different"))
                    os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
                elif mutation == "replace":
                    other = repo.parent / "replacement.py"
                    other.write_bytes(source)
                    other.replace(path)
                elif mutation in ("ancestor", "ancestor symlink"):
                    path.parent.rename(repo / "moved")
                    if mutation == "ancestor symlink":
                        path.parent.symlink_to("moved", target_is_directory=True)
                    else:
                        path.parent.mkdir()
                        for file in (repo / "moved").iterdir():
                            (path.parent / file.name).write_bytes(file.read_bytes())
                elif mutation == "leaf symlink":
                    path.rename(path.with_suffix(".copy"))
                    path.symlink_to(path.with_suffix(".copy").name)
                else:
                    path.unlink()
                provider = mock.Mock()
                with mock.patch.dict(self.helper["run_reviewer"].__globals__, {
                    "run_engine": provider,
                }), contextlib.redirect_stderr(io.StringIO()):
                    refusal = "unsafe mixed source mode" if mutation.startswith("index ") else "mixed source changed|symlinked mixed source"
                    with self.assertRaisesRegex(SystemExit, refusal):
                        self.helper["run_reviewer"](argparse.Namespace(engine="codex", max_priority="P0"),
                                                     repo, passes[0], captured, [])
                provider.assert_not_called()

    def test_every_pass_sends_complete_authoritative_context(self):
        with self.migration(scan_sentinel=True) as (repo, *_):
            # Unchanged authoritative source outside diff hunks reaches the reviewer.
            captured = self.helper["local_bundle"](repo)
            self.assertNotIn("SOURCE_ONLY_SCAN_SENTINEL", captured.text)
            evidence = [self.helper["ReviewDataset"]("evidence.txt", "evidence\n" * 6000)]
            sends = []
            with mock.patch.dict(self.helper["prepare_review_prompts"].__globals__, {
                "run_engine": lambda _args, _repo, prompt: sends.append(prompt) or json.dumps({
                    "findings": [], "overall_correctness": "patch is correct",
                    "overall_explanation": "Synthetic clean.", "overall_confidence": 0.9,
                    "review_completion": "complete",
                }),
            }), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                passes = self.helper["prepare_review_prompts"](repo, "local", None, captured, "", evidence, 30_000)
                self.assertGreater(len(passes), 1)
                args = argparse.Namespace(engine="codex", max_priority="P0")
                self.helper["run_review_passes"](args, [args], repo, passes, captured)
            self.assertEqual(len(passes), len(sends))
            for item, sent in zip(passes, sends):
                self.assertEqual(item.prompt, sent)
                for record in item.chunk.sources:
                    self.assertIn(record.index.content, sent)
                    self.assertIn(record.working_tree.content, sent)

    def test_unfinished_mixed_pass_retains_valid_attribution_without_certifying_scope(self):
        with self.migration() as (repo, *_):
            captured = self.helper["local_bundle"](repo)
            record = captured.mixed[0]
            finding = {
                "title": "Synthetic claim", "body": "A concrete migration defect.",
                "priority": "P2", "confidence": 0.8, "category": "bug",
                "code_location": {"file_path": record.path, "line": 1},
                "source_attribution": {
                    "target": "index", "record_id": record.identity,
                    "source_id": record.index.identity, "side": "present",
                    "column": 1, "excerpt": "obsolete(0)",
                },
            }
            provider = {
                "findings": [finding], "overall_correctness": "patch is incorrect",
                "overall_explanation": "Awaiting another batch.", "overall_confidence": 0.2,
            }
            prepare = self.helper["prepare_review_prompts"]
            for completions in (("incomplete",), ("incomplete", "complete"), ("complete", "incomplete")):
                with self.subTest(completions=completions):
                    output, status = repo.parent / "result.json", repo.parent / "status.json"
                    engine = mock.Mock(side_effect=[
                        json.dumps({**provider, "review_completion": completion}) for completion in completions
                    ])
                    argv = [str(SCRIPT), "--mode", "local", "--max-priority", "P2",
                            "--require-finding", "Synthetic claim", "--expect-findings",
                            "--json-output", str(output), "--status-output", str(status)]
                    text = io.StringIO()
                    with mock.patch.dict(self.helper["main_impl"].__globals__, {
                        "repo_root": lambda: repo,
                        "prepare_review_prompts": lambda *args: prepare(*args) * len(completions),
                        "run_engine": engine,
                    }), mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(text):
                        self.assertEqual(self.helper["main_impl"](), 2)
                    result = json.loads(output.read_text())
                    self.assertEqual(engine.call_count, len(completions))
                    self.assertEqual(result["review_status"], "incomplete")
                    self.assertEqual(result["findings"][0]["source_attribution"], finding["source_attribution"])
                    self.assertNotIn("attribution_rejected_findings", result)
                    self.assertNotIn("missing_required_findings", result)
                    self.assertEqual(len(result["pass_reports"]), len(completions))
                    for entry in result["pass_reports"]:
                        self.assertEqual(entry["report"]["provider_report"], provider)
                    self.assertNotIn("review_completion", output.read_text())
                    self.assertTrue(json.loads(status.read_text())["report_produced"])
                    self.assertIn("provider observation (incomplete review)", text.getvalue())
                    self.assertNotIn("scoped-clean", text.getvalue())

    def test_honest_capacity_refusal_and_no_legacy_metadata_bypass(self):
        with self.migration() as (repo, *_):
            captured = self.helper["local_bundle"](repo)
            provider = mock.Mock()
            with mock.patch.dict(self.helper["prepare_review_prompts"].__globals__, {
                "run_engine": provider,
            }):
                with self.assertRaisesRegex(SystemExit, r"mixed source src/migrate-0.py .*index=.*working_tree=.*prompt limit 1000"):
                    self.helper["prepare_review_prompts"](repo, "local", None, captured, "", [], 1000)
                with self.assertRaisesRegex(SystemExit, "owner-built pass metadata"):
                    self.helper["run_reviewer"](argparse.Namespace(engine="codex"), repo, "flattened", captured, [])
                chunk = self.helper["ReviewChunk"]("xxxx", sources=(captured.mixed[0],))
                budget = len(self.helper["render_review_prompt"](
                    self.helper["current_branch"](repo), "local", None, chunk, "", "", (999_999, 999_999),
                ).encode()) + 1000
                datasets = [self.helper["ReviewDataset"]("e" * 4000 + ".txt", "evidence")]
                build = self.helper["build_mixed_change_passes"]
                failures = []

                def observe_failure(*args, **kwargs):
                    try:
                        return build(*args, **kwargs)
                    except self.helper["MixedContextCapacityError"] as error:
                        failures.append(error)
                        raise

                with mock.patch.dict(self.helper["prepare_review_prompts"].__globals__, {
                    "build_mixed_change_passes": observe_failure,
                }):
                    with self.assertRaisesRegex(SystemExit, r"mixed source src/migrate-\d.py .*prompt limit") as refused:
                        self.helper["prepare_review_prompts"](repo, "local", None, captured, "", datasets, budget)
                self.assertGreaterEqual(len(failures), 2)
                self.assertIs(refused.exception, failures[-2], "retain the terminal batch error when whole evidence also fails")
            provider.assert_not_called()


    def test_mixed_results_keep_index_exit_stale_rejections_filters_and_raw_reports(self):
        cases = (
            # target, excerpt, verdict, priority, required, expect, status, exit
            ("index", "obsolete(0)", "patch is incorrect", "P2", [], False, "findings", 1),
            ("working_tree", "corrected(0)", "patch is incorrect", "P2", [], False, "findings", 1),
            ("working_tree", "obsolete(0)", "patch is correct", "P2", [], True, "incomplete", 2),
            (None, "obsolete(0)", "patch is correct", "P2", [], False, "incomplete", 2),
            ("index", "obsolete(0)", "patch is incorrect", "P0", [], False, "filtered", 1),
            ("index", "obsolete(0)", "patch is correct", "P0", [], False, "filtered", 0),
            ("index", "obsolete(0)", "patch is correct", "P0", ["Synthetic claim"], True, "incomplete", 2),
            ("index", "obsolete(0)", "patch is incorrect", "P2", ["Synthetic claim"], True, "findings", 0),
        )
        with self.migration() as (repo, *_):
            captured = self.helper["local_bundle"](repo)
            record = captured.mixed[0]
            original_prepare = self.helper["prepare_review_prompts"]
            for count in (1, 2):
                for target, excerpt, verdict, priority, required, expect, expected_status, expected_exit in cases:
                    with self.subTest(count=count, target=target, excerpt=excerpt, priority=priority, expect=expect):
                        finding = {
                            "title": "Synthetic claim", "body": "A concrete migration defect.",
                            "priority": "P2", "confidence": 0.8, "category": "bug",
                            "code_location": {"file_path": record.path, "line": 1},
                        }
                        if target:
                            finding["source_attribution"] = {
                                "target": target, "record_id": record.identity,
                                "source_id": getattr(record, target).identity,
                                "side": "present", "column": 1, "excerpt": excerpt,
                            }
                        provider = {"findings": [finding], "overall_correctness": verdict,
                                    "overall_explanation": "Synthetic provider conclusion.", "overall_confidence": 0.61}
                        output = repo.parent / "result.json"
                        argv = [str(SCRIPT), "--mode", "local", "--max-priority", priority,
                                "--json-output", str(output)]
                        for needle in required:
                            argv += ["--require-finding", needle]
                        if expect:
                            argv.append("--expect-findings")
                        text = io.StringIO()
                        with mock.patch.dict(self.helper["main_impl"].__globals__, {
                            "repo_root": lambda: repo,
                            "prepare_review_prompts": lambda *args: original_prepare(*args) * count,
                            "run_engine": lambda *_: json.dumps({**provider, "review_completion": "complete"}),
                        }), mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(text), \
                                contextlib.redirect_stderr(io.StringIO()):
                            self.assertEqual(self.helper["main_impl"](), expected_exit)
                        report = json.loads(output.read_text())
                        self.assertEqual(report["review_status"], expected_status)
                        self.assertEqual(report["overall_confidence"], 0.61)
                        self.assertEqual(report["overall_correctness"], verdict)
                        self.assertEqual(len(report["pass_reports"]), count)
                        for entry in report["pass_reports"]:
                            self.assertEqual(entry["report"]["provider_report"], provider)
                        self.assertNotIn("scoped-clean", text.getvalue())
                        if target == "index":
                            self.assertIn("INDEX-only", text.getvalue())
                        if expected_status == "incomplete" and not required:
                            self.assertTrue(report["attribution_rejected_findings"])
                        if expected_status == "findings":
                            self.assertEqual(len(report["findings"]), 1)
                            self.assertEqual(len(report["findings"][0]["claim_variants"][0]["observations"]), count)

    def test_mixed_crlf_absence_and_executable_mode_keep_exact_source_bytes(self):
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            git(repo, "config", "core.autocrlf", "false")
            path = repo / "source.py"
            path.write_bytes(b"base()\r\nkeep()\r\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "CRLF base")
            path.write_bytes(b"obsolete()\r\nkeep()\r\n")
            if os.name != "nt":
                path.chmod(0o755)
            git(repo, "add", ".")
            path.write_bytes(b"corrected()\r\nkeep()\r\n")
            captured = self.helper["local_bundle"](repo)
            record, = captured.mixed
            self.assertEqual(record.index_removed, ((1, "base()\r"),))
            self.assertEqual(record.working_tree_removed, ((1, "obsolete()\r"),))
            self.assertIn("+obsolete()\r\n", captured.text)
            self.assertEqual(record.working_tree.content.encode(), path.read_bytes())
            if os.name != "nt":
                self.assertEqual(record.base.mode, "100644")
                self.assertEqual(record.index.mode, "100755")

    def test_git_display_settings_preserve_mixed_sources_and_chunk_coordinates(self):
        settings = (
            (), (("diff.suppressBlankEmpty", "false"),),
            (("diff.suppressBlankEmpty", "true"),),
            (("diff.suppress-blank-empty", "true"),),
            (("color.ui", "always"),), (("color.diff", "always"),),
            (("diff.color", "always"),),
            (("diff.suppressBlankEmpty", "true"), ("color.diff", "always")),
        )
        for config in settings:
            for pinned in (False, True):
                with self.subTest(config=config, pinned=pinned), tempfile.TemporaryDirectory() as tempdir:
                    repo = init_repo(Path(tempdir))
                    git(repo, "config", "core.autocrlf", "false")
                    for key, value in config:
                        git(repo, "config", key, value)
                    path = repo / "source.py"
                    path.write_bytes(b"one\n\nbase\n")
                    git(repo, "add", ".")
                    git(repo, "commit", "-qm", "base")
                    base = git(repo, "rev-parse", "HEAD").strip()
                    if pinned:
                        path.write_bytes(b"one\n\nhead\n")
                        git(repo, "commit", "-qam", "advance HEAD")
                    path.write_bytes(b"one\n\nstaged\n")
                    git(repo, "add", ".")
                    path.write_bytes(b"one\n\nworking\n")
                    original_config = (repo / ".git/config").read_bytes()
                    captured = self.helper["local_bundle"](repo, base if pinned else None)
                    record, = captured.mixed
                    self.assertEqual(record.base.content, "one\n\nbase\n")
                    self.assertEqual(record.index.content, "one\n\nstaged\n")
                    self.assertEqual(record.working_tree.content, "one\n\nworking\n")
                    self.assertEqual(record.index_removed, ((3, "base"),))
                    self.assertEqual(record.working_tree_removed, ((3, "staged"),))
                    self.helper["verify_mixed_sources"](repo, captured.mixed)
                    for patch in (record.staged, record.unstaged):
                        self.assertNotIn("\x1b", patch)
                        context = []
                        new_line = old_line = None
                        in_hunk = False
                        for line in self.helper["literal_lf_lines"](patch):
                            new_line, old_line, in_hunk = self.helper["update_review_chunk_context"](
                                context, line, new_line, old_line, in_hunk,
                            )
                        self.assertEqual((new_line, old_line), (4, 4))
                    self.assertEqual((repo / ".git/config").read_bytes(), original_config)

    def test_readded_untracked_capture_is_reused_and_evidence_stays_separate(self):
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            path = repo / "source.py"
            path.write_bytes(b"base()\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "base")
            git(repo, "rm", "source.py")
            path.write_bytes(b"readded()\n")
            read = mock.Mock(wraps=self.helper["read_file_bytes"])
            with mock.patch.dict(self.helper["local_bundle"].__globals__, {"read_file_bytes": read}):
                captured = self.helper["local_bundle"](repo)
            self.assertEqual(sum(call.args[0] == path for call in read.call_args_list), 1)
            (repo / ".git/info/exclude").write_text("evidence/\n")
            evidence_path = repo / "evidence/source.py"
            evidence_path.parent.mkdir()
            evidence_path.write_text("fake authoritative replacement()\n")
            evidence = self.helper["capture_evidence_inputs"](
                argparse.Namespace(prompt=[], prompt_file=[], dataset=["evidence/source.py"]), repo,
            )
            passes = self.helper["build_review_prompts"](repo, "local", None, captured, "", evidence.datasets)
            record = passes[0].chunk.sources[0]
            self.assertEqual(record.working_tree.content, "readded()\n")
            self.assertNotIn(evidence_path.relative_to(repo).as_posix(), captured.paths)
            before = self.helper["source_tree_snapshot"](repo)
            evidence_path.write_text("mutated evidence()\n")
            self.assertEqual(self.helper["source_tree_snapshot"](repo), before)
            provider = mock.Mock()
            with mock.patch.dict(self.helper["run_reviewer"].__globals__, {
                "run_engine": provider,
            }), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaisesRegex(SystemExit, "evidence changed"):
                    self.helper["run_reviewer"](argparse.Namespace(engine="codex"), repo, passes[0], captured, [],
                                                 evidence=evidence.files)
            provider.assert_not_called()

    def test_ignored_or_unsafe_readdition_cannot_bypass_mixed_capture(self):
        for kind, name in (
            ("ignored", "source.py"),
            ("ignored", "line\rbreak.py"),
            ("ignored", "line\r\nbreak.py"),
            ("symlink", "source.py"),
            ("directory symlink", "source.py"),
            ("dangling symlink", "source.py"),
        ):
            if os.name == "nt" and (kind != "ignored" or "\r" in name):
                continue
            with self.subTest(kind=kind, name=name), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                path = repo / name
                path.write_text("base()\n")
                git(repo, "add", ".")
                git(repo, "commit", "-qm", "base")
                git(repo, "rm", "--", name)
                if kind == "ignored":
                    (repo / ".git/info/exclude").write_text("*.py\n")
                    path.write_text("ignored content never sent\n")
                else:
                    outside = repo.parent / "outside.py"
                    if kind == "directory symlink":
                        outside.mkdir()
                        (outside / "child.py").write_text("outside content never sent\n")
                    elif kind == "symlink":
                        outside.write_text("outside content never sent\n")
                    path.symlink_to(outside, target_is_directory=kind == "directory symlink")
                with self.assertRaisesRegex(SystemExit, "working_tree.*validated untracked membership"):
                    self.helper["local_bundle"](repo)


class AutoreviewBinaryDeletionTests(unittest.TestCase):
    def setUp(self):
        self.helper = load_helper()

    @contextlib.contextmanager
    def asset_repo(self, name="asset.bin", *, binary=True):
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            asset = repo / name
            asset.parent.mkdir(parents=True, exist_ok=True)
            asset.write_bytes(b"\0FORMER_BINARY_BYTES" if binary else b"old text\n")
            (repo / "source.py").write_bytes(b"before()\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "base")
            base = git(repo, "rev-parse", "HEAD").strip()
            yield repo, asset, base

    def assert_deletion(self, repo, captured, name, target, ref=None, *, source=True):
        self.assertEqual(captured.paths, {name, "source.py"} if source else {name})
        self.assertIn("deleted file mode 100644", captured.text)
        self.assertIn("Binary files ", captured.text)
        self.assertIn(" and /dev/null differ", captured.text)
        self.assertNotIn("FORMER_BINARY_BYTES", captured.text)
        if source:
            self.assertIn("+after()", captured.text)
        prompts = self.helper["build_review_prompts"](repo, target, ref, captured, "", [])
        self.assertEqual(len(prompts), 1)
        prompt = prompts[0].prompt if captured.mixed else prompts[0]
        self.assertIn(captured.text, prompt)
        return prompt

    def test_local_staged_and_unstaged_deletions_keep_metadata_and_scope(self):
        for staged in (False, True):
            with self.subTest(staged=staged), self.asset_repo() as (repo, asset, base):
                asset.unlink()
                (repo / "source.py").write_bytes(b"after()\n")
                if staged:
                    git(repo, "add", "-u")
                for ref in (None, base):
                    with self.subTest(base=ref):
                        captured = self.helper["local_bundle"](repo, ref)
                        self.assert_deletion(repo, captured, asset.name, "local", ref)
                        self.assertEqual(captured.mixed, ())
                        heading = "# Staged Diff" if staged else "# Unstaged Diff"
                        self.assertIn("Binary files ", captured.text.split(heading, 1)[1])

    def test_committed_deletion_is_reviewable_from_pinned_base_commit_and_branch(self):
        with self.asset_repo() as (repo, asset, base):
            git(repo, "rm", "--", asset.name)
            (repo / "source.py").write_bytes(b"after()\n")
            git(repo, "commit", "-qam", "remove asset")
            commit = git(repo, "rev-parse", "HEAD").strip()
            for target in ("local", "commit", "branch"):
                with self.subTest(target=target):
                    captured = self.helper["build_bundle"](repo, target, base, commit)
                    self.assert_deletion(repo, captured, asset.name, target, base)
            # Committed targets are authoritative, not the current filesystem.
            asset.write_bytes(b"\0UNRELATED_DIRTY_BINARY")
            for target in ("commit", "branch"):
                with self.subTest(dirty_target=target):
                    captured = self.helper["build_bundle"](repo, target, base, commit)
                    self.assert_deletion(repo, captured, asset.name, target, base)
                    self.assertNotIn("UNRELATED_DIRTY_BINARY", captured.text)

    @unittest.skipIf(os.name == "nt", "literal tab/newline filenames require POSIX")
    def test_literal_tab_newline_and_metadata_like_paths_remain_distinct(self):
        names = ("tab\tasset.bin", "line\nbreak.bin", ":100644 000000 aaaaaaa 0000000 D")
        for name in names:
            with self.subTest(name=name), self.asset_repo(name) as (repo, asset, base):
                asset.unlink()
                for staged in (False, True):
                    if staged:
                        git(repo, "add", "-u")
                    captured = self.helper["local_bundle"](repo, base)
                    self.assert_deletion(repo, captured, name, "local", base, source=False)
                git(repo, "commit", "-qm", "remove literal asset")
                for target in ("branch", "commit"):
                    captured = self.helper["build_bundle"](repo, target, base, "HEAD")
                    self.assert_deletion(repo, captured, name, target, base, source=False)

    def test_binary_only_removal_prompt_is_explicitly_metadata_only(self):
        with self.asset_repo() as (repo, asset, _base):
            asset.unlink()
            captured = self.helper["local_bundle"](repo)
            prompt = self.assert_deletion(repo, captured, asset.name, "local", source=False)
            self.assertIn("Binary deletions include Git metadata only", prompt)
            self.assertIn("not the former binary contents", prompt)

    def test_binary_additions_modifications_and_text_replacements_still_refuse(self):
        for kind in ("addition", "modification", "binary-to-text", "text-to-binary"):
            with self.subTest(kind=kind), self.asset_repo(binary=kind != "text-to-binary") as (repo, asset, base):
                if kind == "addition":
                    asset = repo / "added.bin"
                asset.write_bytes(b"new text\n" if kind == "binary-to-text" else b"\0NEW_BINARY_BYTES")
                # Include a genuine deletion in the same transition: its permission
                # must not exempt another path's binary content.
                removed = repo / "removed.bin"
                removed.write_bytes(b"\0removed")
                git(repo, "add", "--", removed.name)
                git(repo, "commit", "-qm", "deletion neighbor")
                removed.unlink()
                if kind != "addition":
                    with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                        self.helper["local_bundle"](repo, base)
                git(repo, "add", ".")
                for ref in (None, base):
                    with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                        self.helper["local_bundle"](repo, ref)
                git(repo, "commit", "-qm", "binary content change")
                for target in ("branch", "commit"):
                    with self.assertRaisesRegex(SystemExit, "refusing (binary changes|unsupported binary)"):
                        self.helper["build_bundle"](repo, target, base, "HEAD")

    def test_worktree_deletion_cannot_hide_staged_binary_change(self):
        for kind in ("addition", "modification"):
            with self.subTest(kind=kind), self.asset_repo() as (repo, asset, base):
                if kind == "addition":
                    asset = repo / "added.bin"
                asset.write_bytes(b"\0STAGED_BINARY_BYTES")
                git(repo, "add", "--", asset.name)
                asset.unlink()
                for ref in (None, base):
                    with self.assertRaisesRegex(SystemExit, "binary changes in local staged diff"):
                        self.helper["local_bundle"](repo, ref)

    def test_transient_deletion_cannot_exempt_a_captured_binary_modification(self):
        for staged in (False, True):
            with self.subTest(staged=staged), self.asset_repo() as (repo, asset, _base):
                asset.write_bytes(b"\0MODIFIED_BINARY_BYTES")
                if staged:
                    git(repo, "add", "--", asset.name)
                real_git = self.helper["git"]

                def mutate_raw(root, *args, **kwargs):
                    if args[0] == "diff" and "--raw" in args and "--patch" not in args:
                        asset.unlink()
                        if staged:
                            git(repo, "add", "-u")
                        try:
                            return real_git(root, *args, **kwargs)
                        finally:
                            asset.write_bytes(b"\0MODIFIED_BINARY_BYTES")
                            if staged:
                                git(repo, "add", "--", asset.name)
                    return real_git(root, *args, **kwargs)

                with mock.patch.dict(self.helper["local_bundle"].__globals__, {"git": mutate_raw}):
                    with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                        self.helper["local_bundle"](repo)

    @unittest.skipIf(os.name == "nt", "symlink type change requires POSIX")
    def test_binary_to_symlink_type_change_is_not_a_deletion(self):
        with self.asset_repo() as (repo, asset, base):
            asset.unlink()
            asset.symlink_to("source.py")
            for staged in (False, True):
                if staged:
                    git(repo, "add", ".")
                with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                    self.helper["local_bundle"](repo, base)
            git(repo, "commit", "-qm", "change asset type")
            for target in ("branch", "commit"):
                with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                    self.helper["build_bundle"](repo, target, base, "HEAD")

    def test_staged_deletion_and_validated_text_readdition_keep_mixed_ownership(self):
        with self.asset_repo() as (repo, asset, base):
            git(repo, "rm", "--", asset.name)
            asset.write_bytes(b"replacement text\n")
            for ref in (None, base):
                captured = self.helper["local_bundle"](repo, ref)
                self.assert_deletion(repo, captured, asset.name, "local", ref, source=False)
                record, = captured.mixed
                self.assertEqual(record.path, asset.name)
                self.assertEqual(record.index.identity, "absent")
                self.assertIsNone(record.base.content)
                self.assertEqual(record.index_removed, ())
                self.assertEqual(record.working_tree.content, "replacement text\n")
                self.assertEqual({span.target for span in captured.spans}, {"index", "working_tree"})
                self.helper["verify_mixed_sources"](repo, captured.mixed)
            asset.write_bytes(b"changed replacement\n")
            with self.assertRaisesRegex(SystemExit, "mixed source changed"):
                self.helper["verify_mixed_sources"](repo, captured.mixed)

    def test_staged_deletion_does_not_admit_unsafe_readditions(self):
        for kind in ("binary", "non-UTF-8", "ignored", "symlink"):
            if kind == "symlink" and os.name == "nt":
                continue
            with self.subTest(kind=kind), self.asset_repo() as (repo, asset, base):
                git(repo, "rm", "--", asset.name)
                if kind == "symlink":
                    asset.symlink_to(repo.parent / "unavailable")
                else:
                    asset.write_bytes({"binary": b"\0replacement", "non-UTF-8": b"\xff",
                                       "ignored": b"ignored text\n"}[kind])
                if kind == "ignored":
                    (repo / ".git/info/exclude").write_text("*.bin\n")
                reason = "binary file|non-UTF-8 file" if kind in {"binary", "non-UTF-8"} else "validated untracked membership"
                for ref in (None, base):
                    with self.assertRaisesRegex(SystemExit, reason):
                        self.helper["local_bundle"](repo, ref)

    def test_sensitive_binary_deletions_retain_security_omissions(self):
        with self.asset_repo(".env") as (repo, asset, base):
            git(repo, "rm", "--", asset.name)
            (repo / "source.py").write_bytes(b"after()\n")
            git(repo, "add", "source.py")
            captured = self.helper["local_bundle"](repo, base)
            git(repo, "commit", "-qm", "remove sensitive asset")
            bundles = [captured, *(self.helper["build_bundle"](repo, target, base, "HEAD")
                                   for target in ("branch", "commit"))]
            for captured in bundles:
                self.assertEqual(captured.paths, {"source.py"})
                self.assertIn(self.helper["REVIEW_SECURITY_OMISSION"], captured.text)
                self.assertIn("+after()", captured.text)
                self.assertNotIn(".env", captured.text)
                self.assertNotIn("FORMER_BINARY_BYTES", captured.text)

    def test_gitlink_deletions_include_metadata(self):
        with self.asset_repo() as (repo, _asset, base):
            git(repo, "update-index", "--add", "--cacheinfo", f"160000,{base},dependency")
            git(repo, "commit", "-qm", "gitlink base")
            base = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "update-index", "--force-remove", "dependency")
            for ref in (None, base):
                self.assertIn('"new": {"mode": "000000", "sha": null',
                              self.helper["local_bundle"](repo, ref).text)
            git(repo, "commit", "-qm", "remove gitlink")
            for target in ("branch", "commit"):
                self.assertIn('"new": {"mode": "000000", "sha": null',
                              self.helper["build_bundle"](repo, target, base, "HEAD").text)

    def test_readdition_during_bundle_capture_prevents_reviewer_start(self):
        with self.asset_repo() as (repo, asset, _base):
            git(repo, "rm", "--", asset.name)
            build = self.helper["build_bundle"]

            def mutate(*args):
                captured = build(*args)
                asset.write_bytes(b"\0REAPPEARED_BINARY_BYTES")
                return captured

            reviewer = mock.Mock()
            main = self.helper["main_impl"]
            with mock.patch.dict(main.__globals__, {"repo_root": lambda: repo,
                    "build_bundle": mutate, "run_engine": reviewer}), \
                    mock.patch.object(sys, "argv", [str(SCRIPT), "--mode", "local"]), \
                    contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaisesRegex(SystemExit, "source changed while"):
                    main()
            reviewer.assert_not_called()


class AutoreviewHardeningTests(unittest.TestCase):
    def setUp(self) -> None:
        self.helper = load_helper()

    @contextlib.contextmanager
    def without_reviewer_defaults(self):
        with mock.patch.dict(os.environ):
            for name in tuple(os.environ):
                if name.startswith("AUTOREVIEW_") and name != "AUTOREVIEW_GIT":
                    os.environ.pop(name)
            yield

    @contextlib.contextmanager
    def preparation_fixture(self, *options):
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            # Protected review reads ignore host Git config, including Windows autocrlf.
            git(repo, "config", "core.autocrlf", "false")
            for index in range(24):
                (repo / f"unchanged-{index}.txt").write_text("old\n")
            (repo / "source.md").write_text("before\n")
            (repo / ".gitignore").write_text("evidence/\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "fixture")
            (repo / "source.md").write_text("after\n")
            (repo / "evidence").mkdir()
            (repo / "evidence/note.md").write_text("frozen evidence\r\n")
            sends = []
            stdout, stderr = io.StringIO(), io.StringIO()

            def engine(_args, _repo, prompt):
                self.assertFalse(any(thread.name == "autoreview-preparation"
                                     for thread in threading.enumerate()))
                sends.append(prompt)
                return json.dumps({
                    "findings": [], "overall_correctness": "patch is correct",
                    "overall_explanation": "fixture clean", "overall_confidence": 0.99,
                    "review_completion": "complete",
                })

            with self.without_reviewer_defaults(), mock.patch.dict(self.helper["main_impl"].__globals__, {
                "repo_root": lambda: repo,
                "run_engine": engine,
                "resolve_engine_binary": lambda *_args: (True, None),
            }), mock.patch.object(sys, "argv", [str(SCRIPT), "--engine", "codex", "--mode", "local", *options]), \
                    contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                yield repo, sends, stdout, stderr

    @contextlib.contextmanager
    def committed_context_fixture(self, *options, path="src/token_count.py", role="--source-context",
                                  content=b"def count_tokens(): return 7\r\n", setup=None):
        with self.preparation_fixture(
            "--mode", "branch", "--base", "HEAD^", role, path, *options,
        ) as fixture:
            repo = fixture[0]
            source = repo / path
            source.parent.mkdir(parents=True, exist_ok=True)
            source.write_bytes(content)
            git(repo, "add", "--", path)
            if setup:
                setup(repo, source)
            git(repo, "commit", "--allow-empty", "-qm", "source context")
            git(repo, "add", "source.md")
            git(repo, "commit", "-qm", "selected change")
            yield fixture

    def test_source_context_uses_reviewed_blob_not_working_copy_or_current_head(self):
        for role, mode in ((role, mode) for role in ("--source-context", "--source-context-file")
                           for mode in ("branch", "commit")):
            with self.subTest(role=role, mode=mode), self.committed_context_fixture(role=role) as (repo, sends, *_):
                commit = git(repo, "rev-parse", "HEAD").strip()
                oid = git(repo, "rev-parse", "HEAD:src/token_count.py").strip()
                source = repo / "src/token_count.py"
                original = source.read_bytes().decode()
                if mode == "commit":
                    source.write_text("newer committed bytes\n")
                    git(repo, "commit", "-qam", "later commit outside selected target")
                source.write_text("dirty checkout bytes must never be context\n")
                options = ["--mode", mode, "--commit", commit]
                with mock.patch.object(sys, "argv", [*sys.argv, *options]):
                    self.assertEqual(self.helper["main_impl"](), 0)
                self.assertEqual(len(sends), 1)
                self.assertIn(original, sends[0])
                self.assertIn(f"commit={commit} blob={oid} mode=100644; context only", sends[0])
                self.assertNotIn("dirty checkout bytes", sends[0])
                self.assertNotIn("newer committed bytes", sends[0])
                self.assertNotIn("src/token_count.py", sends[0].split("# Change Bundle\n", 1)[1])

    def test_source_context_credential_flow_uses_frozen_document(self):
        paths = ("docs/flows/credential-source-egress/model-requests.md",
                 "docs/reference/repository-credentials/prepared-native-git.md",
                 "docs/reference/credential-sources/protected-inference.md",
                 "specs/rfcs/0023-egress-proxy-credential-lifecycle/github-installation-access.md",
                 "specs/rfcs/0023-egress-proxy-credential-lifecycle/index.md")
        content = b"# Model requests\n\nAuthorize each request before releasing a key.\n"
        for path, role in itertools.product(paths, ("--source-context", "--source-context-file")):
            with self.subTest(path=path, role=role), self.committed_context_fixture(
                path=path, role=role, content=content,
            ) as (repo, sends, *_):
                commit = git(repo, "rev-parse", "HEAD").strip()
                oid = git(repo, "rev-parse", f"HEAD:{path}").strip()
                (repo / path).write_text("Dirty document must not replace committed context.\n")
                self.assertEqual(self.helper["main_impl"](), 0)
                self.assertEqual(len(sends), 1)
                self.assertIn(content.decode(), sends[0])
                self.assertIn(f"commit={commit} blob={oid} mode=100644; context only", sends[0])
                self.assertNotIn("Dirty document", sends[0])

    def test_source_context_compound_directories_use_tracked_source_rules(self):
        for path in (
            "packages/contracts/src/drivers/credential-proxy/index.ts",
            "drivers/repository-credentials/store.go",
            ".agents/skills/credential-proxy/SKILL.md",
        ):
            for content in (b"// first source revision\n", b"// revised source\n"):
                with self.subTest(path=path, content=content), self.committed_context_fixture(
                    path=path, content=content,
                ) as (_repo, sends, *_):
                    # Normal source capture is independent of the reviewed-pin table.
                    main = self.helper["main_impl"]
                    with mock.patch.dict(main.__globals__, {"REVIEWED_CONTEXT_BLOBS": {}}):
                        self.assertEqual(main(), 0)
                    self.assertIn(content.decode(), sends[0])

    def test_source_context_duplicates_keep_full_source_in_one_planned_pass(self):
        content = b"# context\n" * 30_000
        for role in ("--source-context", "--source-context-file"):
            with self.subTest(role=role), self.committed_context_fixture(
                role, "./src/token_count.py", "--max-review-passes", "1",
                role=role, content=content,
            ) as (_repo, sends, out, _err):
                self.assertEqual(self.helper["main_impl"](), 0)
                self.assertEqual(len(sends), 1)
                self.assertEqual(sends[0].count(content.decode()), 1)
                self.assertEqual(sends[0].count('# Source context: "src/token_count.py"'), 1)
                self.assertIn("review plan: 1 passes;", out.getvalue())

    def test_source_context_duplicate_capture_refuses_changed_bytes_or_topology(self):
        for role, change in ((role, change) for role in ("--source-context", "--source-context-file")
                             for change in ("bytes", "topology")):
            with self.subTest(role=role, change=change), self.committed_context_fixture(
                role, "./src/token_count.py", role=role,
            ) as (repo, sends, *_):
                source = repo / "src/token_count.py"
                original = self.helper["capture_source_context"]
                seen = []

                def capture(repo, path, commit):
                    record = original(repo, path, commit)
                    seen.append(path)
                    if len(seen) == 1:
                        if change == "bytes":
                            source.write_bytes(source.read_bytes().replace(b"7", b"8"))
                        else:
                            replacement = source.with_suffix(".replacement")
                            replacement.write_bytes(source.read_bytes())
                            replacement.replace(source)
                    return record

                with mock.patch.dict(self.helper["main_impl"].__globals__, {
                    "capture_source_context": capture,
                }), self.assertRaisesRegex(SystemExit, "source context changed while being captured"):
                    self.helper["main_impl"]()
                self.assertEqual(seen, ["src/token_count.py", "./src/token_count.py"])
                self.assertFalse(sends)

    def test_source_context_deduplication_preserves_distinct_paths_and_evidence_roles(self):
        content = b"# distinct role and path context\n"

        def copy_source(repo, source):
            (source.parent / "copy.py").write_bytes(source.read_bytes())
            git(repo, "add", "src/copy.py")

        with self.committed_context_fixture(
            "--source-context", "./src/owner.py", "--source-context", "src/copy.py",
            "--dataset", "src/owner.py", "--prompt-file", "src/owner.py",
            "--source-context-file", "src/owner.py", "--source-context-file", "./src/owner.py",
            "--source-context-file", "src/copy.py",
            path="src/owner.py", content=content, setup=copy_source,
        ) as (_repo, sends, *_):
            self.assertEqual(self.helper["main_impl"](), 0)
            self.assertEqual(len(sends), 1)
            self.assertEqual(sends[0].count(content.decode()), 6)
            for header, count in (
                ('# Source context: "src/owner.py"', 2), ('# Source context: "src/copy.py"', 2),
                (f"# Dataset: {Path('src/owner.py')}", 1), (f"# Prompt file: {Path('src/owner.py')}", 1),
            ):
                self.assertEqual(sends[0].count(header), count)

    def test_source_context_does_not_relax_existing_evidence_roles(self):
        for role in ("--dataset", "--prompt-file"):
            with self.subTest(role=role), self.committed_context_fixture(
                role, "src/token_count.py",
            ) as (_repo, sends, *_):
                with self.assertRaisesRegex(SystemExit, "sensitive filename"):
                    self.helper["main_impl"]()
                self.assertFalse(sends)
        for path, role in itertools.product(
            ("docs/flows/credential-source-egress/model-requests.md",
             "docs/reference/repository-credentials/prepared-native-git.md",
             "docs/reference/credential-sources/protected-inference.md",
             "specs/rfcs/0023-egress-proxy-credential-lifecycle/github-installation-access.md",
             "specs/rfcs/0023-egress-proxy-credential-lifecycle/index.md"),
            ("--dataset", "--prompt-file"),
        ):
            with self.subTest(path=path, role=role), self.committed_context_fixture(
                path=path, role=role,
            ) as (_repo, sends, *_):
                with self.assertRaisesRegex(SystemExit, "sensitive"):
                    self.helper["main_impl"]()
                self.assertFalse(sends)

    def test_source_context_requires_committed_review_mode(self):
        for role, mode in ((role, mode) for role in ("--source-context", "--source-context-file")
                           for mode in ("local", "uncommitted", "auto")):
            with self.subTest(role=role, mode=mode), self.committed_context_fixture(
                "--mode", mode, role=role,
            ) as (repo, sends, *_):
                (repo / "source.md").write_text("dirty source\n")
                with self.assertRaisesRegex(SystemExit, "requires a committed branch or commit review"):
                    self.helper["main_impl"]()
                self.assertFalse(sends)

    def test_source_context_policy_only_admits_reviewed_path_and_bytes(self):
        sample = b"apiVersion: v1\nkind: Service\n"
        path = "charts/example/templates/credentials-service.yaml"
        digest = hashlib.sha256(sample).hexdigest()
        oid = hashlib.sha1(b"blob " + str(len(sample)).encode() + b"\0" + sample).hexdigest()
        for role, selected, content, expected_digest, accepted in (
            ("--source-context", path, sample, digest, True),
            ("--source-context-file", path, sample, digest, True),
            ("--source-context", path, sample + b"# changed\n", digest, False),
            ("--source-context", path, sample, "0" * 64, False),
            ("--source-context", "charts/other/templates/credentials-service.yaml", sample, digest, False),
            ("--prompt-file", path, sample, digest, False),
        ):
            with self.subTest(role=role, selected=selected, accepted=accepted), self.committed_context_fixture(
                path=selected, role=role, content=content,
            ) as (_repo, sends, *_):
                main = self.helper["main_impl"]
                with mock.patch.dict(main.__globals__, {"REVIEWED_CONTEXT_BLOBS": {
                    path: (oid, expected_digest),
                }}):
                    if accepted:
                        self.assertEqual(main(), 0)
                        self.assertIn(sample.decode(), sends[0])
                    else:
                        with self.assertRaisesRegex(SystemExit, "sensitive|digest"):
                            main()
                        self.assertFalse(sends)

    def test_source_context_pin_scope_and_mode(self):
        content = b"// synthetic module for policy review\n"
        for path, executable, allowed in (
            ("src/credential-proxy/index.ts", False, True),
            ("fixtures/repository-credentials/state.mjs", False, True),
            ("apps/controller/src/drivers/secret/kubernetes/index.ts", False, True),
            ("apps/controller/src/drivers/secret/kubernetes/index.ts", True, False),
            ("apps/controller/src/drivers/secret/kubernetes/other.ts", False, False),
            ("apps/controller/src/drivers/secrets/kubernetes/index.ts", False, False),
            ("src/credential-proxy/index.ts", True, True),
            (".ssh/credential-proxy/index.ts", False, False),
            ("credentials/session.json", False, False),
            ("credentials/prod.ts", False, False),
            ("src/Secrets/runtime.ts", False, False),
        ):
            def setup(repo, _source):
                if executable:
                    git(repo, "update-index", "--chmod=+x", path)

            with self.subTest(path=path, executable=executable), self.committed_context_fixture(
                path=path, content=content, setup=setup,
            ) as (repo, sends, *_):
                pin = (git(repo, "rev-parse", f"HEAD:{path}").strip(), hashlib.sha256(content).hexdigest())
                main = self.helper["main_impl"]
                with mock.patch.dict(main.__globals__, {"REVIEWED_CONTEXT_BLOBS": {path: pin}}):
                    if allowed:
                        self.assertEqual(main(), 0)
                        self.assertIn(content.decode(), sends[0])
                    else:
                        with self.assertRaisesRegex(SystemExit, "sensitive --source-context"):
                            main()
                        self.assertFalse(sends)

    def test_source_context_literal_pin_keeps_content_and_topology_checks(self):
        path = "apps/controller/src/drivers/secret/kubernetes/index.ts"
        sample = b"export const synthetic = true;\n"
        oid = hashlib.sha1(b"blob " + str(len(sample)).encode() + b"\0" + sample).hexdigest()
        pin = (oid, hashlib.sha256(sample).hexdigest())
        for role in ("--source-context", "--source-context-file"):
            for kind in ("exact", "edited", "missing pin", "symlink"):
                content = sample + b"// changed\n" if kind == "edited" else sample
                with self.subTest(role=role, kind=kind), self.committed_context_fixture(
                    path=path, role=role, content=content,
                ) as (repo, sends, *_):
                    if kind == "symlink":
                        if os.name == "nt":
                            self.skipTest("symlink topology check requires POSIX")
                        (repo / path).unlink()
                        (repo / path).symlink_to(repo / "source.md")
                    pins = {} if kind == "missing pin" else {path: pin}
                    main = self.helper["main_impl"]
                    with mock.patch.dict(main.__globals__, {"REVIEWED_CONTEXT_BLOBS": pins}):
                        if kind == "exact":
                            self.assertEqual(main(), 0)
                            self.assertIn(sample.decode(), sends[0])
                            self.assertIn(f"blob={oid} mode=100644", sends[0])
                        else:
                            with self.assertRaises(SystemExit):
                                main()
                            self.assertFalse(sends)

    def test_source_context_retains_strict_directories_stores_and_keyfiles(self):
        paths = (
            "private/parser.py", "credentials/prod.py", "src/secrets/runtime.ts",
            "service-account/client.ts", ".aws/config", ".ssh/client.py",
            ".docker/Dockerfile", ".config/gcloud/client.py", "tokens/session.json",
            "src/auth-token.json", "src/.env", "src/.netrc", "src/.git-credentials",
            "keys/id_ed25519", "keys/signing.pem", "keys/signing.p12", "keys/signing.key",
            "docs/flows/credential-source-egress/session.json",
            "docs/flows/credential-source-egress/credentials.md",
            "docs/flows/credential-source-egress/.env",
            "docs/flows/credential-source-egress/signing.key",
            "docs/flows/credential-source-egress/nested/model-requests.md",
            "docs/flows/credentials/model-requests.md",
            "private/docs/flows/credential-source-egress/model-requests.md",
            "docs/Flows/credential-source-egress/model-requests.md",
            "docs/reference/repository-credentials/session.json",
            "docs/reference/repository-credentials/credentials.md",
            "docs/reference/repository-credentials/.env",
            "docs/reference/repository-credentials/signing.key",
            "docs/reference/repository-credentials/nested/guide.md",
            "docs/reference/credentials/guide.md",
            "private/docs/reference/repository-credentials/guide.md",
            "docs/Reference/repository-credentials/guide.md",
            "docs/reference/credential-sources/session.json",
            "docs/reference/credential-sources/credentials.md",
            "docs/reference/credential-sources/.env",
            "docs/reference/credential-sources/signing.key",
            "docs/reference/credential-sources/nested/guide.md",
            "docs/reference/credential-sources/guide.MD",
            "private/docs/reference/credential-sources/guide.md",
            "specs/rfcs/0023-egress-proxy-credential-lifecycle/session.json",
            "specs/rfcs/0023-egress-proxy-credential-lifecycle/credentials.md",
            "specs/rfcs/0023-egress-proxy-credential-lifecycle/.env",
            "specs/rfcs/0023-egress-proxy-credential-lifecycle/signing.key",
            "specs/rfcs/0023-egress-proxy-credential-lifecycle/nested/guide.md",
            "specs/rfcs/0023-egress-proxy-credential-lifecycle/guide.MD",
            "private/specs/rfcs/0023-egress-proxy-credential-lifecycle/guide.md",
            "docs/Reference/credential-sources/guide.md",
            "specs/RFCs/0023-egress-proxy-credential-lifecycle/guide.md",
            "specs/rfcs/credentials/guide.md",
            "specs/rfcs/0024-egress-proxy-credential-lifecycle/guide.md",
            "drivers/repository-credentials/session.json",
            "drivers/repository-credentials/.env",
            "drivers/repository-credentials/signing.pem",
            ".ssh/credential-proxy/index.ts",
            "private/credential-proxy/index.ts",
            ".aws/skills/credential-proxy/SKILL.md",
        )
        cases = [("--source-context", path) for path in paths]
        cases.append(("--source-context-file", "credentials/prod.py"))
        for role, path in cases:
            with self.subTest(role=role, path=path), self.committed_context_fixture(path=path, role=role) as (_repo, sends, *_):
                with self.assertRaisesRegex(SystemExit, "sensitive --source-context"):
                    self.helper["main_impl"]()
                self.assertFalse(sends)

    def test_source_context_rejects_unsafe_or_absent_committed_inputs_before_engine(self):
        for kind, diagnostic in (
            ("untracked", "absent from the reviewed commit"),
            ("staged only", "absent from the reviewed commit"),
            ("missing", "evidence changed or became unreadable"),
            ("tree", "regular checkout path"),
            ("symlink mode", "unsafe mixed source mode"),
            ("gitlink mode", "unsafe mixed source mode"),
            ("binary", "binary file"), ("non-UTF8", "non-UTF-8 file"),
        ):
            def setup(repo, source):
                if kind in ("untracked", "staged only"):
                    git(repo, "rm", "--cached", "--", "src/token_count.py")
                elif kind in ("symlink mode", "gitlink mode"):
                    mode = "120000" if kind == "symlink mode" else "160000"
                    oid = git(repo, "rev-parse", ":src/token_count.py" if mode == "120000" else "HEAD").strip()
                    git(repo, "update-index", "--cacheinfo", f"{mode},{oid},src/token_count.py")

            content = {"binary": b"source\0data", "non-UTF8": b"source\xffdata"}.get(kind, b"safe source\n")
            with self.subTest(kind=kind), self.committed_context_fixture(
                content=content, setup=setup,
            ) as (repo, sends, *_):
                source = repo / "src/token_count.py"
                if kind == "missing":
                    source.unlink()
                elif kind == "tree":
                    source.unlink()
                    source.mkdir()
                elif kind == "staged only":
                    git(repo, "add", "src/token_count.py")
                with self.assertRaisesRegex(SystemExit, diagnostic):
                    self.helper["main_impl"]()
                self.assertFalse(sends)

    def test_source_context_rejects_nonrelative_paths_and_wrong_provenance(self):
        with self.committed_context_fixture() as (repo, sends, *_):
            capture = self.helper["capture_source_context"]
            commit = git(repo, "rev-parse", "HEAD").strip()
            for path in (str(repo / "src/token_count.py"), "../src/token_count.py", ""):
                with self.subTest(path=path), self.assertRaisesRegex(SystemExit, "repo-relative"):
                    capture(repo, path, commit)
            for ref in ("HEAD", "HEAD^", "0" * 40, git(repo, "rev-parse", "HEAD^{tree}").strip()):
                with self.subTest(ref=ref), self.assertRaises(SystemExit):
                    capture(repo, "src/token_count.py", ref)
            absent_commit = git(repo, "rev-parse", "HEAD^^").strip()
            with self.assertRaisesRegex(SystemExit, "absent from the reviewed commit"):
                capture(repo, "src/token_count.py", absent_commit)
            original = self.helper["read_git_source"]

            def corrupt(*args):
                return original(*args)._replace(content="wrong object bytes\n")

            with mock.patch.dict(capture.__globals__, {"read_git_source": corrupt}):
                with self.assertRaisesRegex(SystemExit, "do not match the committed blob"):
                    self.helper["main_impl"]()
            self.assertFalse(sends)

    def test_source_context_revalidation_rejects_stale_publication_and_later_passes(self):
        for role, timing in (
            *(("--source-context", timing) for timing in ("capture", "preparation", "review", "between passes")),
            ("--source-context-file", "review"), ("--source-context-file", "between passes"),
        ):
            with self.subTest(role=role, timing=timing), self.committed_context_fixture(role=role) as (repo, sends, out, _err):
                source = repo / "src/token_count.py"
                original_bytes = source.read_bytes()
                output = repo.parent / "result.json"

                def mutate():
                    info = source.stat()
                    source.write_bytes(original_bytes.replace(b"7", b"8"))
                    os.utime(source, ns=(info.st_atime_ns, info.st_mtime_ns))

                name = {"capture": "read_git_source", "preparation": "prepare_review_prompts"}.get(timing, "run_engine")
                original = self.helper["main_impl"].__globals__[name]

                def mutation(*args):
                    result = original(*args)
                    mutate()
                    return result

                patches = {name: mutation}
                if timing == "between passes":
                    prepare = self.helper["prepare_review_prompts"]
                    patches["prepare_review_prompts"] = lambda *args: prepare(*args) * 2
                with mock.patch.dict(self.helper["main_impl"].__globals__, patches), \
                        mock.patch.object(sys, "argv", [*sys.argv, "--json-output", str(output)]):
                    with self.assertRaisesRegex(SystemExit, "context changed|evidence changed"):
                        self.helper["main_impl"]()
                self.assertEqual(len(sends), int(timing in ("review", "between passes")))
                self.assertFalse(output.exists())
                self.assertNotIn("autoreview scoped-clean", out.getvalue())

    def test_source_context_rejects_anchored_and_resolved_external_paths_before_read(self):
        with self.committed_context_fixture() as (repo, _sends, *_):
            capture = self.helper["capture_source_context"]
            commit = git(repo, "rev-parse", "HEAD").strip()
            # Drive-relative and root-relative Windows paths are not absolute,
            # but joining them can discard the repository anchor.
            with mock.patch.dict(capture.__globals__, {"Path": PureWindowsPath}):
                for path in ("C:token_count.py", r"\src\token_count.py"):
                    with self.subTest(path=path), self.assertRaisesRegex(SystemExit, "repo-relative"):
                        capture(repo, path, commit)
            original_resolve = Path.resolve
            source = repo / "src/token_count.py"

            def resolve(path, *args, **kwargs):
                # A junction/reparse-point escape must not reach the content reader.
                return repo.parent / "outside.py" if path == source else original_resolve(path, *args, **kwargs)

            fingerprint = mock.Mock(side_effect=AssertionError("must not read an external file"))
            with mock.patch.object(Path, "resolve", resolve), \
                    mock.patch.dict(capture.__globals__, {"source_file_fingerprint": fingerprint}):
                with self.assertRaisesRegex(SystemExit, "inside the reviewed repository"):
                    capture(repo, "src/token_count.py", commit)
            fingerprint.assert_not_called()

    def test_source_context_revalidates_topology_before_send_and_publication(self):
        for change in ("replace", "replace parent", "leaf symlink", "parent symlink"):
            if "symlink" in change and os.name == "nt":
                continue
            for timing in ("preparation", "review"):
                with self.subTest(change=change, timing=timing), self.committed_context_fixture() as (repo, sends, *_):
                    source = repo / "src/token_count.py"
                    output = repo.parent / "result.json"
                    name = "prepare_review_prompts" if timing == "preparation" else "run_engine"
                    original = self.helper["main_impl"].__globals__[name]

                    def swap(*args):
                        result = original(*args)
                        if change == "replace":
                            replacement = repo.parent / "same.py"
                            replacement.write_bytes(source.read_bytes())
                            replacement.replace(source)
                        elif change == "replace parent":
                            source.parent.rename(repo.parent / "old-src")
                            source.parent.mkdir()
                            (repo.parent / "old-src/token_count.py").rename(source)
                        elif change == "leaf symlink":
                            destination = repo.parent / "same.py"
                            source.rename(destination)
                            source.symlink_to(destination)
                        else:
                            destination = repo.parent / "same-src"
                            source.parent.rename(destination)
                            source.parent.symlink_to(destination, target_is_directory=True)
                        return result

                    with mock.patch.dict(self.helper["main_impl"].__globals__, {name: swap}), \
                            mock.patch.object(sys, "argv", [*sys.argv, "--json-output", str(output)]):
                        with self.assertRaisesRegex(SystemExit, "evidence changed"):
                            self.helper["main_impl"]()
                    self.assertEqual(len(sends), int(timing == "review"))
                    self.assertFalse(output.exists())

    def test_source_context_file_stays_whole_in_every_pass_and_refuses_insufficient_capacity(self):
        content = ("# context \U0001f99e\r\n" * 300 + "tail without newline \t").encode()
        with self.committed_context_fixture(role="--source-context-file", content=content) as (repo, sends, *_):
            (repo / "source.md").write_text("selected change\n" * 4_000)
            git(repo, "commit", "-qam", "large selected change")
            captured = self.helper["branch_bundle"](repo, "HEAD^")
            record = self.helper["capture_source_context"](repo, "src/token_count.py", captured.commit)
            _, oid, mode = record.source.identity.split(":")
            block = self.helper["render_datasets"]([self.helper["ReviewDataset"](
                record.raw_path, content.decode(), provenance=(record.commit, oid, mode),
            )])
            with mock.patch.dict(self.helper["main_impl"].__globals__, {
                "MAX_REVIEW_PROMPT_BYTES": 30_000,
            }):
                self.assertEqual(self.helper["main_impl"](), 0)
            self.assertGreater(len(sends), 1)
            changes = []
            for prompt in sends:
                self.assertLessEqual(len(prompt.encode()), 30_000)
                self.assertEqual(prompt.count(block), 1)
                prefix, change = prompt.rsplit("\n\n# Change Bundle\n", 1)
                self.assertIn(block, prefix)
                self.assertIn("Source-context paths are not finding targets", prefix)
                changes.append(change)
            self.assertEqual("".join(changes), captured.text)
            sends.clear()
            evidence = self.helper["capture_source_context_inputs"](
                argparse.Namespace(source_context_file=[record.raw_path]), repo, captured,
                self.helper["EvidenceInputs"]("complete instructions", [
                    self.helper["ReviewDataset"]("large-evidence.txt", "partitionable evidence\n" * 3_000),
                ], []),
            )
            prompts = self.helper["prepare_review_prompts"](
                repo, "branch", "HEAD^", captured, evidence.prompt, evidence.datasets, 30_000,
            )
            self.assertTrue(all("Evidence batch:" in prompt for prompt in prompts))
            for prompt in prompts:
                self.assertLessEqual(len(prompt.encode()), 30_000)
                self.assertEqual(prompt.count(block), 1)
            with self.assertRaisesRegex(SystemExit, "--max-review-passes allows 1"):
                self.helper["check_review_plan"](argparse.Namespace(max_review_passes=1), prompts)
            self.assertFalse(sends)
            with mock.patch.dict(self.helper["main_impl"].__globals__, {
                "MAX_REVIEW_PROMPT_BYTES": len(content),
            }), self.assertRaisesRegex(SystemExit, "intact context leave too little room"):
                self.helper["main_impl"]()
            self.assertFalse(sends)

    def test_near_capacity_intact_source_context_keeps_complete_bounded_review(self):
        budget, remaining, pass_limit = 512_000, 3_000, 32
        path = "src/token_count.py"
        render = self.helper["render_review_prompt"]
        threshold = argparse.Namespace(max_priority="P0")
        with self.committed_context_fixture(
            "--max-review-passes", str(pass_limit), "--max-priority", "P0",
            role="--source-context-file", content=b"",
        ) as (repo, sends, *_):
            branch = self.helper["current_branch"](repo)

            def context_inputs(captured):
                return self.helper["capture_source_context_inputs"](
                    argparse.Namespace(source_context_file=[path]), repo, captured,
                    self.helper["EvidenceInputs"]("", [], []),
                )

            empty = context_inputs(self.helper["branch_bundle"](repo, "HEAD^"))
            fixed = render(
                branch, "branch", "HEAD^", self.helper["ReviewChunk"](""),
                self.helper["apply_finding_threshold_prompt"](threshold, empty.prompt),
                "", (999_999, 999_999),
            )
            line, tail = "# committed context \U0001f99e\r\n", "end of context \t"
            repeats, padding = divmod(
                budget - len(fixed.encode()) - remaining - len(tail.encode()), len(line.encode()),
            )
            content = line * repeats + "x" * padding + tail
            (repo / path).write_bytes(content.encode())
            git(repo, "add", "--", path)
            git(repo, "commit", "-qm", "intact source context")
            (repo / "source.md").write_text("small selected change\n")
            git(repo, "commit", "-qam", "small selected change")
            self.assertEqual(self.helper["main_impl"](), 0)
            self.assertEqual(len(sends), 1)
            self.assertNotIn("Oversized review bundle chunk:", sends[0])
            self.assertEqual(sends[0].count(content), 1)
            sends.clear()

            (repo / "source.md").write_bytes(
                ("changed = '\U0001f99e'\r\n" * 400 + "end of selected change \t").encode(),
            )
            git(repo, "commit", "-qam", "larger selected change")
            captured = self.helper["branch_bundle"](repo, "HEAD^")
            evidence = context_inputs(captured)
            extra = self.helper["apply_finding_threshold_prompt"](threshold, evidence.prompt)
            fixed = render(
                branch, "branch", "HEAD^", self.helper["ReviewChunk"](""),
                extra, "", (999_999, 999_999),
            )
            self.assertEqual(budget - len(fixed.encode()), remaining)
            self.assertGreater(len(captured.text.encode()), remaining)
            self.assertEqual(captured.paths, {"source.md"})
            self.assertFalse(captured.mixed or captured.images or evidence.datasets)
            self.assertEqual(len(evidence.files), 1)
            oid = git(repo, "rev-parse", f"HEAD:{path}").strip()
            self.assertIn(f"commit={captured.commit} blob={oid} mode=100644; context only", evidence.prompt)

            observed_render = mock.Mock(wraps=render)
            with mock.patch.dict(self.helper["main_impl"].__globals__, {"render_review_prompt": observed_render}), \
                    mock.patch.object(sys, "argv", [*sys.argv, "--max-review-passes", "1"]), \
                    self.assertRaisesRegex(SystemExit, "no reviewer was started"):
                self.helper["main_impl"]()
            self.assertFalse(sends)
            numbered = [call for call in observed_render.call_args_list
                        if len(call.args) == 7 and call.args[6] != (999_999, 999_999)]
            self.assertEqual(len(numbered), 0, "explicit pass budget must reject before duplicating intact context")
            self.assertEqual(self.helper["main_impl"](), 0)
            self.assertGreater(len(sends), 1)
            self.assertLessEqual(len(sends), pass_limit)
            changes = []
            for prompt in sends:
                self.assertLessEqual(len(prompt.encode()), budget)
                prefix, change = prompt.rsplit("\n\n# Change Bundle\n", 1)
                self.assertEqual(prefix.count(evidence.prompt), 1)
                self.assertIn("Finding threshold: report only P0.", prefix)
                self.assertIn("Source-context paths are not finding targets", prefix)
                self.assertNotIn("Evidence batch:", prefix)
                changes.append(change)
            self.assertEqual("".join(changes).encode(), captured.text.encode())
            self.assertEqual((repo / path).read_bytes(), content.encode())
            self.helper["verify_evidence"](repo, evidence.files)

    def test_source_context_partitioning_preserves_full_bytes_and_provenance(self):
        content = ("# context \U0001f99e\r\n" * 10_000 + "tail without newline \t").encode()
        with self.committed_context_fixture(content=content) as (repo, _sends, *_):
            captured = self.helper["branch_bundle"](repo, "HEAD^")
            evidence = self.helper["capture_source_context_inputs"](
                argparse.Namespace(source_context=["src/token_count.py"]), repo, captured,
                self.helper["EvidenceInputs"]("", [], []),
            )
            batches = self.helper["split_review_datasets"](evidence.datasets, 600)
            recovered = b""
            for batch in batches:
                self.assertLessEqual(len(self.helper["render_datasets"](batch).encode()), 600)
                for item in batch:
                    self.assertEqual(item.byte_offset, len(recovered))
                    self.assertEqual(item.provenance, evidence.datasets[0].provenance)
                    recovered += item.content.encode()
            self.assertEqual(recovered, content)
            prepare = self.helper["prepare_review_prompts"]
            prompts = prepare(repo, "branch", "HEAD^", captured, "complete instructions", evidence.datasets, 30_000)
            self.assertGreater(len(prompts), 1)
            recovered = []
            for prompt in prompts:
                self.assertLessEqual(len(prompt.encode()), 30_000)
                self.assertIn("complete instructions", prompt)
                self.assertIn("Source-context paths are not finding targets", prompt)
                self.assertIn(f"commit={captured.commit}", prompt)
                self.assertIn("[Committed source:", prompt)
                prefix, change = prompt.split("\n\n# Change Bundle\n", 1)
                self.assertEqual(change, captured.text)
                recovered.append(prefix.split("]\n", 2)[-1])
            # Fragment boundaries come from owned metadata, never source headings.
            self.assertEqual("".join(recovered).encode(), content)

    def test_source_context_sha256_empty_executable_blob(self):
        with tempfile.TemporaryDirectory() as tempdir:
            repo = Path(tempdir) / "repo"
            repo.mkdir()
            initialized = fixture_git(repo, "init", "-q", "--object-format=sha256", check=False,
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if initialized.returncode:
                self.skipTest("Git does not support SHA-256 repositories")
            git(repo, "config", "user.name", "Autoreview Test")
            git(repo, "config", "user.email", "autoreview@example.invalid")
            (repo / "token_count.py").write_bytes(b"")
            git(repo, "add", "token_count.py")
            git(repo, "update-index", "--chmod=+x", "token_count.py")
            git(repo, "commit", "-qm", "empty executable source")
            captured = self.helper["commit_bundle"](repo, "HEAD")
            record = self.helper["capture_source_context"](repo, "token_count.py", captured.commit)
            self.assertEqual(len(record.commit), 64)
            self.assertEqual(record.source.identity, "git:" + git(repo, "rev-parse", "HEAD:token_count.py").strip() + ":100755")
            self.assertEqual(record.source.content, "")
            self.helper["verify_evidence"](repo, [record])

    def test_source_context_dry_run_uses_blob_without_executable_conversion(self):
        for role in ("--source-context", "--source-context-file"):
            with self.subTest(role=role), self.committed_context_fixture("--dry-run", role=role) as (repo, sends, out, _err):
                converter = repo / "converter.py"
                marker = repo.parent / "converter-ran"
                converter.write_text(f"from pathlib import Path\nPath({str(marker)!r}).touch()\n")
                command = f'"{sys.executable}" "{converter}"'
                for key in ("clean", "smudge", "process"):
                    git(repo, "config", f"filter.test.{key}", command)
                git(repo, "config", "filter.test.required", "true")
                (repo / ".gitattributes").write_text("src/token_count.py filter=test\n")
                self.assertEqual(self.helper["main_impl"](), 0)
                self.assertIn("prompt: OK", out.getvalue())
                self.assertFalse(sends)
                self.assertFalse(marker.exists())

    def test_source_context_never_expands_finding_authority(self):
        for role in ("--source-context", "--source-context-file"):
            with self.subTest(role=role), self.committed_context_fixture(role=role) as (repo, _sends, *_):
                output = repo.parent / "report.json"
                finding = {
                    "title": "Context-only defect", "body": "This is outside the change.",
                    "priority": "P0", "confidence": 0.99, "category": "bug",
                    "code_location": {"file_path": "src/token_count.py", "line": 1},
                }
                report = {"findings": [finding], "overall_correctness": "patch is incorrect",
                          "overall_explanation": "Context-only observation", "overall_confidence": 0.9,
                          "review_completion": "complete"}
                with mock.patch.dict(self.helper["main_impl"].__globals__, {
                    "run_engine": lambda *_args: json.dumps(report),
                }), mock.patch.object(sys, "argv", [*sys.argv, "--json-output", str(output)]):
                    self.assertEqual(self.helper["main_impl"](), 2)
                result = json.loads(output.read_text())
                self.assertEqual(result["findings"], [])
                self.assertEqual(result["scope_rejected_findings"], [finding])
                self.assertEqual(result["review_status"], "incomplete")

    def test_preparation_reuses_untracked_capture_and_keeps_three_full_snapshots(self):
        for explicit in (False, True):
            options = ("--dataset", "note.md") if explicit else ()
            with self.subTest(explicit=explicit), self.preparation_fixture(*options) as (repo, sends, _out, err):
                (repo / "note.md").write_text("untracked evidence\n")
                read = mock.Mock(wraps=self.helper["file_bundle_snapshot"])
                fingerprint = mock.Mock(wraps=self.helper["source_file_fingerprint"])
                with mock.patch.dict(self.helper["main_impl"].__globals__, {
                    "file_bundle_snapshot": read, "source_file_fingerprint": fingerprint,
                }):
                    self.assertEqual(self.helper["main_impl"](), 0)
                # Explicit evidence has its own initial capture and three fresh
                # checks; finding membership never adds another content read.
                self.assertEqual(read.call_count, 5 if explicit else 1)
                self.assertEqual(fingerprint.call_count, 3 * 27)
                for index in range(24):
                    self.assertEqual(sum(call.args[0] == repo / f"unchanged-{index}.txt"
                                         for call in fingerprint.call_args_list), 3)
                self.assertNotIn("note.md", err.getvalue())
                self.assertNotIn("untracked evidence", err.getvalue())

    def test_ignored_evidence_change_during_capture_refuses_send(self):
        with self.preparation_fixture("--dataset", "evidence/note.md") as (repo, sends, *_):
            original = self.helper["local_bundle"]

            def build(*args, **kwargs):
                captured = original(*args, **kwargs)
                (repo / "evidence/note.md").write_text("changed evidence\n")
                return captured

            with mock.patch.dict(self.helper["main_impl"].__globals__, {"local_bundle": build}):
                with self.assertRaisesRegex(SystemExit, "evidence changed"):
                    self.helper["main_impl"]()
            self.assertFalse(sends)

    def test_preparation_progress_precedes_snapshot(self):
        with self.preparation_fixture() as (_repo, sends, _out, err):
            def snapshot(*_args, **_kwargs):
                self.assertIn("preparation: initial source snapshot", err.getvalue())
                self.assertFalse(sends)
                raise KeyboardInterrupt

            with mock.patch.dict(self.helper["main_impl"].__globals__, {"source_tree_snapshot": snapshot}):
                with self.assertRaises(KeyboardInterrupt):
                    self.helper["main_impl"]()

    def test_dry_run_reuses_capture_without_whole_tree_snapshots(self):
        with self.preparation_fixture("--dry-run", "--dataset", "evidence/note.md") as (_repo, sends, *_):
            snapshot = mock.Mock(side_effect=AssertionError("dry run must not sweep the checkout"))
            with mock.patch.dict(self.helper["main_impl"].__globals__, {"source_tree_snapshot": snapshot}):
                self.assertEqual(self.helper["main_impl"](), 0)
            snapshot.assert_not_called()
            self.assertFalse(sends)

    def test_evidence_mutations_refuse_stale_publication_and_later_passes(self):
        for tracked in (False, True):
            for timing in ("construction", "preparation", "review", "between passes"):
                with self.subTest(tracked=tracked, timing=timing), self.preparation_fixture(
                    "--prompt-file", "evidence/note.md", "--dataset", "evidence/note.md",
                ) as (repo, sends, out, _err):
                    evidence = repo / "evidence/note.md"
                    if tracked:
                        git(repo, "add", "-f", "evidence/note.md")
                        git(repo, "commit", "-qm", "unchanged evidence")
                    frozen = evidence.read_bytes()
                    original_engine = self.helper["main_impl"].__globals__["run_engine"]
                    original_build = self.helper["build_bundle"]
                    output = repo.parent / "report.json"

                    def mutate():
                        info = evidence.stat()
                        evidence.write_bytes(frozen.replace(b"frozen", b"edited"))
                        os.utime(evidence, ns=(info.st_atime_ns, info.st_mtime_ns))

                    def engine(*args):
                        result = original_engine(*args)
                        if timing in ("review", "between passes"):
                            mutate()
                        return result

                    def build(*args):
                        result = original_build(*args)
                        if timing == "construction":
                            mutate()
                        return result

                    patches = {"run_engine": engine, "build_bundle": build}
                    if timing == "preparation":
                        original_prepare = self.helper["prepare_review_prompts"]
                        def prepare(*args):
                            result = original_prepare(*args)
                            mutate()
                            return result
                        patches["prepare_review_prompts"] = prepare
                    if timing == "between passes":
                        original_prepare = self.helper["prepare_review_prompts"]
                        patches["prepare_review_prompts"] = lambda *args: original_prepare(*args) * 2
                    with mock.patch.dict(self.helper["main_impl"].__globals__, patches), \
                            mock.patch.object(sys, "argv", [*sys.argv, "--json-output", str(output)]):
                        with self.assertRaisesRegex(SystemExit, "evidence changed"):
                            self.helper["main_impl"]()
                    self.assertEqual(len(sends), int(timing in ("review", "between passes")))
                    if sends:
                        self.assertEqual(sends[0].count(frozen.decode()), 2)
                    self.assertFalse(output.exists())
                    self.assertNotIn("autoreview scoped-clean", out.getvalue())

    def test_evidence_topology_changes_with_identical_bytes_refuse_send(self):
        for change in ("delete", "replace", "leaf symlink", "ancestor symlink"):
            if "symlink" in change and os.name == "nt":
                continue
            with self.subTest(change=change), self.preparation_fixture(
                "--dataset", "evidence/tree/note.md",
            ) as (repo, sends, *_):
                evidence = repo / "evidence/tree/note.md"
                evidence.parent.mkdir()
                (repo / "evidence/note.md").rename(evidence)
                snapshot = self.helper["source_tree_snapshot"](repo)
                original = self.helper["build_bundle"]

                def build(*args):
                    result = original(*args)
                    if change == "delete":
                        evidence.unlink()
                    elif change == "replace":
                        replacement = repo.parent / "replacement.md"
                        replacement.write_bytes(evidence.read_bytes())
                        replacement.replace(evidence)
                    elif change == "leaf symlink":
                        evidence.rename(evidence.with_name("same.md"))
                        evidence.symlink_to("same.md")
                    else:
                        evidence.parent.rename(evidence.parent.with_name("same-tree"))
                        evidence.parent.symlink_to("same-tree", target_is_directory=True)
                    # All mutations stay inside ignored evidence: the ordinary
                    # whole-tree guard cannot account for this failure.
                    self.assertEqual(self.helper["source_tree_snapshot"](repo), snapshot)
                    return result

                with mock.patch.dict(self.helper["main_impl"].__globals__, {"build_bundle": build}):
                    with self.assertRaisesRegex(SystemExit, "evidence changed"):
                        self.helper["main_impl"]()
                self.assertFalse(sends)

    def test_duplicate_evidence_keeps_exact_frozen_bytes_across_passes(self):
        with self.preparation_fixture(
            "--prompt-file", "evidence/note.md", "--dataset", "evidence/note.md",
            "--dataset", "./evidence/note.md",
        ) as (repo, sends, *_):
            evidence = (repo / "evidence/note.md").read_bytes().decode()
            original = self.helper["prepare_review_prompts"]
            with mock.patch.dict(self.helper["main_impl"].__globals__, {
                "prepare_review_prompts": lambda *args: original(*args) * 2,
            }):
                self.assertEqual(self.helper["main_impl"](), 0)
            self.assertEqual(len(sends), 2)
            for prompt in sends:
                self.assertEqual(prompt.count(evidence), 2)

    def test_equal_evidence_at_different_paths_retains_provenance(self):
        with self.preparation_fixture(
            "--dataset", "evidence/note.md", "--dataset", "evidence/copy.md",
        ) as (repo, sends, *_):
            (repo / "evidence/copy.md").write_bytes((repo / "evidence/note.md").read_bytes())
            self.assertEqual(self.helper["main_impl"](), 0)
            self.assertIn(f"# Dataset: {Path('evidence/note.md')}", sends[0])
            self.assertIn(f"# Dataset: {Path('evidence/copy.md')}", sends[0])

    def test_explicit_pass_budget_rejects_entire_plan_before_any_reviewer(self):
        for dry_run in (False, True):
            options = ("--dry-run",) if dry_run else ()
            with self.subTest(dry_run=dry_run), self.preparation_fixture(
                "--max-review-passes", "1", *options,
            ) as (_repo, sends, out, _err):
                original = self.helper["prepare_review_prompts"]
                with mock.patch.dict(self.helper["main_impl"].__globals__, {
                    "prepare_review_prompts": lambda *args: original(*args) * 2,
                }):
                    if dry_run:
                        self.assertEqual(self.helper["main_impl"](), 1)
                        self.assertIn("no reviewer was started", out.getvalue())
                    else:
                        with self.assertRaisesRegex(SystemExit, "no reviewer was started"):
                            self.helper["main_impl"]()
                self.assertIn("review plan: 2 passes;", out.getvalue())
                self.assertFalse(sends)

    def test_usage_survives_later_failed_pass_without_publishing_partial_report(self):
        for failure in (None, "invalid", "timeout"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as output_dir, self.preparation_fixture(
                "--json-output", str(Path(output_dir) / "report.json"),
                "--status-output", str(Path(output_dir) / "status.json"),
            ) as (_repo, sends, out, _err):
                original_plan = self.helper["prepare_review_prompts"]
                original_engine = self.helper["main_impl"].__globals__["run_engine"]

                def engine(args, repo, prompt):
                    failed = bool(sends) and failure is not None
                    event = json.dumps({"type": "turn.completed", "usage": {
                        "input_tokens": 100, "cached_input_tokens": 20,
                        "output_tokens": 30, "reasoning_output_tokens": 10,
                    }})
                    self.helper["record_codex_usage"](args, "" if failed else event, completed=not failed)
                    result = original_engine(args, repo, prompt)
                    if failed and failure == "timeout":
                        process = self.helper["TimedOutEngineProcess"]([], 124, "", "timed out")
                        raise self.helper["ReviewerUnavailable"]("timed out", result=process)
                    return "invalid report" if failed else result

                with mock.patch.dict(self.helper["main_impl"].__globals__, {
                    "prepare_review_prompts": lambda *args: original_plan(*args) * 2,
                    "run_engine": engine,
                }):
                    if failure:
                        with self.assertRaises(self.helper["ReviewerUnavailable"]):
                            self.helper["main_impl"]()
                    else:
                        self.assertEqual(self.helper["main_impl"](), 0)
                status = json.loads((Path(output_dir) / "status.json").read_text())
                self.assertEqual(status["usage"]["attempts"], 2)
                self.assertEqual(status["usage"]["complete"], failure is None)
                self.assertEqual(status["usage"]["unknown_attempts"], 1 if failure else 0)
                self.assertEqual(status["usage"]["tokens"]["input_tokens"], 100 if failure else 200)
                report = Path(output_dir) / "report.json"
                if failure:
                    self.assertEqual(status["status"], "reviewer_unavailable")
                    self.assertFalse(report.exists())
                else:
                    self.assertEqual(json.loads(report.read_text())["usage"], status["usage"])
                self.assertIn("review usage:", out.getvalue())

    def test_tracked_source_permission_never_authorizes_evidence(self):
        with self.preparation_fixture("--dataset", "private/source.swift") as (repo, sends, *_):
            source = repo / "private/source.swift"
            source.parent.mkdir()
            source.write_text("let safe = true\n")
            git(repo, "add", "private/source.swift")
            self.assertIn("private/source.swift", self.helper["local_bundle"](repo).paths)
            with self.assertRaisesRegex(SystemExit, "sensitive --dataset"):
                self.helper["main_impl"]()
            self.assertFalse(sends)

    def test_unrelated_same_size_restored_mtime_mutation_is_still_guarded(self):
        for timing in ("construction", "review"):
            with self.subTest(timing=timing), self.preparation_fixture() as (repo, sends, *_):
                name = "build_bundle" if timing == "construction" else "run_engine"
                original = self.helper["main_impl"].__globals__[name]

                def mutate(*args):
                    result = original(*args)
                    source = repo / "unchanged-0.txt"
                    info = source.stat()
                    source.write_text("new\n")
                    os.utime(source, ns=(info.st_atime_ns, info.st_mtime_ns))
                    return result

                with mock.patch.dict(self.helper["main_impl"].__globals__, {name: mutate}):
                    if timing == "construction":
                        with self.assertRaisesRegex(SystemExit, "source changed"):
                            self.helper["main_impl"]()
                        self.assertFalse(sends)
                    else:
                        self.assertEqual(self.helper["main_impl"](), 1)

    def test_preparation_ticker_rate_limit_counts_and_cleanup(self):
        progress_type = self.helper["PreparationProgress"]
        clock = [100.0]
        stderr = io.StringIO()
        with mock.patch.object(time, "monotonic", side_effect=lambda: clock[0]), \
                contextlib.redirect_stderr(stderr):
            progress = progress_type("initial source snapshot")
            progress.advance(files=3, bytes=45)
            for now in (100, 114, 115, 115, 129, 130):
                clock[0] = now
                progress._report()
        self.assertEqual(stderr.getvalue().splitlines(), [
            "preparation: initial source snapshot elapsed=15s files=3 bytes=45",
            "preparation: initial source snapshot elapsed=30s files=3 bytes=45",
        ])
        for error in (None, ValueError, KeyboardInterrupt, self.helper["EngineInterrupted"]):
            with self.subTest(error=error), contextlib.redirect_stderr(io.StringIO()):
                progress = progress_type("bundle preparation")
                try:
                    with progress:
                        self.assertTrue(progress.thread.is_alive())
                        if error:
                            raise error(130)
                except BaseException as exc:
                    self.assertIsInstance(exc, error)
                self.assertFalse(progress.thread.is_alive())
                self.assertTrue(progress.stopped.is_set())

    def test_hash_progress_advances_inside_large_file_without_path_output(self):
        with tempfile.TemporaryDirectory() as tempdir:
            source = Path(tempdir) / "do-not-print-this-name.txt"
            source.write_bytes(b"x" * (2 * 1024 * 1024 + 1))
            progress = self.helper["PreparationProgress"]("initial source snapshot")
            original = os.read
            counts = []

            def read(*args):
                counts.append(progress.bytes)
                return original(*args)

            with mock.patch.object(os, "read", side_effect=read):
                self.helper["source_file_fingerprint"](source, progress)
            self.assertEqual(counts, [0, 1024 * 1024, 2 * 1024 * 1024, source.stat().st_size])

    def test_preparation_ticker_reports_while_caller_is_blocked(self):
        stderr = io.StringIO()
        # An exact clock origin keeps the 15-second boundary independent of host float precision.
        with mock.patch.object(time, "monotonic", return_value=100.0):
            progress = self.helper["PreparationProgress"]("bundle preparation")
        progress.stopped = mock.Mock()
        progress.stopped.wait.side_effect = [False, True]
        with mock.patch.object(time, "monotonic", return_value=progress.started + 15), \
                contextlib.redirect_stderr(stderr), mock.patch.object(stderr, "flush") as flush:
            with progress:
                progress.thread.join()
            self.assertEqual(flush.call_count, 2)
        self.assertEqual(progress.stopped.wait.call_args_list, [mock.call(15), mock.call(15)])
        self.assertIn("elapsed=15s files=0 bytes=0", stderr.getvalue())
        self.assertFalse(progress.thread.is_alive())

    def test_bundle_ref_pinning_keeps_patch_and_membership_coherent(self):
        for target in ("branch", "commit"):
            with self.subTest(target=target), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                (repo / "base.md").write_text("base\n")
                git(repo, "add", ".")
                git(repo, "commit", "-qm", "base")
                base = git(repo, "rev-parse", "HEAD").strip()
                git(repo, "branch", "moving-base")
                (repo / "task.md").write_text("task change\n")
                git(repo, "add", ".")
                git(repo, "commit", "-qm", "task")
                head = git(repo, "rev-parse", "HEAD").strip()
                original = self.helper["git"]

                def moving_git(repo, *args, **kwargs):
                    result = original(repo, *args, **kwargs)
                    if "--patch" in args:
                        git(repo, "update-ref", "refs/heads/moving-base", head)
                        git(repo, "update-ref", "HEAD", base)
                    return result

                with mock.patch.dict(self.helper["build_bundle"].__globals__, {"git": moving_git}):
                    captured = self.helper["build_bundle"](repo, target, "moving-base", "HEAD")
                self.assertEqual(captured.paths, {"task.md"})
                self.assertIn("+task change", captured.text)
                self.assertEqual(captured.commit, head)


    def test_local_bundle_preserves_boundary_when_sensitive_diff_is_omitted(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            path = repo / ".env"
            path.write_text("TOKEN=placeholder\n", encoding="utf-8")
            git(repo, "add", path.name)
            git(repo, "commit", "-q", "-m", "base")
            path.write_text("TOKEN=changed-placeholder\n", encoding="utf-8")
            git(repo, "add", path.name)

            bundle = self.helper["local_bundle"](repo).text

            self.assertIn(self.helper["REVIEW_SECURITY_OMISSION"], bundle)

    def test_powershell_harness_exposes_recognized_engines(self) -> None:
        harness = SCRIPT.with_name("test-review-harness.ps1").read_text(encoding="utf-8")

        self.assertIn("[ValidateSet('codex', 'claude', 'amp', 'pi', 'kimi')]", harness)

    def test_local_bundle_omits_sensitive_untracked_file_without_blocking(self) -> None:
        for rel in (".env", "tokens/session.dat", "secrets/local.py"):
            with self.subTest(rel=rel), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                path = repo / rel
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text("placeholder=true\n", encoding="utf-8")
                (repo / "review.py").write_text("print('review me')\n", encoding="utf-8")

                bundle = self.helper["local_bundle"](repo).text

                self.assertIn("# Review Input Omissions", bundle)
                self.assertIn(self.helper["REVIEW_SECURITY_OMISSION"], bundle)
                self.assertNotIn(rel, bundle)
                self.assertNotIn("placeholder=true", bundle)
                self.assertIn("print('review me')", bundle)

    def test_large_binary_and_non_utf8_tails_refuse_input_capture(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            path = repo / "source.txt"
            for bad, reason in ((b"\0", "binary file"), (b"\xff", "non-UTF-8 file")):
                path.write_bytes(b"safe context\n" * 16_000 + bad)
                with self.subTest(reason=reason):
                    with self.assertRaisesRegex(SystemExit, reason):
                        self.helper["local_bundle"](repo)
                    for label in ("--prompt-file", "--dataset"):
                        with self.subTest(label=label), self.assertRaisesRegex(SystemExit, reason):
                            self.helper["validate_evidence_file"](repo, "source.txt", label)

    def test_local_bundle_rejects_non_utf8_untracked_text(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "latin.py").write_bytes(b"print('caf\xe9')\n")

            with self.assertRaisesRegex(SystemExit, "non-UTF-8 file"):
                self.helper["local_bundle"](repo)

    def test_local_bundle_uses_validated_untracked_snapshot(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "notes.txt").write_text("review me\n", encoding="utf-8")
            original_read_file_bytes = self.helper["read_file_bytes"]
            reads = 0

            def read_once(path: Path) -> bytes:
                nonlocal reads
                reads += 1
                if reads > 1:
                    raise AssertionError("untracked file was reopened after validation")
                return original_read_file_bytes(path)

            with mock.patch.dict(
                self.helper["local_bundle"].__globals__,
                {"read_file_bytes": read_once},
            ):
                bundle = self.helper["local_bundle"](repo).text

            expected_record = json.dumps("review me" + os.linesep)
            self.assertIn(
                '# Untracked File\npath: "notes.txt"\n'
                f"source-line 1: {expected_record}",
                bundle,
            )
            self.assertEqual(reads, 1)

    @contextlib.contextmanager
    def nested_worktree_fixture(self, *, linked_root=False, name="scratch/review branch"):
        with self.preparation_fixture() as (main, sends, out, err):
            repo = main
            if linked_root:
                repo = main.parent / "reviewed checkout"
                git(main, "worktree", "add", "--detach", str(repo), "HEAD")
                (repo / "source.md").write_text("outer linked change\n", encoding="utf-8")
            child = repo / name
            git(main, "worktree", "add", "--detach", str(child), "HEAD")
            yield repo, child, sends, out, err

    def test_nested_worktree_keeps_neighboring_untracked_files_in_review(self):
        names = ["scratch/review branch"]
        if os.name != "nt":
            names.append("scratch/review\nbranch")
        for name in names:
            with self.subTest(name=name), self.nested_worktree_fixture(name=name) as (
                repo, child, sends, _out, _err,
            ):
                ordinary = {
                    ".worktrees/notes.md": "OUTER_WORKTREE_DIRECTORY_NOTE\n",
                    f"{name}-copy/notes.md": "OUTER_PREFIX_NEIGHBOR_NOTE\n",
                }
                for rel, content in ordinary.items():
                    path = repo / rel
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(content, encoding="utf-8")
                (child / "source.md").write_text("CHILD_SOURCE_NOT_REVIEWED\n", encoding="utf-8")
                (child / "child-only.md").write_text("CHILD_UNTRACKED_NOT_REVIEWED\n", encoding="utf-8")

                captured = self.helper["local_bundle"](repo)
                self.assertEqual(captured.paths, {"source.md", *ordinary})
                self.assertEqual(self.helper["main_impl"](), 0)
                for pack in sends:
                    for marker in ordinary.values():
                        self.assertIn(marker.strip(), pack)
                    self.assertNotIn("CHILD_SOURCE_NOT_REVIEWED", pack)
                    self.assertNotIn("CHILD_UNTRACKED_NOT_REVIEWED", pack)

    def test_nested_worktree_alone_does_not_select_local_review(self):
        with self.nested_worktree_fixture() as (repo, child, *_):
            git(repo, "commit", "-qam", "finish outer changes")
            git(repo, "branch", "-M", "main")
            (child / "source.md").write_text("child dirty\n", encoding="utf-8")
            (child / "new.md").write_text("child untracked\n", encoding="utf-8")

            self.assertFalse(self.helper["is_dirty"](repo))
            with self.assertRaisesRegex(SystemExit, "no review target: clean main checkout"):
                self.helper["choose_target"](repo, "auto", None)
            with self.assertRaisesRegex(SystemExit, "no local changes to review"):
                self.helper["local_bundle"](repo)

            (repo / ".worktrees").mkdir()
            (repo / ".worktrees/notes.md").write_text("ordinary note\n", encoding="utf-8")
            self.assertEqual(self.helper["choose_target"](repo, "auto", None), ("local", None))
            self.assertEqual(self.helper["local_bundle"](repo).paths, {".worktrees/notes.md"})

    def test_nested_worktree_snapshot_tracks_boundary_not_child_state(self):
        for linked_root in (False, True):
            with self.subTest(linked_root=linked_root), self.nested_worktree_fixture(
                linked_root=linked_root,
            ) as (repo, child, *_):
                self.assertEqual(self.helper["local_bundle"](repo).paths, {"source.md"})
                before = self.helper["source_tree_snapshot"](repo)
                (child / "source.md").write_text("child staged change\n", encoding="utf-8")
                git(child, "add", "source.md")
                self.assertEqual(self.helper["source_tree_snapshot"](repo), before)
                git(child, "commit", "-qm", "child-only commit")
                (child / "untracked.md").write_text("child-only file\n", encoding="utf-8")
                self.assertEqual(self.helper["source_tree_snapshot"](repo), before)

                source = repo / "source.md"
                original = source.read_bytes()
                source.write_bytes(original + b"outer mutation\n")
                self.assertNotEqual(self.helper["source_tree_snapshot"](repo), before)
                source.write_bytes(original)
                self.assertEqual(self.helper["source_tree_snapshot"](repo), before)

                pointer = child / ".git"
                replacement = child / "replacement-pointer"
                replacement.write_bytes(pointer.read_bytes())
                os.replace(replacement, pointer)
                self.assertNotEqual(self.helper["source_tree_snapshot"](repo), before)

    def test_nested_worktree_cannot_hide_indexed_descendants_or_base_readditions(self):
        with self.nested_worktree_fixture() as (repo, child, *_):
            source = child / "source.md"
            rel = source.relative_to(repo).as_posix()
            oid = git(repo, "hash-object", "-w", str(source)).strip()
            git(repo, "update-index", "--add", "--cacheinfo", f"100644,{oid},{rel}")
            source.write_text("PARENT_INDEXED_DESCENDANT\n", encoding="utf-8")
            captured = self.helper["local_bundle"](repo)
            self.assertIn(rel, captured.paths)
            self.assertIn("PARENT_INDEXED_DESCENDANT", captured.text)
            before = self.helper["source_tree_snapshot"](repo)
            source.write_text("PARENT_INDEXED_DESCENDANT_CHANGED\n", encoding="utf-8")
            self.assertNotEqual(self.helper["source_tree_snapshot"](repo), before)

            git(repo, "commit", "-qm", "parent owns a descendant")
            base = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "update-index", "--force-remove", rel)
            source.write_text("RE_ADDED_PARENT_SOURCE\n", encoding="utf-8")
            for base_ref in (None, base):
                with self.subTest(base=base_ref), self.assertRaisesRegex(
                    SystemExit, "cannot safely include untracked file.*not a regular file",
                ):
                    self.helper["local_bundle"](repo, base_ref)
            git(repo, "commit", "-qm", "remove parent index entry")
            with self.assertRaisesRegex(
                SystemExit, "cannot safely include untracked file.*not a regular file",
            ):
                self.helper["local_bundle"](repo, base)

    def test_nested_worktree_exclusion_rejects_unowned_repository_boundaries(self):
        for kind in ("standalone", "foreign", "fake", "alias", "mismatched", "unregistered-admin"):
            with self.subTest(kind=kind), self.preparation_fixture() as (repo, *_):
                child = repo / "scratch" / "unowned boundary"
                child.parent.mkdir()
                if kind == "foreign":
                    foreign = repo.parent / "foreign"
                    foreign.mkdir()
                    git(foreign, "init", "-q")
                    git(foreign, "commit", "--allow-empty", "-qm", "foreign root")
                    git(foreign, "worktree", "add", "--detach", str(child), "HEAD")
                elif kind == "unregistered-admin":
                    git(repo, "worktree", "add", "--detach", str(child), "HEAD")
                    registered = Path(git(child, "rev-parse", "--absolute-git-dir").strip())
                    common = Path(git(repo, "rev-parse", "--absolute-git-dir").strip())
                    copied = repo.parent / "unregistered-admin"
                    shutil.copytree(registered, copied)
                    (copied / "commondir").write_text(f"{common}\n", encoding="utf-8")
                    (copied / "gitdir").write_text(f"{child / '.git'}\n", encoding="utf-8")
                    (child / ".git").unlink()
                    (child / ".git").write_text(f"gitdir: {copied}\n", encoding="utf-8")
                    self.assertEqual(
                        Path(git(child, "rev-parse", "--git-common-dir").strip()).resolve(),
                        common.resolve(),
                    )
                elif kind in {"alias", "mismatched"}:
                    owner = repo / "registered owner"
                    git(repo, "worktree", "add", "--detach", str(owner), "HEAD")
                    if kind == "mismatched":
                        git(repo, "worktree", "add", "--detach", str(child), "HEAD")
                        (child / ".git").unlink()
                    else:
                        child.mkdir()
                    (child / ".git").write_bytes((owner / ".git").read_bytes())
                else:
                    child.mkdir()
                    if kind == "standalone":
                        git(child, "init", "-q")
                        git(child, "commit", "--allow-empty", "-qm", "standalone root")
                    else:
                        (child / ".git").write_text(f"gitdir: {repo / '.git'}\n", encoding="utf-8")
                (child / "ordinary.md").write_text("must not silently disappear\n", encoding="utf-8")

                with self.assertRaisesRegex(
                    SystemExit, "cannot safely include untracked file.*not a regular file",
                ):
                    self.helper["local_bundle"](repo)

    def test_nested_worktree_validation_keeps_parent_git_trust_anchor(self):
        with self.nested_worktree_fixture() as (repo, _child, *_):
            hostile_bin = repo / "host-bin"
            hostile_bin.mkdir()
            marker = repo.parent / "hostile-git-executed"
            write_executable(
                hostile_bin / "git",
                "#!/usr/bin/env python3\nfrom pathlib import Path\n"
                f"Path({str(marker)!r}).write_text('executed')\nraise SystemExit(91)\n",
            )
            exclude = repo / ".git/info/exclude"
            with exclude.open("a", encoding="utf-8") as stream:
                stream.write("\nhost-bin/\n")
            with mock.patch.dict(os.environ, {
                "PATH": f"{hostile_bin}{os.pathsep}{os.environ.get('PATH', '')}",
            }):
                self.assertEqual(self.helper["local_bundle"](repo).paths, {"source.md"})
                self.helper["source_tree_snapshot"](repo)
            self.assertFalse(marker.exists())

    def test_local_base_reviews_resolved_merge_without_upstream_binary(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = repo / "source.txt"
            source.write_bytes(b"common\nretained line\n")
            git(repo, "add", "source.txt")
            git(repo, "commit", "-q", "-m", "base")
            common = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "checkout", "-q", "-b", "incoming")
            (repo / "proof.png").write_bytes(b"\x89PNG\r\n\0upstream-proof")
            source.write_bytes(b"upstream\nretained line\n")
            git(repo, "add", "source.txt", "proof.png")
            git(repo, "commit", "-q", "-m", "upstream")
            incoming = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "checkout", "-q", "-b", "task", common)
            source.write_bytes(b"task\nretained line\n")
            (repo / "committed.txt").write_bytes(b"committed task change\n")
            git(repo, "add", "source.txt", "committed.txt")
            git(repo, "commit", "-q", "-m", "task")
            with self.assertRaises(subprocess.CalledProcessError):
                git(repo, "merge", "--no-ff", "--no-commit", "incoming")
            self.assertEqual(git(repo, "rev-parse", "MERGE_HEAD").strip(), incoming)
            source.write_bytes(b"resolved staged task\n")
            git(repo, "add", "source.txt")
            self.assertEqual(git(repo, "diff", "--name-only", "--diff-filter=U").strip(), "")
            source.write_bytes(b"resolved staged task\nretained line\nunstaged task\n")
            (repo / "notes.md").write_bytes(b"untracked task note\n")
            # Review reads ignore host Git settings, including Windows autocrlf.
            # Expected patches must use the same protected Git policy.
            staged = self.helper["git"](repo, "diff", *self.helper["SAFE_DIFF_FLAGS"], "--cached", incoming)
            unstaged = self.helper["git"](repo, "diff", *self.helper["SAFE_DIFF_FLAGS"])
            sent: list[str] = []
            report = {
                "findings": [{
                    "title": "Task change finding",
                    "body": "The committed task change remains in the selected review scope.",
                    "priority": "P0",
                    "confidence": 0.99,
                    "category": "bug",
                    "code_location": {"file_path": "committed.txt", "line": 1},
                }],
                "overall_correctness": "patch is incorrect",
                "overall_explanation": "Task change finding.",
                "overall_confidence": 0.99,
            }

            def run_engine(_args, _repo, prompt):
                sent.append(prompt)
                return json.dumps({**report, "review_completion": "complete"})

            main = self.helper["main_impl"]
            with mock.patch.dict(main.__globals__, {
                "repo_root": lambda: repo,
                "run_engine": run_engine,
                "resolve_engine_binary": lambda _reviewer, _repo: (True, None),
            }):
                for dry_run in (False, True):
                    argv = [str(SCRIPT), "--engine", "codex", "--mode", "local", "--base", "incoming"]
                    if dry_run:
                        argv.append("--dry-run")
                    with mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(io.StringIO()):
                        self.assertEqual(main(), 0 if dry_run else 1)

            self.assertEqual(len(sent), 1)
            self.assertIn(f"# Staged Diff\nbase: {incoming}", sent[0])
            self.assertIn(staged.rstrip(), sent[0])
            self.assertIn(unstaged.rstrip(), sent[0])
            self.assertIn("-retained line", sent[0])
            self.assertIn("+retained line", sent[0])
            self.assertIn('path: "notes.md"', sent[0])
            self.assertIn("untracked task note", sent[0])
            self.assertNotIn("diff --git a/proof.png", sent[0])
            self.assertEqual(
                self.helper["local_bundle"](repo, incoming).paths,
                {"source.txt", "committed.txt", "notes.md"},
            )
            for mode in ("local", "uncommitted", "auto"):
                self.assertEqual(self.helper["choose_target"](repo, mode, "incoming"), ("local", incoming))
            self.assertEqual(self.helper["choose_target"](repo, "local", None), ("local", None))
            with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                self.helper["local_bundle"](repo)

    @contextlib.contextmanager
    def advanced_local_base(self, *, mixed=False):
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            git(repo, "config", "core.autocrlf", "false")
            names = ["staged.txt", "unstaged.txt", "deleted-index.txt", "deleted-working.txt"]
            if mixed:
                names.append("mixed.txt")
            for name in names:
                (repo / name).write_bytes(b"base\n")
            (repo / ".gitignore").write_bytes(b"evidence/\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "old head")
            old_head = git(repo, "rev-parse", "HEAD").strip()
            upstream = repo / "upstream"
            upstream.mkdir()
            for number in range(1800):
                (upstream / f"{number:04d}-{'baseline-' * 18}.txt").write_bytes(b"upstream\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "advanced base")
            base = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "branch", "review-base")
            git(repo, "reset", "--soft", old_head)
            (repo / "staged.txt").write_bytes(b"staged candidate\n")
            (repo / "added.txt").write_bytes(b"added candidate\n")
            git(repo, "add", "staged.txt", "added.txt")
            git(repo, "rm", "-q", "deleted-index.txt")
            (repo / "unstaged.txt").write_bytes(b"unstaged candidate\n")
            (repo / "deleted-working.txt").unlink()
            (repo / "notes.txt").write_bytes(b"untracked candidate\n")
            if mixed:
                (repo / "mixed.txt").write_bytes(b"INDEX-only defect\n")
                git(repo, "add", "mixed.txt")
                (repo / "mixed.txt").write_bytes(b"base\n")
            yield root, repo, base, old_head

    def test_local_status_preserves_diff_codes_and_quotes_paths(self) -> None:
        # Raw no-renames transitions, including deletion/re-addition and type changes.
        staged = ":100644 000000 aaaa 0000 D\0old name.txt\0:100644 120000 aaaa bbbb T\0link.txt\0"
        unstaged = ":120000 120000 bbbb 0000 M\0link.txt\0"
        untracked = ["old name.txt", 'line\n\t"雪.txt']
        status = self.helper["local_status"](staged, unstaged, untracked)
        self.assertEqual(status.splitlines()[1:], [
            'TM "link.txt"', 'D  "old name.txt"', '?? "old name.txt"',
            "?? " + json.dumps(untracked[1]),
        ])
        self.assertEqual(self.helper["local_status"](staged, unstaged, untracked, redact=True),
                         self.helper["REVIEW_SECURITY_OMISSION"])

    def test_local_status_matches_captured_base_index_and_working_transitions(self) -> None:
        with self.advanced_local_base(mixed=True) as (_root, repo, base, old_head):
            head_status = git(repo, "status", "--short", "--untracked-files=no")
            self.assertGreater(len(head_status.encode()), 300_000)
            before = self.helper["source_tree_snapshot"](repo)
            captured = self.helper["local_bundle"](repo, "review-base")
            status = captured.text.split("# Git Status\n\n", 1)[1].split("\n\n# Staged Diff", 1)[0]
            self.assertNotIn("upstream/", status)
            self.assertIn("base -> index", status)
            self.assertIn("index -> working_tree", status)
            for line in ('A  "added.txt"', 'D  "deleted-index.txt"', ' D "deleted-working.txt"',
                         'MM "mixed.txt"', 'M  "staged.txt"', ' M "unstaged.txt"', '?? "notes.txt"'):
                self.assertIn(line, status.splitlines())
            self.assertEqual(captured.paths, {
                "added.txt", "deleted-index.txt", "deleted-working.txt", "mixed.txt",
                "staged.txt", "unstaged.txt", "notes.txt",
            })
            for args in (("--cached", base), ()):
                patch = self.helper["git"](repo, "diff", *self.helper["SAFE_DIFF_FLAGS"], *args)
                self.assertIn(patch.rstrip(), captured.text)
            self.assertIn('path: "notes.txt"', captured.text)
            record, = captured.mixed
            self.assertEqual(record.path, "mixed.txt")
            self.assertEqual(record.base.content, "base\n")
            self.assertEqual(record.index.content, "INDEX-only defect\n")
            self.assertEqual(record.working_tree.content, "base\n")
            self.assertIn("+INDEX-only defect", captured.text)
            self.assertIn("-INDEX-only defect", captured.text)
            self.assertEqual(self.helper["source_tree_snapshot"](repo), before)
            self.assertEqual(git(repo, "rev-parse", "HEAD").strip(), old_head)

    def test_advanced_local_base_user_path_avoids_upstream_only_partitions(self) -> None:
        with self.advanced_local_base() as (root, repo, base, old_head):
            evidence = repo / "evidence"
            evidence.mkdir()
            datasets = []
            for number in range(43):
                rel = f"evidence/context-{number}.txt"
                (repo / rel).write_text(f"context {number}\n" + "evidence\n" * 2100, encoding="utf-8")
                datasets.extend(("--dataset", rel))
            captured = self.helper["local_bundle"](repo, base)
            self.assertEqual(captured.mixed, ())
            before = self.helper["source_tree_snapshot"](repo)
            sends = []

            def engine(_args, _repo, prompt):
                sends.append(prompt)
                self.assertNotIn("upstream/", prompt)
                self.assertIn(captured.text, prompt)
                self.assertLessEqual(len(prompt.encode()), self.helper["MAX_REVIEW_PROMPT_BYTES"])
                return json.dumps({
                    "findings": [], "overall_correctness": "patch is correct",
                    "overall_explanation": "Synthetic candidate assessment.", "overall_confidence": 0.9,
                    "review_completion": completion,
                })

            main = self.helper["main_impl"]
            argv = [str(SCRIPT), "--engine", "codex", "--mode", "local", "--base", "review-base",
                    *datasets, "--json-output", str(root / "report.json"),
                    "--status-output", str(root / "status.json")]
            with self.without_reviewer_defaults(), mock.patch.dict(main.__globals__, {
                "repo_root": lambda: repo, "run_engine": engine,
                "resolve_engine_binary": lambda _reviewer, _repo: (True, None),
            }):
                output = io.StringIO()
                with mock.patch.object(sys, "argv", [*argv, "--dry-run"]), contextlib.redirect_stdout(output):
                    self.assertEqual(main(), 0)
                self.assertIn("prompt: OK", output.getvalue())
                self.assertEqual(sends, [])
                self.assertFalse((root / "status.json").exists())
                self.assertFalse((root / "report.json").exists())
                for completion, exit_code, status in (("complete", 0, "scoped-clean"), ("incomplete", 2, "incomplete")):
                    with self.subTest(completion=completion):
                        sends.clear()
                        with mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(io.StringIO()):
                            self.assertEqual(main(), exit_code)
                        self.assertGreater(len(sends), 1)
                        for number in range(43):
                            header = f"# Dataset: {Path(f'evidence/context-{number}.txt')}"
                            self.assertTrue(any(header in p for p in sends))
                        result = json.loads((root / "report.json").read_text())
                        self.assertEqual(result["review_status"], status)
                        self.assertEqual(result["findings"], [])
                        self.assertEqual(json.loads((root / "status.json").read_text())["status"], status)
            self.assertEqual(self.helper["source_tree_snapshot"](repo), before)
            self.assertEqual(git(repo, "rev-parse", "HEAD").strip(), old_head)

    def test_local_base_pins_named_ref_and_rejects_invalid_refs(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "source.txt").write_text("base\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            git(repo, "commit", "-q", "-m", "base")
            base = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "branch", "review-base")
            (repo / "committed.txt").write_text("committed task change\n", encoding="utf-8")
            git(repo, "add", "committed.txt")
            git(repo, "commit", "-q", "-m", "task")
            (repo / "source.txt").write_text("staged task change\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            target, pinned = self.helper["choose_target"](repo, "local", "review-base")
            self.assertEqual((target, pinned), ("local", base))
            snapshot = self.helper["source_tree_snapshot"](repo)
            git(repo, "update-ref", "refs/heads/review-base", "HEAD")
            self.assertEqual(self.helper["source_tree_snapshot"](repo), snapshot)
            bundle = self.helper["local_bundle"](repo, pinned).text
            self.assertIn("+committed task change", bundle)
            self.assertEqual(
                self.helper["build_bundle"](repo, target, pinned, "HEAD").paths,
                {"source.txt", "committed.txt"},
            )
            for ref, error in (("--help", "unsafe"), ("HEAD:source.txt", "unsafe"), ("", "unsafe"), ("missing-base", "unknown")):
                with self.subTest(ref=ref), self.assertRaisesRegex(SystemExit, f"{error} base ref"):
                    self.helper["choose_target"](repo, "local", ref)

    def test_credential_source_filename_is_safe_but_stores_remain_blocked(self) -> None:
        safe = "Sources/Configuration/CredentialFile.swift"
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            git(repo, "commit", "-q", "--allow-empty", "-m", "base")
            source = repo / safe
            source.parent.mkdir(parents=True)
            source.write_text("struct CredentialFile { let version = 1 }\n", encoding="utf-8")
            for staged in (False, True):
                if staged:
                    git(repo, "add", safe)
                with self.subTest(staged=staged):
                    bundle = self.helper["local_bundle"](repo).text
                    self.assertIn("struct CredentialFile", bundle)
                    self.assertIn(safe, self.helper["local_bundle"](repo).paths)
                    for label in ("--dataset", "--prompt-file"):
                        _, content = self.helper["validate_evidence_file"](repo, safe, label)
                        self.assertEqual(content, source.read_bytes().decode("utf-8"))

            blocked = (
                "credentials.json", "config/prod-credentials.json", "credentials/store.json",
                "tokens/session.dat", ".env", ".env.local", "config/client.pem", "config/client.key",
                ".ssh/id_ed25519", "Sources/credentials/CredentialFile.swift",
                "Sources/backup-secrets/CredentialFile.swift", ".env/CredentialFile.swift",
                "Sources/CredentialFile.swift.key", "Sources/credentials.swift",
            )
            for rel in blocked:
                with self.subTest(blocked=rel):
                    self.assertIsNotNone(self.helper["sensitive_repo_path_risk"](rel))
                    with self.assertRaisesRegex(SystemExit, "sensitive|unsafe"):
                        self.helper["validate_evidence_file"](repo, rel, "--dataset")

    def test_explicit_empty_local_runs_reviewer_and_validates_outcomes(self) -> None:
        report = {
            "findings": [], "overall_correctness": "patch is correct",
            "overall_explanation": "Synthetic empty-scope review.",
            "overall_confidence": 0.9, "review_completion": "complete",
        }
        cases = (
            ("local", "complete", 0, "scoped-clean"),
            ("branch", "complete", 0, "scoped-clean"),
            ("local", "incomplete", 2, "incomplete"),
            ("local", "incorrect", 1, "incorrect"),
            ("local", "invalid", None, "reviewer_unavailable"),
            ("local", "failed", None, "reviewer_unavailable"),
            ("local", "drift", 1, None),
        )
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("base\n", encoding="utf-8")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "base")
            base = git(repo, "rev-parse", "HEAD").strip()
            source.write_text("head\n", encoding="utf-8")
            git(repo, "commit", "-qam", "head")
            head = git(repo, "rev-parse", "HEAD").strip()
            git(repo, "restore", "--source", base, "--staged", "--worktree", ".")
            self.assertNotEqual(head, base)
            self.assertTrue(git(repo, "status", "--porcelain"))
            self.assertEqual(git(repo, "diff", "--cached", base), "")
            self.assertEqual(git(repo, "diff"), "")
            for mode, outcome, exit_code, status in cases:
                with self.subTest(mode=mode, outcome=outcome):
                    outputs = root / f"{mode}-{outcome}"
                    outputs.mkdir()
                    sends = []

                    def engine(_args, _repo, prompt):
                        sends.append(prompt)
                        if outcome == "failed":
                            raise self.helper["ReviewerUnavailable"]("synthetic engine failure")
                        if outcome == "invalid":
                            return json.dumps({"findings": []})
                        if outcome == "drift":
                            source.write_text("changed during review\n", encoding="utf-8")
                        response = dict(report)
                        if outcome == "incomplete":
                            response["review_completion"] = "incomplete"
                        if outcome == "incorrect":
                            response["overall_correctness"] = "patch is incorrect"
                        return json.dumps(response)

                    argv = [str(SCRIPT), "--engine", "codex", "--mode", mode,
                            "--base", base if mode == "local" else head,
                            "--json-output", str(outputs / "report.json"),
                            "--status-output", str(outputs / "status.json")]
                    with self.without_reviewer_defaults(), mock.patch.dict(self.helper["main_impl"].__globals__, {
                        "repo_root": lambda: repo, "run_engine": engine,
                    }), mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                        if exit_code is None:
                            with self.assertRaises(self.helper["ReviewerUnavailable"]):
                                self.helper["main_impl"]()
                        else:
                            self.assertEqual(self.helper["main_impl"](), exit_code)
                    self.assertEqual(len(sends), 1)
                    if mode == "local":
                        self.assertIn(f"base: {base}", sends[0])
                        self.assertIn("Zero selected changes", sends[0])
                        self.assertIn("Columns: base -> index, index -> working_tree", sends[0])
                        self.assertNotIn("diff --git", sends[0])
                    if status:
                        result = json.loads((outputs / "status.json").read_text())
                        self.assertEqual(result["status"], status)
                        self.assertEqual(result["report_produced"], exit_code is not None)
                    else:
                        self.assertFalse((outputs / "status.json").exists())
                    if exit_code is None or outcome == "drift":
                        self.assertFalse((outputs / "report.json").exists())
                    else:
                        result = json.loads((outputs / "report.json").read_text())
                        self.assertEqual(result["review_status"], status)
                        self.assertEqual(result["findings"], [])
                        self.assertEqual(result["overall_explanation"], report["overall_explanation"])
                    self.assertEqual(git(repo, "rev-parse", "HEAD").strip(), head)
                    self.assertEqual(git(repo, "diff", "--cached", base), "")

    def test_empty_scope_excludes_omissions_and_undone_staged_changes(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = repo / "source.txt"
            source.write_text("base\n", encoding="utf-8")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "base")
            base = git(repo, "rev-parse", "HEAD").strip()
            with self.assertRaisesRegex(SystemExit, "no local changes to review"):
                self.helper["local_bundle"](repo)
            sensitive = repo / ".env"
            sensitive.write_text("SYNTHETIC_OMISSION\n", encoding="utf-8")
            for staged in (False, True):
                if staged:
                    git(repo, "add", ".env")
                captured = self.helper["local_bundle"](repo, base)
                self.assertEqual(captured.paths, set())
                self.assertIn("# Review Input Omissions", captured.text)
                self.assertNotIn("Zero selected changes", captured.text)
                self.assertNotIn("SYNTHETIC_OMISSION", captured.text)
            git(repo, "rm", "-f", ".env")
            source.write_text("staged defect\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            source.write_text("base\n", encoding="utf-8")
            captured = self.helper["local_bundle"](repo, base)
            self.assertEqual(captured.paths, {"source.txt"})
            self.assertIn("+staged defect", captured.text)
            self.assertIn("-staged defect", captured.text)
            self.assertNotIn("Zero selected changes", captured.text)
            self.assertEqual(len(captured.mixed), 1)

    def test_complete_candidate_scope_and_local_results_remain_honest(self) -> None:
        source = "Sources/Configuration/CredentialFile.swift"
        untracked = "Runtime/Configuration/CredentialFile.swift"
        e2e = "Tests/Integration/EndToEndTests.swift"
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            # Match the helper's raw Git policy so CRLF fixtures stay committed-only.
            git(repo, "config", "core.autocrlf", "false")
            (repo / "runtime.txt").write_text("old runtime\n", encoding="utf-8")
            (repo / "context.md").write_text("Full candidate context: integration contract broken.\n", encoding="utf-8")
            git(repo, "add", ".")
            git(repo, "commit", "-q", "-m", "base")
            base = git(repo, "rev-parse", "HEAD").strip()
            test_file = repo / e2e
            test_file.parent.mkdir(parents=True)
            test_file.write_text("// synthetic integration fixture\n" * 27 + "func testLive() { preconditionFailure() }\n", encoding="utf-8")
            git(repo, "add", e2e)
            git(repo, "commit", "-q", "-m", "original candidate")
            self.assertEqual(git(repo, "status", "--porcelain"), "")
            for rel in (source, untracked):
                path = repo / rel
                path.parent.mkdir(parents=True)
                path.write_text("struct CredentialFile { let version = 2 }\n", encoding="utf-8")
            (repo / "credentials.json").write_text('{"fixture": "OMIT_STAGED_STORE"}\n', encoding="utf-8")
            git(repo, "add", source, "credentials.json")
            (repo / "runtime.txt").write_text("unstaged runtime\n", encoding="utf-8")
            (repo / ".env").write_text("OMIT_UNTRACKED_ENV\n", encoding="utf-8")
            findings = [{
                "title": title, "body": body, "priority": "P2", "confidence": 0.8,
                "category": "bug", "code_location": {"file_path": rel, "line": line},
            } for title, body, rel, line in (
                ("Preserve source contract", "The public API contract is broken.", source, 1),
                ("Keep integration runnable", "The live E2E fails unconditionally.", e2e, 28),
            )]
            provider_report = {
                "findings": findings, "overall_correctness": "patch is incorrect",
                "overall_explanation": "The public API contract is broken and live E2E fails unconditionally.",
                "overall_confidence": 0.73,
            }
            cases = (
                ("local", None, {source}, 2),
                ("auto", None, {source}, 2),
                ("branch", base, {e2e}, 2),
                ("local", base, {source, e2e}, 1),
            )
            for engine in ("codex", "claude", "amp", "pi"):
                for mode, ref, accepted, expected_exit in cases:
                    with self.subTest(engine=engine, mode=mode, ref=bool(ref)):
                        sends = []

                        def run_engine(_args, _repo, prompt):
                            sends.append(prompt)
                            return json.dumps({**provider_report, "review_completion": "complete"})

                        argv = [str(SCRIPT), "--engine", engine, "--mode", mode, "--max-priority", "P2",
                                "--dataset", e2e, "--prompt-file", "context.md", "--prompt", "Review the complete candidate.",
                                "--output", str(root / "result.txt"), "--json-output", str(root / "result.json")]
                        if ref:
                            argv.extend(["--base", ref])
                        output = io.StringIO()
                        with mock.patch.dict(self.helper["main_impl"].__globals__, {
                            "repo_root": lambda: repo, "run_engine": run_engine,
                        }), mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(output), contextlib.redirect_stderr(io.StringIO()):
                            self.assertEqual(self.helper["main_impl"](), expected_exit)
                        result = json.loads((root / "result.json").read_text())
                        self.assertEqual({f["code_location"]["file_path"] for f in result["findings"]}, accepted)
                        for key in ("overall_correctness", "overall_explanation", "overall_confidence"):
                            self.assertEqual(result[key], provider_report[key])
                        self.assertEqual(result["review_status"], "incomplete" if expected_exit == 2 else "findings")
                        text = (root / "result.txt").read_text()
                        self.assertIn(text, output.getvalue())
                        self.assertIn("Keep integration runnable", text)
                        self.assertIn("Preserve source contract", text)
                        self.assertNotIn("clean:", text)
                        rejected = result.get("scope_rejected_findings", [])
                        self.assertEqual(len(rejected), 2 - len(accepted))
                        self.assertIn("# Dataset: " + str(Path(e2e)), sends[0])
                        self.assertNotIn("OMIT_STAGED_STORE", sends[0])
                        self.assertNotIn("OMIT_UNTRACKED_ENV", sends[0])
                        if mode == "local" and ref:
                            self.assertIn(f"# Staged Diff\nbase: {base}", sends[0])
                            for marker in ("+func testLive", "+struct CredentialFile", "-old runtime", "+unstaged runtime", f'path: "{untracked}"'):
                                self.assertIn(marker, sends[0])
            for target, ref in (("local", None), ("local", base), ("branch", base)):
                paths = self.helper["build_bundle"](repo, target, ref, "HEAD").paths
                self.assertNotIn("credentials.json", paths)
                self.assertNotIn(".env", paths)
                if target == "local":
                    self.assertIn(untracked, paths)

    def test_single_and_chunked_result_status_exit_and_required_checks(self) -> None:
        finding = {
            "title": "Synthetic defect", "body": "Keep this finding auditable.",
            "priority": "P2", "confidence": 0.7, "category": "bug",
            "code_location": {"file_path": "source.txt", "line": 1},
        }
        cases = (
            # location, provider verdict, priority, required, expect, status, exit
            (None, "patch is correct", "P2", [], False, "scoped-clean", 0),
            (None, "patch is incorrect", "P2", [], False, "incorrect", 1),
            ("source.txt", "patch is incorrect", "P2", [], False, "findings", 1),
            ("source.txt", "patch is incorrect", "P2", ["Synthetic defect"], True, "findings", 0),
            ("source.txt", "patch is incorrect", "P0", [], False, "filtered", 1),
            ("source.txt", "patch is correct", "P0", [], False, "filtered", 0),
            ("source.txt", "patch is incorrect", "P0", ["Synthetic defect"], True, "incomplete", 2),
            ("elsewhere.txt", "patch is incorrect", "P2", [], False, "incomplete", 2),
            ("elsewhere.txt", "patch is correct", "P0", [], True, "incomplete", 2),
            ("elsewhere.txt", "patch is incorrect", "P2", ["Synthetic defect"], False, "incomplete", 2),
        )
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            git(repo, "commit", "-q", "--allow-empty", "-m", "base")
            (repo / "source.txt").write_text("changed\n", encoding="utf-8")
            for count in (1, 2):
                for rel, verdict, priority, required, expect, expected_status, exit_code in cases:
                    with self.subTest(count=count, rel=rel, verdict=verdict, priority=priority, required=required, expect=expect):
                        issue = copy.deepcopy(finding)
                        issue["code_location"]["file_path"] = rel
                        provider = {
                            "findings": [issue] if rel else [], "overall_correctness": verdict,
                            "overall_explanation": "Synthetic provider explanation.", "overall_confidence": 0.61,
                        }
                        argv = [str(SCRIPT), "--engine", "codex", "--mode", "local", "--max-priority", priority,
                                "--max-review-passes", str(count),
                                "--output", str(root / "result.txt"), "--json-output", str(root / "result.json"),
                                "--status-output", str(root / "status.json")]
                        for needle in required:
                            argv.extend(["--require-finding", needle])
                        if expect:
                            argv.append("--expect-findings")
                        with self.without_reviewer_defaults(), mock.patch.dict(self.helper["main_impl"].__globals__, {
                            "repo_root": lambda: repo,
                            "build_review_prompts": lambda *_args: ["synthetic pack"] * count,
                            "run_engine": lambda *_args: json.dumps({**provider, "review_completion": "complete"}),
                        }), mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                            self.assertEqual(self.helper["main_impl"](), exit_code)
                        result = json.loads((root / "result.json").read_text())
                        outcome = json.loads((root / "status.json").read_text())
                        self.assertEqual(outcome, {
                            "schema_version": 1, "status": expected_status, "exit_code": exit_code,
                            "engine": "codex", "report_produced": True, "reason": None,
                            "reviewer_exit_code": None, "timed_out": False,
                        })
                        text = (root / "result.txt").read_text()
                        self.assertEqual(result["review_status"], expected_status)
                        self.assertEqual(result["overall_correctness"], verdict)
                        self.assertEqual(result["overall_confidence"], 0.61)
                        self.assertIn(provider["overall_explanation"], text)
                        self.assertEqual("scoped-clean:" in text, expected_status == "scoped-clean")
                        if rel:
                            self.assertIn("Keep this finding auditable.", text)
                        if expected_status == "incomplete":
                            self.assertIn("incomplete:", text)
                        if required and expected_status == "incomplete":
                            self.assertEqual(result["missing_required_findings"], required)

    def test_local_filter_collection_is_all_or_nothing_before_review(self) -> None:
        import shlex

        cases = (
            ("required-conversion", "probe", {"aaa-ordinary.txt", "data.txt"}),
            ("unused-driver", "unused", {"aaa-ordinary.txt", "data.txt"}),
            ("stat-clean-neighbor", "probe", {"aaa-ordinary.txt"}),
        )
        provider_report = {
            "findings": [],
            "overall_correctness": "patch is correct",
            "overall_explanation": "Synthetic complete-scope review.",
            "overall_confidence": 0.99,
        }
        for scenario, driver, expected_paths in cases:
            with self.subTest(scenario=scenario), tempfile.TemporaryDirectory(
                prefix="autoreview-filter-main.",
            ) as tempdir:
                root = Path(tempdir).resolve()
                home = root / "operator"
                home.mkdir()
                # Keep native setup and main's actual Git preflight independent of
                # caller routing, configuration, reviewer defaults, and credentials.
                env = {key: os.environ[key] for key in (
                    "PATH", "PATHEXT", "SYSTEMROOT", "SystemRoot", "COMSPEC", "WINDIR",
                    "TEMP", "TMP", "TMPDIR", "DEVELOPER_DIR",
                ) if key in os.environ}
                env.update({
                    "HOME": str(home), "USERPROFILE": str(home),
                    "GIT_CONFIG_GLOBAL": os.devnull,
                    "GIT_CONFIG_SYSTEM": os.devnull, "GIT_CONFIG_NOSYSTEM": "1",
                    "GIT_TERMINAL_PROMPT": "0", "GIT_OPTIONAL_LOCKS": "0",
                    "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
                })
                with mock.patch.dict(os.environ, env, clear=True):
                    repo = init_repo(root)
                    git(repo, "config", "core.autocrlf", "false")
                    git(repo, "config", "commit.gpgsign", "false")
                    ordinary = repo / "aaa-ordinary.txt"
                    data = repo / "data.txt"
                    markers = (root / "clean-dispatched", root / "process-dispatched")
                    programs = (repo / "cleaner.py", repo / "processor.py")
                    for marker, program, ending in zip(markers, programs, (
                        "sys.stdout.buffer.write(sys.stdin.buffer.read())\n",
                        "raise SystemExit(23)\n",
                    )):
                        program.write_bytes((
                            "from pathlib import Path\nimport sys\n"
                            f"Path({str(marker)!r}).write_bytes(b'synthetic dispatch\\n')\n"
                            + ending
                        ).encode("utf-8"))
                    (repo / ".gitattributes").write_bytes(b"data.txt filter=probe\n")
                    ordinary.write_bytes(b"ordinary original\n")
                    data.write_bytes(b"filtered original\n")
                    git(repo, "add", ".")
                    git(repo, "commit", "-qm", "synthetic dormant filter fixture")

                    # Establish non-racy clean data before enabling any converter.
                    # Never repair or refresh that entry after converters are armed.
                    info = data.stat()
                    os.utime(data, ns=(info.st_atime_ns, info.st_mtime_ns - 2_000_000_000))
                    git(repo, "update-index", "--refresh")
                    ordinary.write_bytes(b"ordinary changed before filtered path\n")
                    if scenario != "stat-clean-neighbor":
                        data.write_bytes(b"filtered content changed and different in size\n")
                    # Freeze the complete expected patch while no driver can run.
                    expected_patch = git(
                        repo, "--no-optional-locks", "diff", "--no-ext-diff",
                        "--no-textconv", "--no-renames", "--no-color", "--patch",
                    )
                    self.assertIn("+ordinary changed before filtered path", expected_patch)
                    if scenario != "stat-clean-neighbor":
                        self.assertIn("+filtered content changed and different in size", expected_patch)
                    for field, program in zip(("clean", "process"), programs):
                        command = shlex.join((Path(sys.executable).as_posix(), program.as_posix()))
                        git(repo, "config", f"filter.{driver}.{field}", command)
                    git(repo, "config", f"filter.{driver}.required", "true")

                    def observe():
                        # Collection may refresh index stat caches, but must retain
                        # every staged entry and every working/configuration byte.
                        files = {
                            str(path.relative_to(repo)): path.read_bytes()
                            for path in repo.rglob("*")
                            if path.is_file() and path != repo / ".git" / "index"
                        }
                        return files, git(repo, "ls-files", "--stage", "-z")

                    before = observe()
                    output_dir = root / "outputs"
                    output_dir.mkdir()
                    human = output_dir / "report.txt"
                    report = output_dir / "report.json"
                    sidecar = output_dir / "status.json"
                    sidecar.write_bytes(b'{"status":"scoped-clean","stale":true}\n')
                    argv = [
                        str(SCRIPT), "--engine", "codex", "--mode", "local",
                        "--max-priority", "P2", "--output", str(human),
                        "--json-output", str(report), "--status-output", str(sidecar),
                    ]

                    def reply(_args, selected_repo, _prompt):
                        if scenario == "required-conversion":
                            raise AssertionError("partial conversion-dependent scope reached reviewer")
                        self.assertEqual(selected_repo, repo)
                        return json.dumps({**provider_report, "review_completion": "complete"})

                    engine = mock.Mock(side_effect=reply)
                    stdout, stderr = io.StringIO(), io.StringIO()
                    main = self.helper["main_impl"]
                    with mock.patch.dict(main.__globals__, {
                        "repo_root": lambda: repo,
                        "resolve_engine_binary": lambda *_args: (True, None),
                        "run_engine": engine,
                    }), mock.patch.object(sys, "argv", argv), \
                            contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                        try:
                            if scenario == "required-conversion":
                                with self.assertRaisesRegex(SystemExit, r"(?i)filter"):
                                    main()
                            else:
                                self.assertEqual(main(), 0)
                        finally:
                            self.assertFalse(markers[0].exists(), "clean converter executed")
                            self.assertFalse(markers[1].exists(), "process converter executed")
                            self.assertEqual(observe(), before, "collection mutated fixture inputs")

                    if scenario == "required-conversion":
                        engine.assert_not_called()
                        self.assertEqual(list(output_dir.iterdir()), [],
                                         "refusal must not leave reports, status, or partial outputs")
                        self.assertNotIn("scoped-clean:", stdout.getvalue())
                        continue

                    engine.assert_called_once()
                    prompt = engine.call_args.args[2]
                    self.assertIn(expected_patch.rstrip(), prompt)
                    paths = set(re.findall(r"^diff --git a/(\S+) b/\1$", prompt, re.MULTILINE))
                    self.assertEqual(paths, expected_paths)
                    for path in expected_paths:
                        self.assertEqual(prompt.count(f"diff --git a/{path} b/{path}\n"), 1)
                    result = json.loads(report.read_text(encoding="utf-8"))
                    self.assertEqual(result["findings"], [])
                    self.assertEqual(result["review_status"], "scoped-clean")
                    for key in ("overall_correctness", "overall_explanation", "overall_confidence"):
                        self.assertEqual(result[key], provider_report[key])
                    self.assertEqual(json.loads(sidecar.read_text(encoding="utf-8")), {
                        "schema_version": 1, "status": "scoped-clean", "exit_code": 0,
                        "engine": "codex", "report_produced": True, "reason": None,
                        "reviewer_exit_code": None, "timed_out": False,
                    })
                    rendered = human.read_text(encoding="utf-8")
                    self.assertIn("scoped-clean:", rendered)
                    self.assertIn(provider_report["overall_explanation"], rendered)
                    self.assertIn(rendered, stdout.getvalue())
                    self.assertEqual({path.name for path in output_dir.iterdir()},
                                     {"report.txt", "report.json", "status.json"})

    def test_completion_finalizes_status_once_and_preserves_provider_observations(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            git(repo, "commit", "-q", "--allow-empty", "-m", "base")
            (repo / "source.txt").write_text("changed\n")
            status_fn = self.helper["review_status"]
            for completions in (("complete",), ("incomplete",), ("incomplete", "complete"), ("complete", "incomplete")):
                for has_finding in (False, True):
                    for expect in (False, True):
                        for save_text in (False, True):
                            with self.subTest(completions=completions, finding=has_finding, expect=expect, save_text=save_text):
                                providers = [{
                                    "findings": [{
                                        "title": "Synthetic defect", "body": "Retain this observation.",
                                        "priority": "P2", "confidence": 0.01, "category": "bug",
                                        "code_location": {"file_path": "source.txt", "line": 1},
                                    }] if has_finding else [],
                                    "overall_correctness": "patch is incorrect" if has_finding else "patch is correct",
                                    "overall_explanation": (
                                        "Awaiting the second evidence batch before a final review verdict."
                                        if completion == "incomplete" else "Finished this assigned assessment."
                                    ),
                                    "overall_confidence": 0.01,
                                } for completion in completions]
                                engine = mock.Mock(side_effect=[
                                    json.dumps({**provider, "review_completion": completion})
                                    for provider, completion in zip(providers, completions)
                                ])
                                result_path, status_path, text_path = (
                                    root / name for name in ("result.json", "status.json", "result.txt")
                                )
                                argv = [str(SCRIPT), "--mode", "local", "--max-priority", "P2",
                                        "--json-output", str(result_path), "--status-output", str(status_path)]
                                if expect:
                                    argv.append("--expect-findings")
                                if save_text:
                                    argv += ["--output", str(text_path)]
                                complete = all(value == "complete" for value in completions)
                                expected_status = "incomplete" if not complete else "findings" if has_finding else "scoped-clean"
                                expected_exit = 2 if not complete else int(not has_finding) if expect else int(has_finding)
                                finalized = mock.Mock(wraps=status_fn)
                                text = io.StringIO()
                                with mock.patch.dict(self.helper["main_impl"].__globals__, {
                                    "repo_root": lambda: repo,
                                    "build_review_prompts": lambda *_: ["synthetic pack"] * len(completions),
                                    "run_engine": engine, "review_status": finalized,
                                }), mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(text), \
                                        contextlib.redirect_stderr(io.StringIO()):
                                    self.assertEqual(self.helper["main_impl"](), expected_exit)
                                finalized.assert_called_once()
                                self.assertEqual(engine.call_count, len(completions))
                                result = json.loads(result_path.read_text())
                                self.assertEqual(result["review_status"], expected_status)
                                self.assertEqual(result["overall_confidence"], 0.01)
                                self.assertEqual(bool(result["findings"]), has_finding)
                                retained = ([result] if len(completions) == 1
                                            else [entry["report"] for entry in result["pass_reports"]])
                                self.assertEqual([entry["provider_report"] for entry in retained], providers)
                                self.assertNotIn("review_completion", result_path.read_text())
                                self.assertEqual(json.loads(status_path.read_text()), {
                                    "schema_version": 1, "status": expected_status, "exit_code": expected_exit,
                                    "engine": "codex", "report_produced": True, "reason": None,
                                    "reviewer_exit_code": None, "timed_out": False,
                                })
                                for provider in providers:
                                    self.assertIn(provider["overall_explanation"], text.getvalue())
                                if save_text:
                                    self.assertIn(text_path.read_text(), text.getvalue())
                                if not complete:
                                    self.assertNotIn("scoped-clean", text.getvalue())
                                    self.assertIn("provider observation (incomplete review)", text.getvalue())

    def test_status_unavailable_and_local_refusals_remain_distinct(self) -> None:
        public = {"findings": [], "overall_correctness": "patch is correct",
                  "overall_explanation": "Synthetic review.", "overall_confidence": 0.9}
        clean = json.dumps({**public, "review_completion": "complete"})
        earlier_terminal = {"type": "result", "result": json.loads(clean)}
        broken_terminal = {"type": "result", "result": None}
        unavailable = self.helper["ReviewerUnavailable"]
        cases = (
            ("engine", unavailable("DIAGNOSTIC_SENTINEL", result=subprocess.CompletedProcess([], 7, "", "")), "engine_failed"),
            ("timeout", unavailable("DIAGNOSTIC_SENTINEL", result=self.helper["TimedOutEngineProcess"]([], 124, "", "")), "engine_failed"),
            ("invalid-json", "not JSON", "invalid_report"),
            ("invalid-schema", '{"findings": []}', "invalid_report"),
            ("invalid-field-type", json.dumps({"findings": [], "overall_correctness": [],
                                               "overall_explanation": "Invalid enum", "overall_confidence": 0.9,
                                               "review_completion": "complete"}), "invalid_report"),
            ("invalid-event-type", '[{"type":"assistant","message":{"content":null}}]', "invalid_report"),
            ("invalid-final-jsonl", "\n".join(json.dumps(event) for event in
                                             (earlier_terminal, broken_terminal)), "invalid_report"),
            ("invalid-final-array", json.dumps([earlier_terminal, broken_terminal]), "invalid_report"),
            ("missing-completion", json.dumps(public), "invalid_report"),
            *((f"invalid-completion-{index}", json.dumps({**public, "review_completion": value}), "invalid_report")
              for index, value in enumerate(("", "deferred", [], {}, None, 42, False))),
            ("isolation", SystemExit("isolation refused"), None),
            ("spawn", OSError("cannot execute reviewer"), None),
        )
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            git(repo, "commit", "-q", "--allow-empty", "-m", "base")
            (repo / "source.txt").write_text("changed\n")
            for count in (1, 2):
                for label, failure, reason in cases:
                    with self.subTest(count=count, label=label):
                        outputs = root / f"case-{count}-{label}"
                        outputs.mkdir()
                        sidecar = outputs / "status.json"
                        report = outputs / "result.json"
                        human = outputs / "result.txt"
                        sidecar.write_text('{"status":"scoped-clean"}')
                        argv = [str(SCRIPT), "--mode", "local", "--engine", "codex",
                                "--status-output", str(sidecar), "--json-output", str(report),
                                "--output", str(human)]
                        engine = mock.Mock(side_effect=[clean] * (count - 1) + [failure])
                        stdout = io.StringIO()
                        with mock.patch.dict(self.helper["main_impl"].__globals__, {
                            "repo_root": lambda: repo,
                            "build_review_prompts": lambda *_args: ["synthetic pack"] * count,
                            "run_engine": engine,
                        }), mock.patch.object(sys, "argv", argv), contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(io.StringIO()):
                            with self.assertRaises((SystemExit, OSError)) as caught:
                                self.helper["main_impl"]()
                        self.assertFalse(report.exists())
                        self.assertFalse(human.exists())
                        self.assertNotIn("scoped-clean:", stdout.getvalue())
                        self.assertEqual(engine.call_count, count)
                        self.assertEqual(sidecar.exists(), reason is not None)
                        if reason:
                            text = sidecar.read_text()
                            outcome = json.loads(text)
                            self.assertEqual(outcome["status"], "reviewer_unavailable")
                            self.assertEqual(outcome["reason"], reason)
                            self.assertFalse(outcome["report_produced"])
                            self.assertEqual(outcome["timed_out"], label == "timeout")
                            self.assertEqual(outcome["reviewer_exit_code"], {"engine": 7, "timeout": 124}.get(label))
                            self.assertNotIn("DIAGNOSTIC_SENTINEL", text)
                            if label.startswith("invalid-final-"):
                                self.assertIsInstance(caught.exception, unavailable)
                                self.assertEqual(caught.exception.reason, "invalid_report")
                                self.assertEqual(outcome, {
                                    "schema_version": 1, "status": "reviewer_unavailable", "exit_code": 1,
                                    "engine": "codex", "report_produced": False, "reason": "invalid_report",
                                    "reviewer_exit_code": None, "timed_out": False,
                                })
                                self.assertEqual({path.name for path in outputs.iterdir()}, {"status.json"})

    def test_status_paths_reject_repo_and_aliases_before_removing_files(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            existing = root / "status.json"
            existing.write_text("keep existing output")
            for first, second in (("result.json", "RESULT.json"), ("caf\u00e9.json", "cafe\u0301.json")):
                args = argparse.Namespace(status_output=str(root / first), output=None, json_output=str(root / second))
                with self.assertRaises(SystemExit):
                    self.helper["prepare_output_paths"](args, repo)
                self.assertFalse((root / first).exists())
            for value in (str(repo / "result.json"), str(existing)):
                args = argparse.Namespace(status_output=value, output=None, json_output=str(existing))
                with self.assertRaises(SystemExit):
                    self.helper["prepare_output_paths"](args, repo)
                self.assertEqual(existing.read_text(), "keep existing output")
            if os.name != "nt":
                alias = root / "alias.json"
                alias.symlink_to(existing)
                args.status_output = str(alias)
                with self.assertRaises(SystemExit):
                    self.helper["prepare_output_paths"](args, repo)
                alias.unlink()
                os.link(existing, alias)
                with self.assertRaises(SystemExit):
                    self.helper["prepare_output_paths"](args, repo)

    @unittest.skipUnless(sys.platform == "darwin", "macOS firmlink alias")
    def test_status_rejects_absent_outputs_under_same_parent_inode(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir).resolve()
            alias = Path("/System/Volumes/Data") / root.relative_to("/")
            if not alias.exists() or not os.path.samefile(root, alias):
                self.skipTest("temporary directory has no data-volume alias")
            repo = init_repo(root)
            args = argparse.Namespace(status_output=str(root / "result.json"),
                                      json_output=str(alias / "result.json"), output=None)
            with self.assertRaises(SystemExit):
                self.helper["prepare_output_paths"](args, repo)
            self.assertFalse((root / "result.json").exists())

    @unittest.skipIf(os.name == "nt", "the executable fixtures are POSIX-only")
    def test_cli_status_for_launched_codex_and_claude_failures(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            git(repo, "commit", "-q", "--allow-empty", "-m", "base")
            (repo / "source.txt").write_text("review me\n")
            env = os.environ.copy()
            env.update({"HOME": str(root), "USERPROFILE": str(root)})
            for engine, source in (("codex", fake_codex_script()), ("claude", fake_claude_script())):
                for timeout in (False, True):
                    with self.subTest(engine=engine, timeout=timeout):
                        # Help/version preflights succeed; only the launched review fails.
                        injected = "import time; sys.stdin.read(); time.sleep(30)" if timeout else "print('DIAGNOSTIC_SENTINEL\\x1b[31m', file=sys.stderr); raise SystemExit(17)"
                        executable = write_executable(root / engine, source.replace('record = os.environ["AUTOREVIEW_FAKE_RECORD"]', injected + '\nrecord = os.environ["AUTOREVIEW_FAKE_RECORD"]'))
                        sidecar = root / "status.json"
                        report = root / "result.json"
                        argv = [sys.executable, str(SCRIPT), "--mode", "local", "--engine", engine,
                                f"--{engine}-bin", str(executable), "--status-output", str(sidecar),
                                "--json-output", str(report)]
                        if timeout:
                            argv += ["--engine-timeout-seconds", "0.2"]
                        result = subprocess.run(argv, cwd=repo, env=env, text=True, capture_output=True, timeout=30)
                        self.assertEqual(result.returncode, 1, result.stderr)
                        outcome = json.loads(sidecar.read_text())
                        self.assertEqual(outcome["status"], "reviewer_unavailable")
                        self.assertEqual(outcome["engine"], engine)
                        self.assertEqual(outcome["reviewer_exit_code"], 124 if timeout else 17)
                        self.assertEqual(outcome["timed_out"], timeout)
                        self.assertFalse(report.exists())
                        self.assertNotIn("DIAGNOSTIC_SENTINEL", sidecar.read_text())
                        self.assertNotIn("\x1b", result.stderr)


    @unittest.skipUnless(os.name == "posix", "signals and process groups require POSIX")
    def test_cli_interruption_publishes_no_verdict_after_child_cleanup(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            git(repo, "commit", "-q", "--allow-empty", "-m", "base")
            (repo / "source.txt").write_text("review me\n")
            ready = root / "ready"
            executable = write_executable(root / "codex", f'''#!/usr/bin/env python3
import os
from pathlib import Path
import sys
import time
if "--version" in sys.argv:
    print("codex-cli 0.0.0-test")
    raise SystemExit(0)
if "login" in sys.argv:
    raise SystemExit(1)
sys.stdin.read()
ready = Path({str(ready)!r})
ready.with_suffix(".tmp").write_text(str(os.getpid()))
ready.with_suffix(".tmp").replace(ready)
time.sleep(60)
''')
            # Empty homes and an inert CLI keep this process test offline and unauthenticated.
            env = {"PATH": os.environ.get("PATH", os.defpath), "HOME": str(root),
                   "USERPROFILE": str(root), "CODEX_HOME": str(root),
                   # Without OS temp settings, macOS Python chooses shared /tmp
                   # and isolation refuses startup before this test can signal it.
                   "TMPDIR": str(root)}
            if "AUTOREVIEW_GIT" in os.environ:
                env["AUTOREVIEW_GIT"] = os.environ["AUTOREVIEW_GIT"]
            cases = ((signal.SIGTERM, True, None), (signal.SIGINT, True, None),
                     (signal.SIGTERM, False, None), (signal.SIGTERM, False, "stderr"),
                     (signal.SIGTERM, True, "stdout"), (signal.SIGTERM, False, "both"))
            for signum, writable, closed in cases:
                with self.subTest(signum=signum, writable=writable, closed=closed):
                    ready.unlink(missing_ok=True)
                    destination = root / f"status-{signum}-{writable}-{closed}"
                    destination.mkdir()
                    sidecar = destination / "status.json"
                    report, human = root / "result.json", root / "result.txt"
                    argv = [sys.executable, str(SCRIPT), "--mode", "local", "--engine", "codex",
                            "--codex-bin", str(executable), "--codex-no-fallback", "--no-web-search",
                            "--status-output", str(sidecar), "--json-output", str(report),
                            "--output", str(human)]
                    with subprocess.Popen(argv, cwd=repo, env=env, text=True,
                                          stdout=subprocess.PIPE, stderr=subprocess.PIPE) as proc:
                        try:
                            deadline = time.monotonic() + 20
                            while not ready.exists() and proc.poll() is None and time.monotonic() < deadline:
                                time.sleep(0.01)
                            self.assertTrue(ready.exists(), "inert reviewer did not start")
                            child_pid = int(ready.read_text())
                            if not writable:
                                destination.rmdir()  # Simulate storage lost after output preflight.
                            # Cancellation can also close the observer's diagnostic pipes.
                            for name in ("stdout", "stderr"):
                                if closed in (name, "both"):
                                    getattr(proc, name).close()
                                    setattr(proc, name, None)
                            # Signal only the helper: its existing handler must stop the owned child.
                            proc.send_signal(signum)
                            stdout, stderr = proc.communicate(timeout=10)
                            self.assertEqual(proc.returncode, 128 + signum, (stdout or "") + (stderr or ""))
                            with self.assertRaises(ProcessLookupError):
                                os.killpg(child_pid, 0)
                            self.assertFalse(report.exists())
                            self.assertFalse(human.exists())
                            if not writable:
                                self.assertFalse(sidecar.exists())
                                if closed not in ("stderr", "both"):
                                    self.assertIn("interrupted status could not be written", stderr)
                                continue
                            outcome = json.loads(sidecar.read_text())
                            self.assertEqual(outcome["status"], "interrupted")
                            self.assertEqual(outcome["reason"], "interrupted")
                            self.assertEqual(outcome["exit_code"], 128 + signum)
                            self.assertEqual(outcome["signal_number"], signum)
                            self.assertFalse(outcome["report_produced"])
                            self.assertFalse(outcome["timed_out"])
                            self.assertIsNone(outcome["reviewer_exit_code"])
                        finally:
                            if proc.poll() is None:
                                proc.terminate()
                                proc.communicate(timeout=10)

    @unittest.skipUnless(os.name == "posix", "closed pipe requires POSIX")
    def test_output_finalization_preserves_normal_run_io_errors(self) -> None:
        for code in (0, 1, 2, 143):
            with self.subTest(code=code):
                reader, writer = os.pipe()
                os.close(reader)
                stream = os.fdopen(writer, "w")
                def pending_output():
                    print("pending diagnostic", end="")
                    return code
                try:
                    # Exercise real finalization against a closed pipe; only the
                    # main result is supplied so ordinary exits stay observable.
                    with mock.patch.dict(self.helper["sanitized_main"].__globals__,
                                         {"main": pending_output}), \
                            contextlib.redirect_stdout(stream), contextlib.redirect_stderr(io.StringIO()):
                        if code == 143:
                            self.assertEqual(self.helper["sanitized_main"](), code)
                            stream.flush()  # Interpreter shutdown must not fail again.
                        else:
                            with self.assertRaises(BrokenPipeError):
                                self.helper["sanitized_main"]()
                finally:
                    with contextlib.suppress(OSError):
                        stream.close()

    @unittest.skipIf(os.name == "nt", "the executable fixture is POSIX-only")
    def test_cli_codex_model_fallback_opt_out_preserves_failed_terminal(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            git(repo, "commit", "-q", "--allow-empty", "-m", "base")
            (repo / "source.txt").write_text("review me\n")
            env = {key: value for key, value in os.environ.items()
                   if not key.startswith("AUTOREVIEW_") or key == "AUTOREVIEW_GIT"}
            env.update({"HOME": str(root), "USERPROFILE": str(root), "CODEX_HOME": str(root),
                        "AUTOREVIEW_FAKE_RECORD": str(root / "record.json")})
            for primary, fallback in (("gpt-6.1-sol", "gpt-6-sol"), ("gpt-6-sol", "gpt-6-luna"), ("gpt-5.6-sol", "gpt-5.6-terra")):
                # Even a schema-valid output file cannot override the failing child exit.
                failure = (
                    'model = args[args.index("--model") + 1]\n'
                    f'if model == {primary!r}:\n'
                    '    print(json.dumps({"type": "error", "message": '
                    'f"The model {model} does not exist or you do not have access to it."}))\n'
                    '    raise SystemExit(17)\n'
                )
                executable = write_executable(root / "codex", fake_codex_script().replace(
                    'print("fake codex ok")', failure + 'print("fake codex ok")',
                ))
                for disabled in (True, False):
                    with self.subTest(primary=primary, disabled=disabled):
                        outputs = root / f"{primary}-{disabled}"
                        outputs.mkdir()
                        invocations = outputs / "invocations.jsonl"
                        sidecar, report = outputs / "status.json", outputs / "result.json"
                        env["AUTOREVIEW_FAKE_CODEX_INVOCATIONS"] = str(invocations)
                        argv = [sys.executable, str(SCRIPT), "--mode", "local", "--engine", "codex",
                                "--model", primary, "--no-web-search", "--codex-bin", str(executable),
                                "--status-output", str(sidecar), "--json-output", str(report)]
                        if disabled:
                            argv.append("--codex-no-fallback")
                        planned = subprocess.run(argv + ["--dry-run"], cwd=repo, env=env, text=True, capture_output=True, timeout=30)
                        self.assertEqual(planned.returncode, 0, planned.stdout + planned.stderr)
                        policy = "codex_fallback: disabled (model and authentication route)"
                        self.assertEqual(policy in planned.stdout, disabled)
                        self.assertEqual(f"fallback_model: {fallback}" in planned.stdout, not disabled)
                        self.assertFalse(report.exists())
                        result = subprocess.run(argv, cwd=repo, env=env, text=True, capture_output=True, timeout=30)
                        self.assertEqual(result.returncode, 1 if disabled else 0, result.stdout + result.stderr)
                        self.assertEqual(policy in result.stdout, disabled)
                        self.assertEqual(f"fallback_model: {fallback}" in result.stdout, not disabled)
                        attempts = [json.loads(line)["argv"] for line in invocations.read_text().splitlines()]
                        models = [args[args.index("--model") + 1] for args in attempts if "exec" in args]
                        self.assertEqual(models, [primary] if disabled else [primary, fallback])
                        outcome = json.loads(sidecar.read_text())
                        self.assertEqual(outcome["status"], "reviewer_unavailable" if disabled else "scoped-clean")
                        self.assertEqual(outcome["report_produced"], not disabled)
                        if disabled:
                            self.assertEqual(outcome["reason"], "engine_failed")
                            self.assertEqual(outcome["reviewer_exit_code"], 17)
                            self.assertFalse(outcome["timed_out"])
                            self.assertFalse(report.exists())
                            self.assertNotIn("scoped-clean:", result.stdout)
                            self.assertNotIn("retrying with", result.stderr)
                        else:
                            self.assertEqual(json.loads(report.read_text())["findings"], [])
                            self.assertIn(f"retrying with {fallback}", result.stderr)

    def test_tracked_binary_changes_are_blocked_in_all_modes(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            binary = repo / "artifact.bin"
            binary.write_bytes(b"\0base")
            git(repo, "add", "artifact.bin")
            git(repo, "commit", "-q", "-m", "base")
            base = git(repo, "rev-parse", "HEAD").strip()

            binary.write_bytes(b"\0changed")
            for staged in (False, True):
                if staged:
                    git(repo, "add", "artifact.bin")
                for local_base in (None, base):
                    with self.subTest(staged=staged, base=local_base), self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                        self.helper["local_bundle"](repo, local_base)

            git(repo, "commit", "-q", "-m", "binary change")
            with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                self.helper["commit_bundle"](repo, "HEAD")
            with self.assertRaisesRegex(SystemExit, "refusing binary changes"):
                self.helper["branch_bundle"](repo, base)

    def test_gitlink_additions_include_metadata_in_all_modes(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            tracked = repo / "tracked.txt"
            tracked.write_text("base\n", encoding="utf-8")
            git(repo, "add", "tracked.txt")
            git(repo, "commit", "-q", "-m", "base")
            base = git(repo, "rev-parse", "HEAD").strip()

            git(
                repo,
                "update-index",
                "--add",
                "--cacheinfo",
                f"160000,{base},vendor/dependency",
            )
            (repo / "vendor" / "dependency").mkdir(parents=True)
            for local_base in (None, base):
                with self.subTest(base=local_base):
                    self.assertIn('"sha": "' + base + '"',
                                  self.helper["local_bundle"](repo, local_base).text)

            git(repo, "commit", "-q", "-m", "add gitlink")
            self.assertIn("# Gitlink Pin Changes", self.helper["commit_bundle"](repo, "HEAD").text)
            self.assertIn("# Gitlink Pin Changes", self.helper["branch_bundle"](repo, base).text)

    def test_gitlink_guard_parses_combined_raw_modes(self) -> None:
        raw_diff = (
            "::100644 100644 160000 "
            + ("a" * 40)
            + " "
            + ("b" * 40)
            + " "
            + ("c" * 40)
            + " MM\0vendor/dependency\0"
        )

        with self.assertRaisesRegex(SystemExit, "unsupported gitlink diff metadata"):
            self.helper["gitlink_records"](raw_diff)

    def test_codex_config_rejects_capability_bearing_overrides(self) -> None:
        for override in (
            'mcp_servers.review.command="touch /tmp/owned"',
            'notify=["sh", "-c", "touch /tmp/owned"]',
            'model_instructions_file="/tmp/hostile.md"',
            'model_providers.review_api.auth.command="/tmp/credential-sink"',
            'hooks.PreToolUse.command="touch /tmp/owned"',
            'app_server.listen="0.0.0.0:9000"',
            'app_server.max_input_text_chars.extra=1',
        ):
            with self.subTest(override=override), self.assertRaisesRegex(
                SystemExit,
                "unsafe Codex config override refused",
            ):
                self.helper["codex_config_overrides"](
                    argparse.Namespace(codex_config=[override])
                )

    def test_codex_config_accepts_safe_tuning_overrides(self) -> None:
        args = argparse.Namespace(
            codex_config=[
                'service_tier="fast"',
                'model_verbosity="low"',
                'model_reasoning_summary="concise"',
            ]
        )

        self.assertEqual(
            self.helper["codex_config_overrides"](args),
            args.codex_config,
        )

    def test_codex_input_text_limit_is_forwarded_as_bounded_startup_config(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for value, expected in (
                ("1", "1"), ("1048576", "1048576"), ("3145728", "3145728"),
                ("4194304", "4194304"), (" 3145728 ", "3145728"),
                ("\u00a03145728\u00a0", "3145728"), ("\n3145728\n", "3145728"),
            ):
                override = f"app_server.max_input_text_chars={value}"
                canonical = f"app_server.max_input_text_chars={expected}"
                for source in ("argument", "environment"):
                    with self.subTest(value=value, source=source), mock.patch.dict(
                        os.environ, {"AUTOREVIEW_CODEX_CONFIG": override}, clear=True,
                    ):
                        args = argparse.Namespace(
                            codex_bin=sys.executable, web_search=False, thinking=None,
                            codex_speed="default", codex_config=[override] if source == "argument" else [],
                        )
                        command = self.helper["codex_command"](
                            args, root, root, root, root / "schema.json", root / "output.json",
                            "fixture-model", auth_config=[],
                        )
                        self.assertIn(canonical, command)
                        index = command.index(canonical)
                        self.assertEqual(command[index - 1], "-c")
                        self.assertLess(index, command.index("exec"))
                        self.assertEqual(command.count(canonical), 1)

    def test_codex_input_text_limit_rejects_invalid_values_from_both_inputs(self) -> None:
        for value in ("0", "-1", "+1", "01", "4194305", "1.5", "1e6", '"3145728"',
                      "true", "0x100000", "3_145_728", "١", "9" * 5000,
                      "3145728\nnotify=['untrusted']"):
            override = f"app_server.max_input_text_chars={value}"
            for source in ("argument", "environment"):
                with self.subTest(value=value[:40], source=source), mock.patch.dict(
                    os.environ, {"AUTOREVIEW_CODEX_CONFIG": override}, clear=True,
                ), self.assertRaisesRegex(SystemExit, "integer from 1 to 4194304"):
                    self.helper["codex_config_overrides"](argparse.Namespace(
                        codex_config=[override] if source == "argument" else [],
                    ))

    def test_codex_speed_override_accepts_ultrafast(self) -> None:
        override = self.helper["codex_speed_override"]
        with mock.patch.dict(os.environ, {"AUTOREVIEW_CODEX_SPEED": ""}):
            self.assertEqual(
                override(argparse.Namespace(codex_speed="ultrafast")),
                'service_tier="ultrafast"',
            )
        with mock.patch.dict(os.environ, {"AUTOREVIEW_CODEX_SPEED": " UltraFast "}):
            self.assertEqual(
                override(argparse.Namespace(codex_speed=None)),
                'service_tier="ultrafast"',
            )
        with mock.patch.dict(os.environ, {"AUTOREVIEW_CODEX_SPEED": "warp"}):
            with self.assertRaisesRegex(SystemExit, "valid: fast, ultrafast, flex, default"):
                override(argparse.Namespace(codex_speed=None))

    def test_untracked_files_respect_trusted_global_excludes(self) -> None:
        cases = [("external", "global-ignore"), ("missing", "global-ignore"),
                 ("inside", "global-ignore")]
        if os.name != "nt":
            cases.extend([("external", "global\rignore"), ("external", "global-ignore ")])
        for location, name in cases:
            with self.subTest(location=location, name=name), tempfile.TemporaryDirectory() as tempdir:
                root = Path(tempdir)
                repo = init_repo(root)
                home = root / "home"
                home.mkdir()
                excludes = (repo if location == "inside" else root) / name
                if location != "missing":
                    excludes.write_text("ignored.local\n!settings.local\n", encoding="utf-8")
                if location == "inside":
                    git(repo, "add", "--", name)
                git(repo, "config", "--file", str(home / ".gitconfig"),
                    "core.excludesFile", str(excludes))
                (repo / "ignored.local").write_text("private notes\n", encoding="utf-8")
                (repo / ".gitignore").write_text("settings.local\n", encoding="utf-8")
                (repo / "settings.local").write_text("repo private\n", encoding="utf-8")
                git(repo, "add", ".gitignore")
                (repo / "visible.txt").write_text("review me\n", encoding="utf-8")
                (repo / "hostile-gitconfig").write_text(
                    "[core]\n\texcludesFile = /does/not/exist\n", encoding="utf-8",
                )
                with mock.patch.dict(os.environ, {
                    "HOME": str(home), "USERPROFILE": str(home),
                    "GIT_CONFIG_GLOBAL": str(repo / "hostile-gitconfig"),
                }):
                    expected = ["hostile-gitconfig", "visible.txt"]
                    if location != "external":
                        expected.insert(1, "ignored.local")
                    self.assertEqual(
                        [rel for rel, _ in self.helper["collect_untracked_file_snapshots"](repo)[0]],
                        expected,
                    )

    def test_dirty_check_respects_trusted_global_excludes(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            home = root / "home"
            home.mkdir()
            excludes = root / "global-ignore"
            excludes.write_text("ignored.local\n", encoding="utf-8")
            (home / ".gitconfig").write_text(
                f"[core]\n\texcludesFile = {excludes.as_posix()}\n",
                encoding="utf-8",
            )
            (repo / "ignored.local").write_text("private notes\n", encoding="utf-8")

            with mock.patch.dict(
                os.environ,
                {
                    "HOME": str(home),
                    "USERPROFILE": str(home),
                },
            ):
                self.assertFalse(self.helper["is_dirty"](repo))

    def test_large_untracked_text_is_captured_completely(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            content = "界\r\n" * 50_000 + "COMPLETE_UNTRACKED_TAIL\n"
            untracked = repo / "untracked.txt"
            untracked.write_bytes(content.encode("utf-8"))
            captured = self.helper["local_bundle"](repo)
            records = re.findall(r"^source-line \d+: (.*)$", captured.text, re.MULTILINE)
            self.assertEqual("".join(json.loads(record) for record in records), content)
            passes = self.helper["build_review_prompts"](
                repo, "local", None, captured, "", [], 50_000,
            )
            self.assertGreater(len(passes), 1)
            self.assertEqual("".join(prompt.split("# Change Bundle\n", 1)[1] for prompt in passes), captured.text)

    def test_branch_bundle_rejects_unsafe_or_unknown_base_before_diff(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "tracked.txt").write_text("base\n", encoding="utf-8")
            git(repo, "add", "tracked.txt")
            git(repo, "commit", "-q", "-m", "base")

            with self.assertRaisesRegex(SystemExit, "unsafe base ref"):
                self.helper["branch_bundle"](repo, "--help")
            with self.assertRaisesRegex(SystemExit, "unknown base ref"):
                self.helper["branch_bundle"](repo, "origin/main")

    def test_commit_bundle_rejects_merge_commits(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "base.txt").write_text("base\n", encoding="utf-8")
            git(repo, "add", "base.txt")
            git(repo, "commit", "-q", "-m", "base")
            base_branch = git(repo, "branch", "--show-current").strip()
            git(repo, "checkout", "-q", "-b", "side")
            (repo / "side.txt").write_text("side\n", encoding="utf-8")
            git(repo, "add", "side.txt")
            git(repo, "commit", "-q", "-m", "side")
            git(repo, "checkout", "-q", base_branch)
            (repo / "main.txt").write_text("main\n", encoding="utf-8")
            git(repo, "add", "main.txt")
            git(repo, "commit", "-q", "-m", "main")
            git(repo, "merge", "-q", "--no-ff", "side", "-m", "merge")

            shallow = Path(tempdir) / "shallow"
            git(repo, "clone", "-q", "--depth=1", repo.resolve().as_uri(), str(shallow))
            for checkout in (repo, shallow):
                with self.subTest(checkout=checkout.name), self.assertRaisesRegex(
                    SystemExit, "does not accept merge commits"
                ):
                    self.helper["commit_bundle"](checkout, "HEAD")

    def test_commit_review_uses_raw_parents_at_history_boundaries(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir).resolve()
            repo = init_repo(root)
            git(repo, "config", "core.autocrlf", "false")
            (repo / "behavior.py").write_text("def behavior(): return 'preexisting'\n", encoding="utf-8")
            git(repo, "add", "behavior.py")
            git(repo, "commit", "-qm", "initial behavior")
            initial = git(repo, "rev-parse", "HEAD").strip()
            for content in (b"before\n", b"after\r\n"):
                (repo / "unrelated.txt").write_bytes(content)
                git(repo, "add", "unrelated.txt")
                git(repo, "commit", "-qm", "unrelated maintenance")
            expected_parent = git(repo, "rev-parse", "HEAD^").strip()
            expected_patch = fixture_git(
                repo, "diff", *self.helper["SAFE_DIFF_FLAGS"], "HEAD^", "HEAD",
                check=True, capture_output=True,
            ).stdout.decode("utf-8")
            for state, depth in (("missing", 1), ("available", 2), ("retained", None)):
                with self.subTest(state=state):
                    checkout = root / state
                    depth_args = [f"--depth={depth}"] if depth else []
                    git(repo, "clone", "-q", *depth_args, repo.as_uri(), str(checkout))
                    if state == "retained":
                        git(checkout, "fetch", "-q", "--depth=1", "origin")
                    self.assertEqual(git(checkout, "rev-parse", "--is-shallow-repository").strip(), "true")
                    if state == "missing":
                        # Missing history stays unknown even without a shallow marker.
                        for marked in (True, False):
                            if not marked:
                                (checkout / ".git" / "shallow").unlink()
                            with self.subTest(marked=marked), self.assertRaisesRegex(
                                SystemExit, "missing parent.*deepen"
                            ):
                                self.helper["build_bundle"](checkout, "commit", None, "HEAD")
                        continue
                    captured = self.helper["build_bundle"](checkout, "commit", None, "HEAD")
                    self.assertIn(f"parent: {expected_parent}\n", captured.text)
                    self.assertIn(expected_patch, captured.text)
                    self.assertNotIn("behavior.py", captured.text)
                    self.assertEqual(captured.paths, {"unrelated.txt"})
            git(repo, "replace", "--graft", "HEAD")
            captured = self.helper["build_bundle"](repo, "commit", None, "HEAD")
            self.assertIn(f"parent: {expected_parent}\n", captured.text)
            self.assertIn(expected_patch, captured.text)
            self.assertNotIn("behavior.py", captured.text)
            self.assertEqual(captured.paths, {"unrelated.txt"})
            captured = self.helper["build_bundle"](repo, "commit", None, initial)
            self.assertIn("parent: none (verified raw root)\n", captured.text)
            self.assertIn("+def behavior(): return 'preexisting'", captured.text)
            self.assertEqual(captured.paths, {"behavior.py"})
            tree = git(repo, "rev-parse", f"{initial}^{{tree}}").strip()
            graft_parents = [git(repo, "commit-tree", tree, "-m", f"graft {index}").strip() for index in range(2)]
            for count in (1, 2):
                with self.subTest(graft_parents=count):
                    (repo / ".git/info/grafts").write_text(" ".join([initial, *graft_parents[:count]]) + "\n")
                    captured = self.helper["build_bundle"](repo, "commit", None, initial)
                    self.assertIn("parent: none (verified raw root)\n", captured.text)
                    self.assertIn("+def behavior(): return 'preexisting'", captured.text)
                    self.assertEqual(captured.paths, {"behavior.py"})
                    self.assertEqual(self.helper["git"](repo, "rev-list", "--parents", "-n", "1", initial).split(), [initial])

    def test_commit_review_keeps_identity_separators_out_of_parent_records(self) -> None:
        for codepoint in (11, 12, 13, 28, 29, 30, 0x85, 0x2028, 0x2029):
            with self.subTest(codepoint=codepoint), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                (repo / "code.py").write_text("root_content = True\n", encoding="utf-8")
                git(repo, "add", "code.py")
                name = f"A{chr(codepoint)}parent HEAD{chr(codepoint)}B"
                git(repo, "commit", "-qm", "root", "--author", f"{name} <author@example.invalid>")
                raw = self.helper["git_bytes"](repo, "cat-file", "-p", "HEAD").stdout
                self.assertIn(f"author {name}".encode(), raw)
                self.assertNotIn(b"\nparent ", raw.partition(b"\n\n")[0])
                captured = self.helper["build_bundle"](repo, "commit", None, "HEAD")
                self.assertIn("parent: none (verified raw root)\n", captured.text)
                self.assertIn("+root_content = True", captured.text)
                self.assertEqual(captured.paths, {"code.py"})

    def test_commit_review_follows_only_contiguous_full_parent_ids(self) -> None:
        for algorithm in ("sha1", "sha256"):
            with self.subTest(algorithm=algorithm), tempfile.TemporaryDirectory() as tempdir:
                root = Path(tempdir)
                repo = root / "repo"
                repo.mkdir()
                git(repo, "init", "-q", f"--object-format={algorithm}")
                (repo / "code.py").write_text("root_content = True\n", encoding="utf-8")
                git(repo, "add", "code.py")
                git(repo, "commit", "-qm", "root")
                initial = git(repo, "rev-parse", "HEAD").strip()
                raw = self.helper["git_bytes"](repo, "cat-file", "-p", "HEAD").stdout
                headers, body = raw.split(b"\n\n", 1)
                tree, identity = headers.split(b"\n", 1)
                for label, parent in (
                    ("late", initial.encode()),
                    ("uppercase", initial.upper().encode()),
                    ("symbolic", b"HEAD"),
                    ("short", initial[:12].encode()),
                    ("CR-suffix", initial.encode() + bytes([13])),
                ):
                    with self.subTest(label=label):
                        candidate_headers = (
                            headers + b"\nparent " + parent if label == "late"
                            else tree + b"\nparent " + parent + b"\n" + identity
                        )
                        payload = root / "candidate.commit"
                        payload.write_bytes(candidate_headers + b"\n\n" + body)
                        commit = git(repo, "hash-object", "--literally", "-t", "commit", "-w", str(payload)).strip()
                        if label not in ("late", "uppercase"):
                            with self.assertRaises(SystemExit):
                                self.helper["build_bundle"](repo, "commit", None, commit)
                            continue
                        captured = self.helper["build_bundle"](repo, "commit", None, commit)
                        if label == "late":
                            self.assertEqual(git(repo, "rev-list", "--parents", "-n", "1", commit).split(), [commit])
                            self.assertIn("parent: none (verified raw root)\n", captured.text)
                            self.assertIn("+root_content = True", captured.text)
                            self.assertEqual(captured.paths, {"code.py"})
                        else:
                            self.assertIn(f"parent: {parent.decode()}\n", captured.text)
                            self.assertEqual(captured.paths, set())

    def test_repo_root_preserves_exact_native_paths(self) -> None:
        names = ["repo"]
        if os.name != "nt":
            names.extend(["repo\rname", "repo "])
        for name in names:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as tempdir:
                root = Path(tempdir)
                repo = init_repo(root)
                if name != repo.name:
                    repo = repo.rename(root / name)
                nested = repo / "nested"
                nested.mkdir()
                previous = Path.cwd()
                try:
                    os.chdir(nested)
                    self.assertEqual(self.helper["repo_root"](), repo.resolve())
                finally:
                    os.chdir(previous)

    def test_git_path_list_preserves_newline_filenames(self) -> None:
        if os.name == "nt":
            self.skipTest("Windows filesystems do not support newline path components")
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            names = [f"line{separator}break.txt" for separator in ("\n", "\r", "\r\n", "\t")]
            for rel in names:
                (repo / rel).write_text("content\n", encoding="utf-8")
                git(repo, "add", "--", rel)

            paths = self.helper["git_path_list"](repo, "ls-files", "-z")

            self.assertCountEqual(paths, names)

    @unittest.skipUnless(sys.platform.startswith("linux"), "requires raw non-UTF-8 filename support")
    def test_git_path_list_rejects_non_utf8_output(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            rel = os.fsdecode(b"invalid-\xff.txt")
            (repo / rel).write_text("content\n", encoding="utf-8")
            git(repo, "add", "--", rel)

            with self.assertRaisesRegex(SystemExit, "non-UTF-8 Git output"):
                self.helper["git_path_list"](repo, "ls-files", "-z")

    def test_review_patch_accepts_large_content_without_explicit_limit(self) -> None:
        patch = (
            "diff --git a/safe.txt b/safe.txt\n"
            "--- a/safe.txt\n"
            "+++ b/safe.txt\n"
            "@@ -0,0 +1,100000 @@\n"
            + "+safe review content\n" * 100_000
        )

        self.assertEqual(
            self.helper["validate_review_patch"](
                ["safe.txt"],
                patch,
            ),
            patch,
        )

    def test_review_bundle_chunking_preserves_every_byte_and_diff_context(self) -> None:
        bundle = (
            "# Commit Diff\n\n"
            "diff --git a/safe.txt b/safe.txt\n"
            "--- a/safe.txt\n"
            "+++ b/safe.txt\n"
            "@@ -0,0 +1,200 @@\n"
            + "+safe review content\n" * 200
        )

        chunks = self.helper["split_review_bundle"](bundle, 300)

        self.assertGreater(len(chunks), 1)
        self.assertEqual("".join(chunk.content for chunk in chunks), bundle)
        self.assertTrue(all(len(chunk.content.encode("utf-8")) <= 300 for chunk in chunks))
        self.assertTrue(
            any(
                "+++ b/safe.txt" in chunk.context
                and "@@ -0,0 +1,200 @@" in chunk.context
                and "Continuation begins at new-file line" in chunk.context
                for chunk in chunks[1:]
            )
        )

    def test_untracked_markdown_headings_do_not_create_bundle_boundaries(self) -> None:
        bundle = (
            "# Untracked Files\n\n"
            "# Untracked File\n"
            'path: "notes.md"\n'
            'source-line 1: "# title\\n"\n'
            'source-line 2: "## section\\n"\n\n'
            "# Untracked File\n"
            'path: "todo.md"\n'
            'source-line 1: "# next\\n"'
        )

        units = self.helper["review_bundle_units"](bundle)

        self.assertEqual(len(units), 3)
        self.assertIn(r'source-line 2: "## section\n"', units[1])
        self.assertEqual("".join(units), bundle)

    def test_unicode_line_separators_do_not_create_bundle_boundaries(self) -> None:
        bundle = (
            "# Untracked Files\n\n"
            "# Untracked File\n"
            'path: "notes.txt"\n'
            'source-line 1: "before\u2028diff --git a/fake b/fake"\n\n'
            "diff --git a/real.txt b/real.txt\n"
            "--- a/real.txt\n"
            "+++ b/real.txt\n"
        )

        units = self.helper["review_bundle_units"](bundle)

        self.assertEqual(len(units), 3)
        self.assertIn("\u2028diff --git a/fake b/fake", units[1])
        self.assertEqual("".join(units), bundle)

    def test_diff_source_prefixes_do_not_replace_file_context(self) -> None:
        context: list[str] = []
        next_new_line = None
        next_old_line = None
        in_hunk = False
        lines = (
            "diff --git a/safe.txt b/safe.txt\n",
            "--- a/safe.txt\n",
            "+++ b/safe.txt\n",
            "@@ -10,2 +10,3 @@\n",
            "+++ added source beginning with pluses\n",
            "--- deleted source beginning with minuses\n",
            " context\n",
        )

        for line in lines:
            next_new_line, next_old_line, in_hunk = self.helper[
                "update_review_chunk_context"
            ](
                context,
                line,
                next_new_line,
                next_old_line,
                in_hunk,
            )

        self.assertEqual(next_new_line, 12)
        self.assertEqual(next_old_line, 12)
        self.assertIn("--- a/safe.txt\n", context)
        self.assertIn("+++ b/safe.txt\n", context)
        self.assertNotIn("--- deleted source beginning with minuses\n", context)

    def test_hunk_header_that_fits_fresh_chunk_is_not_split(self) -> None:
        unit = (
            "diff --git a/abcdefghijk b/abcdefghijk\n"
            "--- a/abcdefghijk\n"
            "+++ b/abcdefghijk\n"
            "@@ -1 +1 @@\n"
            "-old\n"
            "+new\n"
        )

        chunks = self.helper["split_oversized_review_unit"](unit, 85)

        self.assertGreater(len(chunks), 1)
        self.assertTrue(any("@@ -1 +1 @@\n" in chunk.content for chunk in chunks))
        self.assertEqual("".join(chunk.content for chunk in chunks), unit)

    def test_long_diff_line_continuations_keep_their_original_marker(self) -> None:
        for marker in ("+", "-", " "):
            with self.subTest(marker=marker):
                unit = (
                    "diff --git a/large.txt b/large.txt\n"
                    "--- a/large.txt\n"
                    "+++ b/large.txt\n"
                    "@@ -1 +1 @@\n"
                    f"{marker}{'x' * 400}\n"
                )

                chunks = self.helper["split_oversized_review_unit"](unit, 140)

                self.assertTrue(
                    any(
                        f"original marker is `{marker}`" in chunk.context
                        for chunk in chunks[1:]
                    )
                )
                self.assertEqual("".join(chunk.content for chunk in chunks), unit)

    def test_multiple_long_line_tails_pack_into_following_chunks(self) -> None:
        limit = 200
        unit = (
            "diff --git a/large.txt b/large.txt\n"
            "--- a/large.txt\n"
            "+++ b/large.txt\n"
            "@@ -1,5 +1,5 @@\n"
            + ("+" + "x" * 205 + "\n") * 5
        )

        chunks = self.helper["split_oversized_review_unit"](unit, limit)
        minimum_chunks = (len(unit.encode("utf-8")) + limit - 1) // limit

        self.assertLessEqual(len(chunks), minimum_chunks + 1)
        self.assertEqual("".join(chunk.content for chunk in chunks), unit)
        self.assertTrue(all(len(chunk.content.encode("utf-8")) <= limit for chunk in chunks))

    def test_untracked_continuation_context_keeps_source_line(self) -> None:
        unit = (
            "# Untracked File\n"
            'path: "notes.txt"\n'
            'source-line 1: "short\\n"\n'
            f'source-line 2: "{"x" * 300}"\n'
        )

        chunks = self.helper["split_oversized_review_unit"](unit, 120)

        self.assertGreater(len(chunks), 2)
        self.assertTrue(
            any(
                "Continuation begins at untracked source line 2" in chunk.context
                for chunk in chunks[1:]
            )
        )
        self.assertEqual("".join(chunk.content for chunk in chunks), unit)

    def test_deleted_file_continuation_uses_positive_old_line(self) -> None:
        unit = (
            "diff --git a/removed.txt b/removed.txt\n"
            "--- a/removed.txt\n"
            "+++ /dev/null\n"
            "@@ -40,50 +0,0 @@\n"
            + "-deleted content\n" * 50
        )

        chunks = self.helper["split_oversized_review_unit"](unit, 180)

        deletion_contexts = [
            chunk.context for chunk in chunks[1:] if "old-file line" in chunk.context
        ]
        self.assertTrue(deletion_contexts)
        self.assertTrue(all("line 0" not in context for context in deletion_contexts))
        self.assertTrue(all("--- a/removed.txt" in context for context in deletion_contexts))

    def test_long_complete_context_is_retained_or_rejected(self) -> None:
        path = "nested/" + "x" * 10_000 + ".txt"
        context = [
            f'diff --git "a/{path}" "b/{path}"\n',
            f'--- "a/{path}"\n',
            f'+++ "b/{path}"\n',
            "@@ -1 +1 @@\n",
        ]

        rendered = self.helper["review_chunk_context"](context, 2, 2)

        self.assertIn(f'+++ "b/{path}"', rendered)
        self.assertIn("@@ -1 +1 @@", rendered)
        self.assertIn("Continuation begins at new-file line 2", rendered)

    def test_review_bundle_packs_oversized_unit_tails_globally(self) -> None:
        limit = 1_000
        units = []
        for index in range(5):
            header = (
                f"diff --git a/file-{index}.txt b/file-{index}.txt\n"
                f"--- a/file-{index}.txt\n"
                f"+++ b/file-{index}.txt\n"
                "@@ -0,0 +1 @@\n"
            )
            body = "+" + "x" * (1_100 - len(header.encode("utf-8")) - 2) + "\n"
            units.append(header + body)
        bundle = "".join(units)

        chunks = self.helper["split_review_bundle"](bundle, limit)

        self.assertEqual(len(chunks), 6)
        self.assertEqual("".join(chunk.content for chunk in chunks), bundle)
        self.assertTrue(all(len(chunk.content.encode("utf-8")) <= limit for chunk in chunks))

    def test_large_bundle_stays_single_pass_until_prompt_limit(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            prompts = self.helper["build_review_prompts"](
                repo,
                "commit",
                "HEAD",
                "# Commit Diff\n" + "safe review content\n" * 18_000,
                "",
                [],
            )

        self.assertEqual(len(prompts), 1)

    def test_bundle_above_prompt_limit_uses_complete_bounded_passes(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            for line_count, minimum_passes in ((35_000, 2), (200_000, 9)):
                with self.subTest(line_count=line_count):
                    bundle = "# Commit Diff\n" + "".join(
                        f"+review line {index}: \U0001f99e\n" for index in range(line_count)
                    )
                    prompts = self.helper["build_review_prompts"](
                        repo, "commit", "HEAD", bundle, "", []
                    )

                    self.assertGreaterEqual(len(prompts), minimum_passes)
                    self.assertEqual(
                        "".join(prompt.split("# Change Bundle\n", 1)[1] for prompt in prompts),
                        bundle,
                    )
                    for index, prompt in enumerate(prompts, 1):
                        self.assertLessEqual(
                            len(prompt.encode("utf-8")), self.helper["MAX_REVIEW_PROMPT_BYTES"]
                        )
                        self.assertIn(f"Oversized review bundle chunk: {index}/{len(prompts)}", prompt)

    def test_change_partitions_keep_complete_datasets_when_context_fits(self) -> None:
        def sized_content(size: int) -> str:
            line = "synthetic owner \U0001f99e\r\n"
            repeats, padding = divmod(size - 2, len(line.encode("utf-8")))
            return line * repeats + "x" * padding + " \t"

        dataset = self.helper["ReviewDataset"]
        render = self.helper["render_datasets"]
        instructions = (
            "Review the complete change against the supplied owner modules, callers and tests.\n"
            "Preserve source attribution and distinguish current behavior from intended behavior.\n"
            "Report concrete P0-P2 findings; incomplete evidence is not proof of missing behavior.\n"
        )
        header = (
            "diff --git a/source.py b/source.py\n"
            "--- a/source.py\n+++ b/source.py\n@@ -0,0 +1 @@\n"
        )
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            for context_bytes, change_bytes in ((430_139, 343_560), (437_973, 112_941)):
                with self.subTest(context_bytes=context_bytes, change_bytes=change_bytes):
                    paths = [f"owners/module-{index:02d}/source.py" for index in range(25)]
                    size, remainder = divmod(context_bytes, len(paths))
                    datasets = [dataset(path, sized_content(size + (index < remainder)))
                                for index, path in enumerate(paths)]
                    rendered = render(datasets)
                    self.assertEqual(sum(len(item.content.encode("utf-8")) for item in datasets), context_bytes)
                    self.assertGreater(len(rendered.encode("utf-8")), context_bytes)
                    tail = "+\U0001f99e \t\r\n"
                    padding = change_bytes - len((header + tail).encode("utf-8"))
                    bundle = header + "+\U0001f99e" + "x" * padding + " \t\r\n"
                    self.assertEqual(len(bundle.encode("utf-8")), change_bytes)
                    with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                        "optimize_evidence_plan": mock.Mock(side_effect=AssertionError("complete context is preferred")),
                    }):
                        prompts = self.helper["build_review_prompts"](
                            repo, "branch", "base", bundle, instructions, datasets, 512_000,
                        )
                    self.assertGreater(len(prompts), 1)
                    with contextlib.redirect_stdout(io.StringIO()):
                        with self.assertRaisesRegex(SystemExit, "no reviewer was started"):
                            self.helper["check_review_plan"](
                                argparse.Namespace(max_review_passes=len(prompts) - 1), prompts,
                            )
                        self.helper["check_review_plan"](
                            argparse.Namespace(max_review_passes=len(prompts)), prompts,
                        )
                    changes = []
                    for index, prompt in enumerate(prompts, 1):
                        self.assertLessEqual(len(prompt.encode("utf-8")), 512_000)
                        prefix, change = prompt.split("# Change Bundle\n", 1)
                        self.assertTrue(prefix.endswith(rendered + "\n\n"), "each pass needs complete owner context")
                        self.assertEqual(prefix.count("[Dataset byte offset: 0]"), len(datasets))
                        self.assertTrue(instructions in prefix)
                        self.assertFalse("Evidence batch:" in prefix)
                        if index > 1:
                            for context in ("# Continuation Context", "+++ b/source.py",
                                            "@@ -0,0 +1 @@", "original marker is `+`"):
                                self.assertTrue(context in prefix, context)
                        changes.append(change)
                    self.assertTrue("".join(changes).encode("utf-8") == bundle.encode("utf-8"),
                                    "change bytes must appear exactly once")

    def test_full_dataset_preference_rebatches_before_tiny_change_splits(self) -> None:
        budget, minimum = 512_000, 32_000
        render = self.helper["render_review_prompt"]
        split = self.helper["split_review_bundle"]
        dataset = self.helper["ReviewDataset"]
        render_data = self.helper["render_datasets"]
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            branch = self.helper["current_branch"](repo)
            overhead = len(render(branch, "branch", "base", self.helper["ReviewChunk"](""),
                                  "", render_data([dataset("owner.py", "")]), (999_999, 999_999)).encode())
            for capacity, hunk_bytes in ((4, 0), (minimum + 64, 6_000)):
                with self.subTest(capacity=capacity):
                    datasets = [dataset("owner.py", "e" * (budget - overhead - 4_096 - capacity))]
                    complete = render_data(datasets)
                    bundle = ("diff --git a/source.py b/source.py\n--- a/source.py\n+++ b/source.py\n"
                              "@@ -0,0 +1 @@ " + "h" * hunk_bytes + "\n+" + "x" * 120_000 + "\n")
                    preferred, split_limits = False, []

                    def observe_render(*args, **kwargs):
                        nonlocal preferred
                        preferred = args[5] == complete
                        return render(*args, **kwargs)

                    def bounded_split(text, limit):
                        if preferred:
                            self.assertGreaterEqual(limit, minimum, "rebatch before allocating tiny speculative chunks")
                            split_limits.append(limit)
                        return split(text, limit)

                    optimize = self.helper["optimize_evidence_plan"]

                    def probe_full_batch(baseline, available, change_bytes, evidence, build):
                        # Exercise the optimizer's one-batch retry, including a
                        # continuation correction that reduces change capacity.
                        self.assertIsNone(build(len(complete.encode()) + 128, len(baseline)))
                        return optimize(baseline, available, change_bytes, evidence, build)

                    with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                        "render_review_prompt": observe_render, "split_review_bundle": bounded_split,
                        "optimize_evidence_plan": probe_full_batch,
                    }):
                        prompts = self.helper["build_review_prompts"](
                            repo, "branch", "base", bundle, "", datasets, budget,
                        )
                    self.assertEqual(bool(split_limits), capacity != 4)
                    self.assertTrue(all(limit == capacity for limit in split_limits))
                    batches = {}
                    for prompt in prompts:
                        self.assertLessEqual(len(prompt.encode()), budget)
                        batch = re.search(r"Evidence batch: (\d+)/(\d+)", prompt)
                        self.assertIsNotNone(batch)
                        batches.setdefault(batch[1], []).append(prompt.split("# Change Bundle\n", 1)[1])
                    self.assertGreater(len(batches), 1)
                    self.assertTrue(all("".join(changes) == bundle for changes in batches.values()))

    def test_intact_prompt_initial_fallback_rebatches_small_evidence(self) -> None:
        budget = 512_000
        render_data = self.helper["render_datasets"]
        split = self.helper["split_review_bundle"]
        build = self.helper["build_change_review_prompts"]
        datasets = [self.helper["ReviewDataset"]("owner.py", "e" * 8_000)]
        complete = render_data(datasets)
        instructions = "i" * 480_000
        bundle = "diff --git a/source.py b/source.py\n--- a/source.py\n+++ b/source.py\n@@ -0,0 +1 @@\n+" + "x" * 60_000 + "\n"
        whole, full_attempts = False, []

        def observe_build(*args, **kwargs):
            nonlocal whole
            whole = args[5] == complete
            if whole:
                full_attempts.append(kwargs.get("min_change_bytes", 4))
            return build(*args, **kwargs)

        def bounded_split(text, limit):
            if whole:
                self.assertGreaterEqual(limit, 32_000, "initial fallback must rebatch complete evidence")
            return split(text, limit)

        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            with mock.patch.dict(self.helper["build_review_prompts"].__globals__, {
                "build_change_review_prompts": observe_build, "split_review_bundle": bounded_split,
            }):
                prompts = self.helper["build_review_prompts"](repo, "branch", "base", bundle, instructions, datasets, budget)
        self.assertGreaterEqual(len(full_attempts), 2)
        self.assertTrue(all(value == 32_000 for value in full_attempts))
        batches = {}
        for prompt in prompts:
            self.assertLessEqual(len(prompt.encode()), budget)
            self.assertIn(instructions, prompt)
            batch = re.search(r"Evidence batch: (\d+)/(\d+)", prompt)
            self.assertIsNotNone(batch)
            batches.setdefault(batch[1], []).append(prompt.split("# Change Bundle\n", 1)[1])
        self.assertGreater(len(batches), 1)
        self.assertTrue(all("".join(changes) == bundle for changes in batches.values()))

    def test_evidence_fallback_keeps_incomplete_passes_incomplete(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            prompts = self.helper["build_review_prompts"](
                repo, "branch", "base", "diff --git a/source.py b/source.py\n+changed\n", "",
                [self.helper["ReviewDataset"]("owner.py", "owner context\n" * 3_000)], 30_000,
            )
            self.assertGreater(len(prompts), 1)
            self.assertTrue(all("Evidence batch:" in prompt for prompt in prompts))
            args = argparse.Namespace(engine="codex", max_priority="P2")
            for incomplete_index in (0, len(prompts) - 1):
                with self.subTest(incomplete_index=incomplete_index):
                    engine = mock.Mock(side_effect=[json.dumps({
                        "findings": [], "overall_correctness": "patch is correct",
                        "overall_explanation": "Synthetic assessment.", "overall_confidence": 0.9,
                        "review_completion": "incomplete" if index == incomplete_index else "complete",
                    }) for index in range(len(prompts))])
                    with mock.patch.dict(self.helper["run_review_passes"].__globals__, {
                        "run_engine": engine,
                    }), contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                        results = self.helper["run_review_passes"](
                            args, [args], repo, prompts, {"source.py"},
                        )
                    self.assertEqual(engine.call_count, len(prompts))
                    report = self.helper["merge_chunk_reports"]([
                        (label, result.report) for label, result in results
                    ])
                    complete = all(result.complete for _, result in results)
                    self.assertFalse(complete)
                    self.assertEqual(self.helper["review_status"](report, complete=complete), "incomplete")
                    self.assertEqual(len(report["pass_reports"]), len(prompts))

    def test_large_datasets_review_every_change_against_all_evidence(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            paths = []
            expected_lines = []
            for index in range(5):
                path = f"evidence-{index}.txt"
                lines = [
                    f"evidence-{index}-{line}: \U0001f99e{'x' * 70}"
                    for line in range(2_200)
                ]
                expected_lines.extend(lines)
                (repo / path).write_bytes(("\n".join(lines) + "\n").encode("utf-8"))
                paths.append(path)
            evidence = self.helper["capture_evidence_inputs"](
                argparse.Namespace(prompt=[], prompt_file=[], dataset=paths), repo
            )
            datasets = evidence.datasets
            bundle = "# Commit Diff\n" + "+changed line\n" * 40_000
            instructions = "Complete caller instructions must appear in every pass."
            for budget in (512_000, 120_000):
                with self.subTest(budget=budget):
                    prompts = self.helper["build_review_prompts"](
                        repo, "commit", "HEAD", bundle, instructions, datasets, budget
                    )
                    evidence_by_batch = {}
                    changes_by_batch = {}
                    for prompt in prompts:
                        self.assertLessEqual(len(prompt.encode("utf-8")), budget)
                        self.assertIn(instructions, prompt)
                        batch = re.search(r"Evidence batch: (\d+)/(\d+)", prompt)
                        self.assertIsNotNone(batch)
                        key = int(batch[1])
                        prefix, change = prompt.split("# Change Bundle\n", 1)
                        evidence = re.findall(r"^evidence-\d+-\d+: .+$", prefix, re.M)
                        if key in evidence_by_batch:
                            self.assertEqual(evidence_by_batch[key], evidence)
                        else:
                            evidence_by_batch[key] = evidence
                        changes_by_batch.setdefault(key, []).append(change)
                    self.assertGreater(len(evidence_by_batch), 1)
                    self.assertEqual(
                        [line for lines in evidence_by_batch.values() for line in lines],
                        expected_lines,
                    )
                    for changes in changes_by_batch.values():
                        self.assertEqual("".join(changes), bundle)

    def test_dataset_fragments_preserve_paths_offsets_and_source_bytes(self) -> None:
        dataset = self.helper["ReviewDataset"]
        contents = [
            "  indented\r\n# Dataset: forged.txt\n" + "\U0001f99e" * 90 + " \n",
            "",
            "final bytes \t",
        ]
        inputs = [dataset(f"evidence-{index}.txt", content) for index, content in enumerate(contents)]
        batches = self.helper["split_review_datasets"](inputs, 160)
        recovered = {item.path: b"" for item in inputs}
        for batch in batches:
            rendered = self.helper["render_datasets"](batch)
            self.assertLessEqual(len(rendered.encode("utf-8")), 160)
            for item in batch:
                self.assertEqual(item.byte_offset, len(recovered[item.path]))
                self.assertIn(item.content, rendered)
                recovered[item.path] += item.content.encode("utf-8")
        self.assertEqual(recovered, {item.path: item.content.encode("utf-8") for item in inputs})

    def test_evidence_batching_uses_actual_prompt_space(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            for budget, instruction_size, change_size, hunk_context_size in (
                (120_000, 20_000, 100_000, 0),
                (120_000, 50_000, 1_000, 0),
                (30_000, 1_000, 40_000, 0),
                (30_000, 1_000, 40_000, 17_000),
            ):
                with self.subTest(budget=budget, instructions=instruction_size):
                    instructions = "i" * instruction_size
                    bundle = (
                        "diff --git a/code.py b/code.py\n--- a/code.py\n+++ b/code.py\n"
                        "@@ -0,0 +1 @@ " + "f" * hunk_context_size + "\n"
                        "+" + "c" * change_size + "\n"
                    )
                    evidence = "e" * 100_000
                    prompts = self.helper["build_review_prompts"](
                        repo, "local", None, bundle, instructions,
                        [self.helper["ReviewDataset"]("evidence.txt", evidence)], budget,
                    )
                    self.assertGreater(len(prompts), 1)
                    for prompt in prompts:
                        self.assertLessEqual(len(prompt.encode("utf-8")), budget)
                        self.assertIn(instructions, prompt)

    def test_partitioned_inputs_keep_credential_review_rule_in_every_pass(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            bundle = "diff --git a/code.py b/code.py\n" + "+review me\n" * 20_000
            prompts = self.helper["prepare_review_prompts"](
                repo, "local", None, bundle, "", [], 120_000
            )
            self.assertGreater(len(prompts), 1)
            for prompt in prompts:
                self.assertIn(
                    "Report suspected real credentials as P0 findings without reproducing their values.",
                    prompt,
                )


    def test_review_prompt_preserves_bundle_ending_whitespace(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            bundle = "# Commit Diff\n+Markdown hard break  \n+\n"
            instructions = "  Keep all instructions. \t\n"
            evidence = "  source indentation\r\n  ending whitespace \t"
            prompt = self.helper["render_review_prompt"](
                self.helper["current_branch"](repo),
                "commit",
                "HEAD",
                self.helper["ReviewChunk"](bundle),
                instructions,
                evidence,
            )

        self.assertTrue(prompt.endswith(bundle))
        self.assertIn(instructions, prompt)
        self.assertIn(evidence, prompt)

    def test_many_review_passes_preserve_late_findings_and_fail_closed(self) -> None:
        args = argparse.Namespace(
            engine="codex", max_priority="P0", require_finding=["late defect"]
        )
        prompts = [f"pass {index}" for index in range(10)]
        finding = {
            "title": "Late defect",
            "body": "The last pass demonstrates the defect.",
            "priority": "P0",
            "confidence": 0.9,
            "category": "bug",
            "code_location": {"file_path": "source.txt", "line": 1},
        }
        for failure in (None, "engine"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                events = []


                def engine(_args, _repo, prompt):
                    events.append(("engine", prompt))
                    if failure == "engine" and prompt == prompts[8]:
                        raise SystemExit("late engine failure")
                    findings = [finding] if prompt == prompts[-1] else []
                    return json.dumps(
                        {
                            "findings": findings,
                            "overall_correctness": (
                                "patch is incorrect" if findings else "patch is correct"
                            ),
                            "overall_explanation": "test review",
                            "overall_confidence": 0.9,
                            "review_completion": "complete",
                        }
                    )

                with mock.patch.dict(
                    self.helper["run_review_passes"].__globals__,
                    {"run_engine": engine},
                ), contextlib.redirect_stdout(io.StringIO()):
                    if failure:
                        with self.assertRaisesRegex(SystemExit, f"late {failure} failure"):
                            self.helper["run_review_passes"](
                                args, [args], repo, prompts, {"source.txt"}
                            )
                    else:
                        results = self.helper["run_review_passes"](
                            args, [args], repo, prompts, {"source.txt"}
                        )
                        self.assertTrue(all(result.complete for _, result in results))
                        reports = [(label, result.report) for label, result in results]
                        report = self.helper["merge_chunk_reports"](reports)
                        self.helper["require_findings"](report, args.require_finding)
                        self.assertEqual(report["overall_correctness"], "patch is incorrect")
                        self.assertEqual(
                            [item["title"] for item in report["findings"]], [finding["title"]]
                        )
                expected = [
                    ("engine", prompt) for prompt in prompts
                ]
                if failure:
                    expected = expected[:9]
                self.assertEqual(events, expected)

    def test_review_patch_does_not_disclose_controls_in_refused_paths(self) -> None:
        path = ".env.\x1b]52;c;VEVTVA==\x07\udc9b"
        with self.assertRaises(SystemExit) as refusal:
            self.helper["validate_review_patch"]([path], "")
        message = str(refusal.exception)
        self.assertEqual(message, "cannot establish sensitive patch ownership")
        self.assertNotIn("\x1b", message)
        self.assertNotIn("\x07", message)
        self.assertNotIn("\udc9b", message)

    def test_review_patch_refuses_unmapped_sensitive_paths(self) -> None:
        patch = (
            "commit metadata that must not survive a mapping failure\n"
            "diff --cc .env\n"
            "@@@ -1,1 -1,1 +1,1 @@@\n"
            "++placeholder=true\n"
        )

        with self.assertRaisesRegex(SystemExit, "cannot establish sensitive patch ownership"):
            self.helper["validate_review_patch"]([".env"], patch)

    def test_review_patch_preserves_combined_and_headerless_hunk_content(self) -> None:
        credential_shaped_code = '+token = "ordinary-hardcoded-value-12345"\n'
        for patch in (
            "@@ -0,0 +1 @@\n" + credential_shaped_code,
            "diff --cc src/runtime.ts\n"
            "@@@ -0,0 -0,0 +1 @@@\n"
            "++token = \"ordinary-hardcoded-value-12345\"\n",
        ):
            with self.subTest(patch=patch):
                validated = self.helper["validate_review_patch"](
                    ["src/runtime.ts"],
                    patch,
                )
                self.assertIn("ordinary-hardcoded-value-12345", validated)

    def test_tracked_sensitive_paths_are_omitted_in_all_modes(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "base.txt").write_text("base\n", encoding="utf-8")
            git(repo, "add", "base.txt")
            git(repo, "commit", "-q", "-m", "base")
            base = git(repo, "rev-parse", "HEAD").strip()

            (repo / ".env").write_text("placeholder=true\n", encoding="utf-8")
            (repo / "base.txt").write_text("base\nreview me\n", encoding="utf-8")
            git(repo, "add", ".env", "base.txt")
            local = self.helper["local_bundle"](repo).text
            self.assertIn(self.helper["REVIEW_SECURITY_OMISSION"], local)
            self.assertNotIn(".env", local)
            self.assertNotIn("placeholder=true", local)
            self.assertIn("+review me", local)

            git(repo, "commit", "-q", "-m", "sensitive path")
            for captured in (
                self.helper["branch_bundle"](repo, base),
                self.helper["commit_bundle"](repo, "HEAD"),
            ):
                bundle = captured.text
                self.assertIn(self.helper["REVIEW_SECURITY_OMISSION"], bundle)
                self.assertNotIn(".env", bundle)
                self.assertNotIn("placeholder=true", bundle)
                self.assertIn("+review me", bundle)

    def test_credential_flow_changes_remain_finding_targets(self) -> None:
        paths = ("docs/flows/credential-source-egress/model-requests.md",
                 "docs/reference/repository-credentials/prepared-native-git.md",
                 "docs/reference/credential-sources/protected-inference.md",
                 "specs/rfcs/0023-egress-proxy-credential-lifecycle/github-installation-access.md",
                 "specs/rfcs/0023-egress-proxy-credential-lifecycle/index.md")
        for path in paths:
            with self.subTest(path=path), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                (repo / "base.txt").write_text("base\n")
                git(repo, "add", "base.txt")
                git(repo, "commit", "-qm", "base")
                base = git(repo, "rev-parse", "HEAD").strip()
                doc = repo / path
                doc.parent.mkdir(parents=True)
                doc.write_text("# Model request flow\n")
                # The exception is for tracked behavior docs, not arbitrary evidence.
                untracked = self.helper["local_bundle"](repo)
                self.assertNotIn("Model request flow", untracked.text)
                self.assertNotIn(path, untracked.paths)
                git(repo, "add", path)
                staged = self.helper["local_bundle"](repo)
                self.assertIn("+# Model request flow", staged.text)
                self.assertIn(path, staged.paths)
                git(repo, "commit", "-qm", "document flow")
                for bundle in (self.helper["branch_bundle"](repo, base),
                               self.helper["commit_bundle"](repo, "HEAD")):
                    self.assertIn(path, bundle.text)
                    self.assertIn("+# Model request flow", bundle.text)
                    self.assertIn(path, bundle.paths)

    def test_credential_flow_exception_requires_regular_changed_modes(self) -> None:
        paths = ("docs/flows/credential-source-egress/guide.md",
                 "docs/reference/repository-credentials/guide.md",
                 "docs/reference/credential-sources/guide.md",
                 "specs/rfcs/0023-egress-proxy-credential-lifecycle/guide.md",
                 "specs/rfcs/0042-credential-lifecycle/contracts.md")
        url = "https://example.invalid/private-flow-repository.git"
        for path, (old_mode, new_mode, allowed) in itertools.product(paths, (
            ("160000", "160000", False), ("120000", "120000", False),
            ("000000", "160000", False), ("000000", "120000", False),
            ("100644", "160000", False), ("160000", "100644", False),
            ("100644", "120000", False), ("120000", "100644", False),
            ("160000", "000000", False), ("120000", "000000", False),
            ("100644", "000000", True), ("100644", "100755", True),
        )):
            with self.subTest(path=path, old_mode=old_mode, new_mode=new_mode), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                git(repo, "config", "core.filemode", "false")
                if os.name == "nt":
                    git(repo, "config", "core.symlinks", "false")
                (repo / "base.txt").write_text("base\n")
                git(repo, "add", "base.txt")
                git(repo, "commit", "-qm", "first pin")
                first = git(repo, "rev-parse", "HEAD").strip()
                git(repo, "commit", "--allow-empty", "-qm", "second pin")
                second = git(repo, "rev-parse", "HEAD").strip()
                (repo / ".gitmodules").write_text(
                    f'[submodule "flow"]\npath = {path}\nurl = {url}\n'
                )
                git(repo, "add", ".gitmodules")

                def select(mode, pin, text):
                    target = repo / path
                    if target.is_symlink() or target.is_file():
                        target.unlink()
                    elif target.is_dir():
                        target.rmdir()
                    if mode == "000000":
                        git(repo, "update-index", "--force-remove", path)
                        return
                    payload = repo.parent / "payload"
                    payload.write_text(text)
                    oid = pin if mode == "160000" else git(repo, "hash-object", "-w", str(payload)).strip()
                    git(repo, "update-index", "--add", "--cacheinfo", f"{mode},{oid},{path}")
                    if mode == "160000":
                        target.mkdir(parents=True)
                    else:
                        git(repo, "checkout-index", "--force", "--", path)

                select(old_mode, first, "original-flow-marker\n")
                git(repo, "commit", "-qm", "baseline mapping")
                base = git(repo, "rev-parse", "HEAD").strip()
                select(new_mode, second, "updated-flow-marker\n")
                (repo / "base.txt").write_text("base\npermitted-sibling-edit\n")
                git(repo, "add", "base.txt")
                local = self.helper["local_bundle"](repo)
                git(repo, "commit", "-qm", "change flow object")
                for bundle in (local, self.helper["branch_bundle"](repo, base),
                               self.helper["commit_bundle"](repo, "HEAD")):
                    # Filtering either section of a type change must retain its sibling.
                    self.assertIn("base.txt", bundle.paths)
                    self.assertIn("+permitted-sibling-edit", bundle.text)
                    # An unchanged mapping must never be disclosed by a rejected gitlink.
                    self.assertNotIn(url, bundle.text)
                    self.assertEqual(path in bundle.paths, allowed)
                    self.assertEqual("original-flow-marker" in bundle.text, allowed)
                    if not allowed:
                        self.assertNotIn("updated-flow-marker", bundle.text)
                        self.assertNotIn(path, bundle.text)

    def test_secret_named_workflows_are_reviewable_in_all_modes(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "base.txt").write_text("base\n", encoding="utf-8")
            git(repo, "add", "base.txt")
            git(repo, "commit", "-q", "-m", "base")
            base = git(repo, "rev-parse", "HEAD").strip()

            workflow = repo / ".github" / "workflows" / "secret-scan.yml"
            workflow.parent.mkdir(parents=True)
            workflow.write_text("name: Secret scan\n", encoding="utf-8")
            untracked_bundle = self.helper["local_bundle"](repo).text
            self.assertIn("secret-scan.yml", untracked_bundle)

            git(repo, "add", str(workflow.relative_to(repo)))
            tracked_bundle = self.helper["local_bundle"](repo).text
            self.assertIn("secret-scan.yml", tracked_bundle)

            git(repo, "commit", "-q", "-m", "add secret scanner")
            branch_bundle = self.helper["branch_bundle"](repo, base).text
            commit_bundle = self.helper["commit_bundle"](repo, "HEAD").text
            self.assertIn("secret-scan.yml", branch_bundle)
            self.assertIn("secret-scan.yml", commit_bundle)

    def test_case_variant_secret_named_workflows_remain_sensitive(self) -> None:
        for rel in (
            ".GitHub/workflows/secret-scan.yml",
            ".github/Workflows/secret-scan.yml",
            ".github/workflows/secret-scan.YML",
        ):
            with self.subTest(rel=rel):
                self.assertIsNotNone(self.helper["sensitive_repo_path_risk"](rel))
                self.assertIsNotNone(
                    self.helper["tracked_sensitive_repo_path_risk"](rel)
                )

    def test_tracked_source_names_and_env_templates_remain_reviewable(self) -> None:
        for rel in (
            "tokenizer.py",
            "token_count.ts",
            "src/token/parser.py",
            "src/token/session.ts",
            "internal/tokens/types.go",
            "packages/token/package.json",
            "scripts/tokens/session.sh",
            "src/tokens/session.mjs",
            "credentials/prod.py",
            "secrets/runtime.ts",
            "src/credentials/provider.py",
            "src/secrets/scanner.ts",
            "ui/tokens/session.vue",
            "proto/token/session.proto",
            "password_validator.go",
            ".env.example",
            "private/parser.py",
            ".agents/skills/openclaw-secret-scanning-maintainer/SKILL.md",
            "design-tokens/colors.json",
            "design-tokens.json",
            "design_tokens.json",
            "tokens/default.json",
            "token_count/generated.py",
            ".docker/Dockerfile",
            ".docker/scripts/build.sh",
            ".github/workflows/secret-scan.yml",
        ):
            with self.subTest(rel=rel):
                self.assertIsNone(self.helper["tracked_sensitive_repo_path_risk"](rel))

    def test_tracked_rfc_companions_are_source_not_credential_stores(self) -> None:
        for root in ("specs/rfcs", "docs/rfcs"):
            for name in ("README.md", "index.md", "contracts.md", "design.md", "security.md"):
                rel = f"{root}/0042-credential-lifecycle/{name}"
                with self.subTest(rel=rel):
                    self.assertIsNone(self.helper["tracked_sensitive_repo_path_risk"](rel))
                    # This exception does not admit untracked files or evidence.
                    self.assertIsNotNone(self.helper["sensitive_repo_path_risk"](rel))

    def test_rfc_companion_exception_requires_regular_files(self) -> None:
        for root in ("specs/rfcs", "docs/rfcs"):
            rel = f"{root}/0042-credential-lifecycle/contracts.md"
            with self.subTest(rel=rel):
                self.assertIsNotNone(
                    self.helper["tracked_sensitive_repo_path_risk"](rel, regular_file=False)
                )

    def test_rfc_shaped_credential_storage_remains_sensitive(self) -> None:
        for rel in (
            "credentials/contracts.md",
            "specs/credentials/contracts.md",
            "rfcs/0042-credential-lifecycle/contracts.md",
            "vendor/specs/rfcs/0042-credential-lifecycle/contracts.md",
            "specs/rfcs/credential-lifecycle/contracts.md",
            "specs/rfcs/0042-credential-lifecycle/notes.md",
            "specs/rfcs/0042-credential-lifecycle/credentials.md",
            "specs/rfcs/0042-credential-lifecycle/token.md",
            "specs/rfcs/0042-credential-lifecycle/secret.md",
            "specs/rfcs/0042-credential-lifecycle/config.md",
            "specs/rfcs/0042-credential-lifecycle/contracts.json",
            "specs/rfcs/0042-credential-lifecycle/contracts.pem",
            "specs/rfcs/0042-credential-lifecycle/.env",
            "specs/rfcs/0042-credential-lifecycle/.ssh/contracts.md",
            "specs/rfcs/0042-credential-lifecycle/.aws/contracts.md",
            "specs/rfcs/0042-credential-lifecycle/credentials/contracts.md",
            "specs/rfcs/0042-credential-lifecycle/appendix/contracts.md",
            "specs/rfcs/0042-credential-lifecycle/contracts.md.backup",
            "specs/rfcs/0042-credential-lifecycle/contracts.MD",
            "specs/rfcs/0042-secret-credential-store/contracts.md",
            "docs/rfcs/0042-credential-token-store/index.md",
        ):
            with self.subTest(rel=rel):
                self.assertIsNotNone(self.helper["tracked_sensitive_repo_path_risk"](rel))
                self.assertIsNotNone(self.helper["sensitive_repo_path_risk"](rel))

    def test_untracked_token_source_paths_remain_reviewable(self) -> None:
        for rel in (
            "src/token/parser.py",
            "src/token/session.ts",
            "scripts/tokens/session.sh",
            "src/tokens/session.mjs",
            "ui/tokens/session.vue",
            "proto/token/session.proto",
        ):
            with self.subTest(rel=rel):
                self.assertIsNone(self.helper["sensitive_repo_path_risk"](rel))

    def test_untracked_credential_shaped_source_content_is_reviewed(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = 'const token = "ordinary-hardcoded-value-12345";\n'
            path = repo / "src" / "runtime.ts"
            path.parent.mkdir()
            path.write_text(source, encoding="utf-8")

            bundle = self.helper["local_bundle"](repo).text

            self.assertIn("ordinary-hardcoded-value-12345", bundle)

    def test_untracked_design_token_artifacts_remain_reviewable(self) -> None:
        for rel in (
            "design-tokens.json",
            "design_tokens.json",
            "src/styles/design-tokens.json",
            "themes/dark/design_tokens.json",
            "tokens/design-tokens.json",
            "tokens/design_tokens.json",
        ):
            with self.subTest(rel=rel):
                self.assertIsNone(self.helper["sensitive_repo_path_risk"](rel))
                self.assertIsNone(
                    self.helper["tracked_sensitive_repo_path_risk"](rel)
                )
        self.assertIsNotNone(
            self.helper["sensitive_repo_path_risk"](".env/design-tokens.json")
        )
        self.assertIsNotNone(
            self.helper["tracked_sensitive_repo_path_risk"](
                ".env/design-tokens.json"
            )
        )
        self.assertIsNotNone(
            self.helper["tracked_sensitive_repo_path_risk"](
                ".env/tokens/design-tokens.json"
            )
        )

    def test_sensitive_named_source_directories_are_blocked_untracked(self) -> None:
        for rel in (
            "credentials/prod.py",
            "secrets/runtime.ts",
            "src/credentials/provider.py",
            "src/secrets/scanner.ts",
        ):
            with self.subTest(rel=rel):
                self.assertIsNotNone(self.helper["sensitive_repo_path_risk"](rel))

    def test_tracked_env_variants_remain_sensitive(self) -> None:
        for rel in (
            ".env-local",
            ".env_prod",
            ".env/production",
            ".env/example/production",
            ".env/template/prod",
        ):
            with self.subTest(rel=rel):
                self.assertIsNotNone(
                    self.helper["tracked_sensitive_repo_path_risk"](rel)
                )

    def test_suffixed_credential_data_paths_remain_sensitive(self) -> None:
        for rel in (
            "credentials-prod.json",
            "service-account-dev.yaml",
            "api-key.backup.json",
            "token-prod.json",
            "tokens.json",
            "auth-token.yaml",
            "prod-credentials.json",
            "google-service-account.json",
            "client-secret.yaml",
            "credentials/prod.json",
            "prod-credentials/client.conf",
            "client-secrets/account.ini",
            "token/production.json",
            "tokens/production.json",
            "tokens/session.dat",
            "tokens/cache.json",
            "token/user.json",
            "tokens/device.sqlite",
            "tokens/session.jwt",
            "tokens/session",
            "backup-secrets/prod.json",
            "dev_credentials/runtime.yaml",
            "client-secrets-old/account.ini",
            "client-secrets/account.properties",
            "credentials/prod.xml",
            "secrets/prod.md",
            "credentials.txt",
            "client-secret.csv",
            ".docker/config.json",
            "deployment/.docker/config.json",
            ".netrc",
            "config/.netrc",
            ".git-credentials",
            "config/.git-credentials",
        ):
            with self.subTest(rel=rel):
                self.assertIsNotNone(
                    self.helper["tracked_sensitive_repo_path_risk"](rel)
                )

    def test_review_patch_allows_provider_references_and_test_placeholders(
        self,
    ) -> None:
        token_name = "to" + "ken"
        key_name = "api_" + "key"
        secret_name = "api_" + "secret"
        safe_patch = (
            "diff --git a/provider.ts b/provider.ts\n"
            "--- a/provider.ts\n"
            "+++ b/provider.ts\n"
            "@@ -1 +1,6 @@\n"
            f"-const {token_name} = data.session?.access_token;\n"
            f"+const {token_name} = data.session?.access_token;\n"
            "+const api" + f"Key = providerConfig.{key_name};\n"
            "+const api" + "Sec" + f"ret = providerConfig.{secret_name};\n"
            f'+const fixture = {{ {key_name}: "test-key" }};\n'
            f'+const fixtureSecret = {{ {secret_name}: "test-secret" }};\n'
            f'+const session = {{ access_{token_name}: "test-token" }};\n'
        )

        self.assertEqual(
            self.helper["validate_review_patch"](
                ["provider.ts"],
                safe_patch,
            ),
            safe_patch,
        )

    def test_secret_detector_allows_typescript_credential_plumbing_fixture(self) -> None:
        source = (FIXTURES / "typescript-benign-references.ts").read_text(
            encoding="utf-8"
        )

        patch = (
            "diff --git a/src/credential-plumbing.ts b/src/credential-plumbing.ts\n"
            "new file mode 100644\n"
            "--- /dev/null\n"
            "+++ b/src/credential-plumbing.ts\n"
            f"@@ -0,0 +1,{len(source.splitlines())} @@\n"
            + "".join(f"+{line}\n" for line in source.splitlines())
        )
        validated = self.helper["validate_review_patch"](
            ["src/credential-plumbing.ts"],
            patch,
        )
        for reference in (
            "filePassword",
            "passwordResolution.password",
            "tokenResolution.token",
            "CredentialUnavailableDiagnostic",
            "tokenRef",
            "keyRef",
        ):
            self.assertIn(reference, validated)

    def test_review_bundle_preserves_deleted_swift_status_literals(self) -> None:
        # Regression: a deleted Swift file with status-string cases like
        # `case "ok-empty", "ok-token":` next to value returns is not a
        # credential. The retired heuristic scanner flagged the "ok-token"
        # key shape as secret-like even after value redaction, so the whole
        # deletion became unreviewable; the bundle must stay byte-identical.
        source = (FIXTURES / "swift-benign-status-literals.swift").read_text(
            encoding="utf-8"
        )
        patch = (
            "diff --git a/apps/macos/MenuContentView.swift "
            "b/apps/macos/MenuContentView.swift\n"
            "deleted file mode 100644\n"
            "--- a/apps/macos/MenuContentView.swift\n"
            "+++ /dev/null\n"
            f"@@ -1,{len(source.splitlines())} +0,0 @@\n"
            + "".join(f"-{line}\n" for line in source.splitlines())
        )

        self.assertEqual(
            self.helper["validate_review_patch"](
                ["apps/macos/MenuContentView.swift"],
                patch,
            ),
            patch,
        )


    def test_review_bundle_preserves_typescript_config_paths(self) -> None:
        source = (FIXTURES / "typescript-benign-config-path-references.ts").read_text(
            encoding="utf-8"
        )
        patch = (
            "diff --git a/src/config-path-references.ts b/src/config-path-references.ts\n"
            "new file mode 100644\n"
            "--- /dev/null\n"
            "+++ b/src/config-path-references.ts\n"
            f"@@ -0,0 +1,{len(source.splitlines())} @@\n"
            + "".join(f"+{line}\n" for line in source.splitlines())
        )

        validated = self.helper["validate_review_patch"](
            ["src/config-path-references.ts"],
            patch,
        )

        for config_path in (
            "channels.irc.accounts.${accountId}.passwordFile",
            "channels.irc.accounts.${accountId}.nickserv.passwordFile",
            "channels.nextcloud-talk.accounts.${accountId}.botSecret",
            "channels.nextcloud-talk.accounts.${accountId}.botSecretFile",
            "channels.telegram.accounts.${accountId}.tokenFile",
        ):
            self.assertIn(config_path, validated)

        token_term = "To" + "ken"
        truncated_call_patch = (
            "diff --git a/src/token.ts b/src/token.ts\n"
            "--- a/src/token.ts\n"
            "+++ b/src/token.ts\n"
            "@@ -40,3 +40,4 @@ function resolveAccountToken() {\n"
            f"+  const account{token_term} = resolveRuntime{token_term}Value({{\n"
            "+    value: accountConfig.token,\n"
            "@@ -70,3 +71,4 @@ function resolveConfigToken() {\n"
            f"+  const config{token_term} = resolveRuntime{token_term}Value({{\n"
            "+    value: merged.token,\n"
        )
        self.assertEqual(
            self.helper["validate_review_patch"](
                ["src/token.ts"],
                truncated_call_patch,
            ),
            truncated_call_patch,
        )

    def test_review_patch_preserves_safe_uri_userinfo(self) -> None:
        safe_lines = (
            'url = f"ssh://{ssh_user}@git.example.invalid/org/repo.git"',
            'url = "https://alice@github.com/example/repo"',
            'url = "https://username:@host/repo"',
            'remote = "ssh://git@github.com/org/repo.git"',
        )
        for line in safe_lines:
            with self.subTest(line=line):
                patch = (
                    "diff --git a/fixture.py b/fixture.py\n"
                    "--- a/fixture.py\n"
                    "+++ b/fixture.py\n"
                    "@@ -0,0 +1 @@\n"
                    f"+{line}\n"
                )

                validated = self.helper["validate_review_patch"](
                    ["fixture.py"],
                    patch,
                )

                self.assertIn(f"+{line}", validated)
                self.assertNotIn("redacted@", validated)

    def test_branch_bundle_preserves_deleted_jinja_pem_marker_regex(self) -> None:
        # Generic template regex delimiters are not private-key material. The
        # branch boundary must keep a deleted template reviewable as-is.
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            template = repo / "origin-pem.j2"
            template.write_text(
                "-----BEGIN [A-Z ]+-----\n"
                "{{ _body }}\n"
                "-----END [A-Z ]+-----\n",
                encoding="utf-8",
            )
            git(repo, "add", template.name)
            git(repo, "commit", "-q", "-m", "add template")
            base = git(repo, "rev-parse", "HEAD").strip()

            template.unlink()
            git(repo, "add", "-u")
            git(repo, "commit", "-q", "-m", "delete template")

            bundle = self.helper["branch_bundle"](repo, base).text

            self.assertIn("deleted file mode 100644", bundle)
            self.assertIn("------BEGIN [A-Z ]+-----", bundle)
            self.assertIn("-{{ _body }}", bundle)
            self.assertIn("------END [A-Z ]+-----", bundle)

    def test_review_patch_preserves_redaction_placeholder_fallback(self) -> None:
        patch = (
            "diff --git a/runtime.py b/runtime.py\n"
            "--- a/runtime.py\n"
            "+++ b/runtime.py\n"
            "@@ -0,0 +1 @@\n"
            + "+pass"
            + 'word = getenv("PASSWORD") or "redacted"\n'
        )

        self.assertEqual(
            self.helper["validate_review_patch"](
                ["runtime.py"],
                patch,
            ),
            patch,
        )

    def test_review_patch_preserves_ambiguous_short_markerless_lines(self) -> None:
        chunks = ["AB12", "CDef", "GH34", "ijKL", "MN56", "opQR"]
        patch = (
            "diff --git a/fixture.txt b/fixture.txt\n"
            "--- a/fixture.txt\n"
            "+++ b/fixture.txt\n"
            f"@@ -0,0 +1,{len(chunks)} @@\n"
            + "".join(f"+{chunk}\n" for chunk in chunks)
        )

        redacted_patch = self.helper["validate_review_patch"](
            ["fixture.txt"],
            patch,
        )

        self.assertEqual(redacted_patch, patch)

    def test_review_patch_preserves_long_non_pem_identifier_lines(self) -> None:
        identifier = "runDangerousOperationWithLongIdentifier"
        patch = (
            "diff --git a/runtime.ts b/runtime.ts\n"
            "--- a/runtime.ts\n"
            "+++ b/runtime.ts\n"
            "@@ -0,0 +1 @@\n"
            + f"+{identifier}\n"
        )

        redacted = self.helper["validate_review_patch"](
            ["runtime.ts"],
            patch,
        )

        self.assertIn("+" + identifier, redacted)

    def test_review_patch_preserves_hash_and_submodule_lines(self) -> None:
        digest = "abcdef0123456789abcdef0123456789abcdef01"
        patch = (
            "diff --git a/vendor b/vendor\n"
            "--- a/vendor\n"
            "+++ b/vendor\n"
            "@@ -1 +1,2 @@\n"
            + f"+{digest}\n"
            + f"+Subproject commit {digest}\n"
        )

        redacted = self.helper["validate_review_patch"](
            ["vendor"],
            patch,
        )

        self.assertIn("+" + digest, redacted)
        self.assertIn("+Subproject commit " + digest, redacted)

    def test_review_patch_preserves_unwrapped_alphabetic_identifier(self) -> None:
        identifier = "AbCdEfGh" + "IjKlMnOp"
        patch = (
            "diff --git a/runtime.ts b/runtime.ts\n"
            "--- a/runtime.ts\n"
            "+++ b/runtime.ts\n"
            "@@ -0,0 +1 @@\n"
            + f"+const {identifier} = true;\n"
        )

        redacted_patch = self.helper["validate_review_patch"](
            ["runtime.ts"],
            patch,
        )

        self.assertIn(identifier, redacted_patch)

    def test_review_patch_preserves_punctuation_wrapped_alphabetic_identifier(self) -> None:
        identifier = "AbCdEfGh" + "IjKlMnOp"
        patch = (
            "diff --git a/runtime.ts b/runtime.ts\n"
            "--- a/runtime.ts\n"
            "+++ b/runtime.ts\n"
            "@@ -0,0 +1 @@\n"
            + f"+  {identifier},\n"
        )

        redacted_patch = self.helper["validate_review_patch"](
            ["runtime.ts"],
            patch,
        )

        self.assertIn(identifier, redacted_patch)

    def test_review_patch_preserves_escaped_newline_beside_alphabetic_identifier(self) -> None:
        identifier = "AbCdEfGh" + "IjKlMnOp"
        patch = (
            "diff --git a/runtime.ts b/runtime.ts\n"
            "--- a/runtime.ts\n"
            "+++ b/runtime.ts\n"
            "@@ -0,0 +1 @@\n"
            + f'+[{identifier}, "\\\\n"];\n'
        )

        redacted_patch = self.helper["validate_review_patch"](
            ["runtime.ts"],
            patch,
        )

        self.assertIn(identifier, redacted_patch)

    def test_review_patch_preserves_bare_identifier_in_escaped_pem_concatenation(self) -> None:
        identifier = "AbCdEfGh" + "IjKlMnOp"
        patch = (
            "diff --git a/runtime.ts b/runtime.ts\n"
            "--- a/runtime.ts\n"
            "+++ b/runtime.ts\n"
            "@@ -0,0 +1 @@\n"
            '+const fixture = "-----BEGIN '
            + "PRIVATE KEY-----\\n\" + "
            + identifier
            + ' + "\\n-----END '
            + 'PRIVATE KEY-----";\n'
        )

        redacted_patch = self.helper["validate_review_patch"](
            ["runtime.ts"],
            patch,
        )

        self.assertIn(identifier, redacted_patch)

    def test_local_bundle_allows_deleted_test_token_fixture(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            path = repo / "fixture.test.ts"
            path.write_text('const request = { token: "test-token" };\n', encoding="utf-8")
            git(repo, "add", path.name)
            git(repo, "commit", "-q", "-m", "base")

            path.write_text('const request = { token: String() };\n', encoding="utf-8")

            bundle = self.helper["local_bundle"](repo).text

            self.assertIn('-const request = { token: "test-token" };', bundle)

    def test_toml_keys_and_values_round_trip_unicode_and_scalar_types(self) -> None:
        values = {
            "model": "review-🦞",
            "label.🦞\x7f": 'Unicode 🦞 with "quotes", backslash \\, newline\n and DEL\x7f',
            "values": [True, False, 42, 1.5, "🦞"],
        }
        encoded = "\n".join(
            f'{self.helper["toml_key"](key)} = {self.helper["toml_value"](value)}'
            for key, value in values.items()
        )
        self.assertEqual(tomllib.loads(encoded), values)

    def test_pi_preserves_kimi_provider_key_without_kimi_runtime_overrides(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            with mock.patch.dict(
                os.environ,
                {
                    "KIMI_API_KEY": "test-token",
                    "KIMI_BASE_URL": "https://api.example.invalid",
                    "KIMI_MODEL_NAME": "kimi-model",
                    "KIMI_CODE_HOME": str(repo / ".hostile-kimi"),
                    "PYTHONPATH": "/tmp/hostile-python",
                },
                clear=False,
            ):
                env = self.helper["safe_engine_env"](repo, engine="pi")

        self.assertEqual(env["KIMI_API_KEY"], "test-token")
        self.assertNotIn("KIMI_BASE_URL", env)
        self.assertNotIn("KIMI_MODEL_NAME", env)
        self.assertNotIn("KIMI_CODE_HOME", env)
        self.assertNotIn("PYTHONPATH", env)

    def test_safe_git_env_preserves_trusted_platform_and_helper_paths(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            repo_bin = repo / "bin"
            trusted_bin = root / "trusted-bin"
            repo_bin.mkdir()
            trusted_bin.mkdir()
            with mock.patch.dict(
                os.environ,
                {
                    "PATH": os.pathsep.join((str(repo_bin), str(trusted_bin))),
                    "SYSTEMROOT": "C:\\Windows",
                    "GIT_DIR": str(repo / ".git"),
                    "OPENAI_API_KEY": "must-not-reach-git",
                },
                clear=False,
            ):
                env = self.helper["safe_git_env"](repo)

        self.assertNotIn(str(repo_bin.resolve()), env["PATH"].split(os.pathsep))
        self.assertIn(str(trusted_bin.resolve()), env["PATH"].split(os.pathsep))
        self.assertEqual(env["SYSTEMROOT"], "C:\\Windows")
        self.assertNotIn("GIT_DIR", env)
        self.assertNotIn("OPENAI_API_KEY", env)

    def test_prompt_file_keeps_recoverable_repo_path(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "review.md").write_text("review context\n", encoding="utf-8")
            args = argparse.Namespace(prompt=[], prompt_file=["review.md"], dataset=[])

            evidence = self.helper["capture_evidence_inputs"](args, repo)

            self.assertIn("# Prompt file: review.md", evidence.prompt)

    def test_absolute_prompt_file_keeps_evidence_guards(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir)).resolve()
            prompt = repo / "review.md"
            prompt.write_bytes(b"review context\n")
            args = argparse.Namespace(prompt=[], prompt_file=[str(prompt)], dataset=[])
            evidence = self.helper["capture_evidence_inputs"](args, repo)
            self.assertEqual(evidence.prompt, "# Prompt file: review.md\nreview context\n")
            self.assertEqual(evidence.files[0].raw_path, "review.md")
            self.helper["verify_evidence"](repo, evidence.files)
            prompt.write_text("changed\n", encoding="utf-8")
            with self.assertRaisesRegex(SystemExit, "evidence changed"):
                self.helper["verify_evidence"](repo, evidence.files)
            with self.assertRaisesRegex(SystemExit, "repo-relative"):
                self.helper["capture_evidence_file"](repo, str(prompt), "--dataset")
            (repo / ".env").write_text("fixture\n", encoding="utf-8")
            with self.assertRaisesRegex(SystemExit, "sensitive"):
                self.helper["capture_evidence_file"](repo, str(repo / ".env"), "--prompt-file")

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_git_preflight_failures_stop_before_target_selection(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            for body, diagnostic, minimum in (
                ("exit 7", "exit 7", 0),
                ("exec sleep 60", "timed out after 10s", 9),
            ):
                with self.subTest(diagnostic=diagnostic):
                    binary = write_executable(root / f"git-stub-{minimum}", f"#!/bin/sh\n{body}\n")
                    started = time.monotonic()
                    result = subprocess.run(
                        [sys.executable, str(SCRIPT), "--mode", "local", "--dry-run"],
                        cwd=repo, env={**os.environ, "AUTOREVIEW_GIT": str(binary)},
                        text=True, capture_output=True, timeout=20,
                    )
                    elapsed = time.monotonic() - started
                    self.assertEqual(result.returncode, 2, result.stdout + result.stderr)
                    self.assertIn("incomplete", result.stderr)
                    self.assertIn(diagnostic, result.stderr)
                    self.assertIn(str(binary), result.stderr)
                    self.assertIn("DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer", result.stderr)
                    self.assertNotIn("autoreview target:", result.stdout)
                    self.assertNotIn("scoped-clean", result.stdout + result.stderr)
                    self.assertGreaterEqual(elapsed, minimum)
                    self.assertLess(elapsed, 15)

    def test_git_override_uses_trusted_resolution_and_preserves_git_environment(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            binary = write_executable(root / "git-stub", "#!/bin/sh\nexit 0\n")
            developer = str(root / "Xcode.app/Contents/Developer")
            with mock.patch.dict(os.environ, {"AUTOREVIEW_GIT": str(binary), "DEVELOPER_DIR": developer,
                                               "GIT_DIR": "untrusted", "DYLD_INSERT_LIBRARIES": "untrusted"}):
                with mock.patch.object(subprocess, "run", return_value=subprocess.CompletedProcess([], 0, b"ok", b"")) as run:
                    self.assertEqual(self.helper["git"](repo, "rev-parse", "HEAD"), "ok")
                    self.assertEqual(self.helper["git_bytes"](repo, "show", "HEAD").stdout, b"ok")
                for call in run.call_args_list:
                    self.assertEqual(call.args[0][0], str(binary))
                    self.assertEqual(call.kwargs["env"]["DEVELOPER_DIR"], developer)
                    self.assertNotIn("GIT_DIR", call.kwargs["env"])
                    self.assertNotIn("DYLD_INSERT_LIBRARIES", call.kwargs["env"])
                reviewer_env = self.helper["safe_engine_env"](repo, engine="codex")
                self.assertNotIn("AUTOREVIEW_GIT", reviewer_env)
                self.assertNotIn("DEVELOPER_DIR", reviewer_env)
            local_binary = write_executable(repo / "git-stub", "#!/bin/sh\nexit 0\n")
            with mock.patch.dict(os.environ, {"AUTOREVIEW_GIT": str(local_binary)}):
                with self.assertRaisesRegex(SystemExit, "executable not found"):
                    self.helper["resolve_git"](repo)

    def test_review_prompts_omit_absolute_repo_path_and_keep_instructions_whole(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            for bundle in ("diff", "# Staged Diff\n" + "+changed line\n" * 40_000):
                prompts = self.helper["build_review_prompts"](repo, "local", None, bundle, "", [])
                for prompt in prompts:
                    self.assertIn(
                        "Review sandbox: . (intentionally contains no reviewed repository files)",
                        prompt,
                    )
                    self.assertIn("Read-only tools cannot access unchanged repository files", prompt)
                    self.assertIn(
                        "Missing context or omitted sensitive material is not evidence of a defect.",
                        prompt,
                    )
                    self.assertNotIn(str(repo), prompt)
            with self.assertRaisesRegex(SystemExit, "too little room"):
                self.helper["build_review_prompts"](
                    repo,
                    "local",
                    None,
                    "diff",
                    "x" * self.helper["MAX_REVIEW_PROMPT_BYTES"],
                    [],
                )

    def test_evidence_file_must_be_repo_relative_and_not_symlinked(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            outside = root / "outside.md"
            outside.write_text("outside\n", encoding="utf-8")

            with self.assertRaisesRegex(SystemExit, "inside the reviewed repository"):
                self.helper["validate_evidence_file"](repo, str(outside), "--prompt-file")

            target = repo / "notes.md"
            target.write_text("notes\n", encoding="utf-8")
            link = repo / "link.md"
            try:
                link.symlink_to(target)
            except OSError as exc:
                if os.name == "nt" and getattr(exc, "winerror", None) == 1314:
                    self.skipTest("Windows symlink privilege is not available")
                raise
            with self.assertRaisesRegex(SystemExit, "symlinked"):
                self.helper["validate_evidence_file"](repo, "link.md", "--dataset")
            with self.assertRaisesRegex(SystemExit, "symlinked"):
                self.helper["capture_evidence_file"](repo, str(link.resolve().parent / "link.md"), "--prompt-file")

    def test_safe_engine_env_strips_process_injection_variables(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            try:
                os.environ["GIT_DIR"] = "/tmp/unsafe-git-dir"
                os.environ["GIT_CONFIG_COUNT"] = "99"
                os.environ["DYLD_INSERT_LIBRARIES"] = "/tmp/unsafe.dylib"
                os.environ["NODE_OPTIONS"] = "--require=/tmp/unsafe.js"
                os.environ["NODE_PATH"] = "/tmp/unsafe-node"
                os.environ["LD_AUDIT"] = "/tmp/unsafe-audit.so"
                os.environ["LD_LIBRARY_PATH"] = "/tmp/unsafe-lib"
                os.environ["RUBYOPT"] = "-r/tmp/unsafe.rb"
                os.environ["PERL5OPT"] = "-Munsafe"
                os.environ["BUN_OPTIONS"] = "--preload=/tmp/unsafe.js"
                os.environ["OPENCODE_CONFIG"] = "/tmp/unsafe-opencode.json"
                os.environ["OPENCODE_PERMISSION"] = "allow"
                os.environ["OPENCODE_AUTO_SHARE"] = "1"
                os.environ["COPILOT_ALLOW_ALL"] = "1"
                os.environ["CODEX_HOME"] = "/tmp/codex-auth"
                os.environ["DBUS_SESSION_BUS_ADDRESS"] = "unix:path=/run/user/1000/bus"
                os.environ["XDG_RUNTIME_DIR"] = "/run/user/1000"
                os.environ["CLAUDE_CONFIG_DIR"] = "/tmp/claude-auth"
                os.environ["PI_CODING_AGENT_DIR"] = "/tmp/pi-auth"
                os.environ["CLAUDE_CODE_USE_FOUNDRY"] = "1"
                os.environ["CLOUD_ML_REGION"] = "us-east5"
                os.environ["ANTHROPIC_AUTH_TOKEN"] = "test-auth-token"
                os.environ["AWS_BEARER_TOKEN_BEDROCK"] = "test-token-placeholder"
                os.environ["ANTHROPIC_BEDROCK_BASE_URL"] = (
                    "https://bedrock.example.invalid"
                )
                os.environ["ANTHROPIC_VERTEX_BASE_URL"] = (
                    "https://vertex.example.invalid"
                )
                os.environ["AWS_PROFILE"] = "review-profile"
                os.environ["AWS_CONFIG_FILE"] = "/tmp/unsafe-aws-config"
                os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = (
                    "/tmp/unsafe-google-credentials"
                )
                os.environ["GOOGLE_EXTERNAL_ACCOUNT_ALLOW_EXECUTABLES"] = "1"
                os.environ["OPENROUTER_API_KEY"] = "test-provider-key"
                os.environ["GITHUB_TOKEN"] = "test-token-placeholder"
                os.environ["HTTPS_PROXY"] = "http://proxy.example.invalid:8080"
                os.environ["HTTP_PROXY"] = "proxy.example.invalid:8080"
                os.environ["ALL_PROXY"] = "socks5://proxy.example.invalid:1080"
                os.environ["DO_NOT_TRACK"] = "1"
                os.environ["DISABLE_TELEMETRY"] = "1"
                os.environ["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"] = "1"

                env = self.helper["safe_engine_env"](repo, engine="codex")
                claude_env = self.helper["safe_engine_env"](repo, engine="claude")
                pi_env = self.helper["safe_engine_env"](repo, engine="pi")

                self.assertNotEqual(env.get("GIT_DIR"), "/tmp/unsafe-git-dir")
                self.assertEqual(
                    env["GIT_CONFIG_COUNT"],
                    str(len(self.helper["ENGINE_GIT_CONFIG_OVERRIDES"])),
                )
                self.assertNotIn("DYLD_INSERT_LIBRARIES", env)
                self.assertNotIn("NODE_OPTIONS", env)
                for key in (
                    "NODE_PATH",
                    "LD_AUDIT",
                    "LD_LIBRARY_PATH",
                    "RUBYOPT",
                    "PERL5OPT",
                    "BUN_OPTIONS",
                    "OPENCODE_CONFIG",
                    "OPENCODE_PERMISSION",
                    "OPENCODE_AUTO_SHARE",
                ):
                    self.assertNotIn(key, env)
                self.assertNotIn("COPILOT_ALLOW_ALL", env)
                self.assertNotIn("GITHUB_TOKEN", env)
                self.assertEqual(env["HTTPS_PROXY"], "http://proxy.example.invalid:8080")
                self.assertEqual(env["HTTP_PROXY"], "proxy.example.invalid:8080")
                self.assertEqual(env["ALL_PROXY"], "socks5://proxy.example.invalid:1080")
                self.assertEqual(env["DO_NOT_TRACK"], "1")
                self.assertEqual(env["DISABLE_TELEMETRY"], "1")
                self.assertEqual(env["CODEX_HOME"], "/tmp/codex-auth")
                if os.name == "nt":
                    self.assertNotIn("DBUS_SESSION_BUS_ADDRESS", env)
                else:
                    self.assertEqual(
                        env["DBUS_SESSION_BUS_ADDRESS"],
                        "unix:path=/run/user/1000/bus",
                    )
                self.assertEqual(env["XDG_RUNTIME_DIR"], "/run/user/1000")
                self.assertEqual(
                    claude_env["CLAUDE_CONFIG_DIR"],
                    "/tmp/claude-auth",
                )
                self.assertEqual(
                    claude_env["CLAUDE_CODE_DISABLE_AUTO_MEMORY"],
                    "1",
                )
                self.assertEqual(pi_env["PI_CODING_AGENT_DIR"], "/tmp/pi-auth")
                self.assertEqual(claude_env["CLAUDE_CODE_USE_FOUNDRY"], "1")
                self.assertEqual(claude_env["CLOUD_ML_REGION"], "us-east5")
                self.assertEqual(
                    claude_env["ANTHROPIC_AUTH_TOKEN"],
                    "test-auth-token",
                )
                self.assertEqual(
                    claude_env["AWS_BEARER_TOKEN_BEDROCK"],
                    "test-token-placeholder",
                )
                self.assertEqual(
                    claude_env["ANTHROPIC_BEDROCK_BASE_URL"],
                    "https://bedrock.example.invalid",
                )
                self.assertEqual(
                    claude_env["ANTHROPIC_VERTEX_BASE_URL"],
                    "https://vertex.example.invalid",
                )
                self.assertEqual(claude_env["AWS_PROFILE"], "review-profile")
                self.assertNotIn("AWS_CONFIG_FILE", env)
                self.assertNotIn("GOOGLE_APPLICATION_CREDENTIALS", env)
                self.assertNotIn(
                    "GOOGLE_EXTERNAL_ACCOUNT_ALLOW_EXECUTABLES",
                    env,
                )
                self.assertNotIn("OPENROUTER_API_KEY", env)
                self.assertEqual(
                    claude_env["CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC"],
                    "1",
                )
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_terminate_process_group_uses_windows_process_api(self) -> None:
        proc = mock.Mock(pid=1234)
        fake_taskkill = r"C:\Windows\System32\taskkill.exe"
        with mock.patch.object(os, "name", "nt"), mock.patch.dict(
            self.helper["terminate_process_group"].__globals__,
            {"_resolve_windows_taskkill": lambda: fake_taskkill},
        ), mock.patch(
            "subprocess.run",
            return_value=subprocess.CompletedProcess([], 0),
        ) as run:
            self.helper["terminate_process_group"](proc, grace_seconds=0.01)
        argv = run.call_args.args[0]
        self.assertEqual(argv, [fake_taskkill, "/PID", "1234", "/T", "/F"])
        # A repo-local taskkill.exe on PATH/CWD must never be reachable here:
        # the resolved argv[0] has to be an absolute path, never the bare name.
        self.assertTrue(PureWindowsPath(argv[0]).is_absolute())
        self.assertNotEqual(argv[0], "taskkill")
        proc.kill.assert_not_called()

    def test_successful_windows_taskkill_still_waits_for_owned_processes(self) -> None:
        for batched in (False, True):
            for force_required in (False, True):
                with self.subTest(batched=batched, force_required=force_required):
                    events = []
                    processes = []
                    for pid in ((1234, 5678) if batched else (1234,)):
                        proc = mock.Mock(pid=pid, returncode=None)
                        proc.poll.side_effect = lambda proc=proc: proc.returncode

                        def wait(*, timeout, proc=proc):
                            events.append(("wait", proc.pid))
                            self.assertGreater(timeout, 0)
                            if force_required and not proc.kill.called:
                                raise subprocess.TimeoutExpired("reviewer", timeout)
                            proc.returncode = 1
                            return proc.returncode

                        proc.wait.side_effect = wait
                        processes.append(proc)

                    def taskkill(argv, **kwargs):
                        events.append(("signal", int(argv[2])))
                        # Success can precede the owned handle becoming signaled.
                        self.assertTrue(all(proc.returncode is None for proc in processes))
                        return subprocess.CompletedProcess(argv, 0)

                    with mock.patch.object(os, "name", "nt"), mock.patch.dict(
                        self.helper["terminate_process_group"].__globals__,
                        {"_resolve_windows_taskkill": lambda: r"C:\Windows\System32\taskkill.exe"},
                    ), mock.patch("subprocess.run", side_effect=taskkill):
                        if batched:
                            for proc in processes:
                                self.helper["register_owned_process"](proc)
                            try:
                                self.helper["terminate_owned_processes"]()
                            finally:
                                for proc in processes:
                                    self.helper["unregister_owned_process"](proc)
                        else:
                            self.helper["terminate_process_group"](processes[0])

                    self.assertEqual(events[:len(processes)], [
                        ("signal", proc.pid) for proc in processes
                    ])
                    for proc in processes:
                        self.assertIsNotNone(proc.returncode)
                        self.assertEqual(proc.wait.call_count, 2 if force_required else 1)
                        self.assertEqual(proc.kill.call_count, int(force_required))

    def test_terminate_process_group_skips_taskkill_when_unresolved(self) -> None:
        proc = mock.Mock(pid=1234)
        proc.poll.return_value = None
        with mock.patch.object(os, "name", "nt"), mock.patch.dict(
            self.helper["terminate_process_group"].__globals__,
            {"_resolve_windows_taskkill": lambda: None},
        ), mock.patch("subprocess.run") as run:
            self.helper["terminate_process_group"](proc, grace_seconds=0.01)
        run.assert_not_called()
        proc.kill.assert_called_once()

    def test_terminate_process_group_attempts_taskkill_when_leader_already_exited(
        self,
    ) -> None:
        # Regression for detached descendants leaking: taskkill /T is still
        # worth attempting even once the leader PID has exited (it can still
        # fell the tree while the PID is valid), but the direct-kill fallback
        # only ever makes sense for a leader that is still alive.
        proc = mock.Mock(pid=1234)
        proc.poll.return_value = 0
        fake_taskkill = r"C:\Windows\System32\taskkill.exe"
        with mock.patch.object(os, "name", "nt"), mock.patch.dict(
            self.helper["terminate_process_group"].__globals__,
            {"_resolve_windows_taskkill": lambda: fake_taskkill},
        ), mock.patch(
            "subprocess.run",
            return_value=subprocess.CompletedProcess([], 1),
        ) as run:
            self.helper["terminate_process_group"](proc, grace_seconds=0.01)
        self.assertEqual(run.call_args.args[0][0], fake_taskkill)
        proc.kill.assert_not_called()

    def test_owned_process_registry_terminates_all_tracked_groups(self) -> None:
        terminated: list[object] = []
        proc_a = mock.Mock(pid=111)
        proc_b = mock.Mock(pid=222)
        with mock.patch.dict(
            self.helper["register_owned_process"].__globals__,
            {
                "_signal_owned_process_group": lambda proc: (terminated.append(proc), True)[1],
                "_await_owned_process_groups": lambda procs, grace: None,
                "_enforce_owned_process_group": lambda proc, grace: None,
            },
        ):
            self.helper["register_owned_process"](proc_a)
            self.helper["register_owned_process"](proc_b)
            try:
                self.helper["terminate_owned_processes"]()
            finally:
                self.helper["unregister_owned_process"](proc_a)
                self.helper["unregister_owned_process"](proc_b)
        self.assertEqual(set(terminated), {proc_a, proc_b})

    def test_terminate_owned_processes_signals_all_groups_before_grace_wait(
        self,
    ) -> None:
        # Regression: interrupt handling used to run each group's full
        # terminate-wait-kill sequence serially, so N owned engines cost
        # grace_seconds * N. Phase 1 (signal) must complete for every
        # group before phase 2 (the shared grace wait) starts for any of
        # them.
        order: list[str] = []
        proc_a = mock.Mock(pid=111)
        proc_b = mock.Mock(pid=222)
        proc_gone = mock.Mock(pid=333)

        def fake_signal(proc: object) -> bool:
            order.append(f"signal:{proc.pid}")  # type: ignore[attr-defined]
            return proc is not proc_gone

        def fake_await(procs: list[object], grace_seconds: float) -> None:
            order.append("await:" + ",".join(str(p.pid) for p in procs))  # type: ignore[attr-defined]

        def fake_enforce(proc: object, grace_seconds: float) -> None:
            order.append(f"enforce:{proc.pid}")  # type: ignore[attr-defined]

        with mock.patch.dict(
            self.helper["register_owned_process"].__globals__,
            {
                "_signal_owned_process_group": fake_signal,
                "_await_owned_process_groups": fake_await,
                "_enforce_owned_process_group": fake_enforce,
            },
        ):
            self.helper["register_owned_process"](proc_a)
            self.helper["register_owned_process"](proc_gone)
            self.helper["register_owned_process"](proc_b)
            try:
                self.helper["terminate_owned_processes"]()
            finally:
                self.helper["unregister_owned_process"](proc_a)
                self.helper["unregister_owned_process"](proc_gone)
                self.helper["unregister_owned_process"](proc_b)

        self.assertEqual(
            order,
            [
                "signal:111",
                "signal:333",
                "signal:222",
                "await:111,222",
                "enforce:111",
                "enforce:222",
            ],
        )

    def test_owned_process_grace_deadline_is_shared_across_groups(self) -> None:
        proc_a = mock.Mock()
        proc_b = mock.Mock()
        proc_a.poll.return_value = None
        proc_b.poll.return_value = None
        proc_a.wait.side_effect = subprocess.TimeoutExpired("a", 1.5)
        proc_b.wait.side_effect = subprocess.TimeoutExpired("b", 0.5)

        with mock.patch(
            "time.monotonic",
            side_effect=[10.0, 10.5, 11.5],
        ):
            self.helper["_await_owned_process_groups"](
                [proc_a, proc_b],
                grace_seconds=2.0,
            )

        proc_a.wait.assert_called_once_with(timeout=1.5)
        proc_b.wait.assert_called_once_with(timeout=0.5)

    def test_engine_interrupted_is_not_swallowed_by_except_system_exit(self) -> None:
        # Input validation may translate unreadable-file errors, but an engine
        # interrupt must unwind with its original exit code.
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            (repo / "evidence.txt").write_text("evidence\n")
            with mock.patch.dict(
                self.helper["validate_evidence_file"].__globals__,
                {"read_file_bytes": mock.Mock(side_effect=self.helper["EngineInterrupted"](130))},
            ):
                with self.assertRaises(self.helper["EngineInterrupted"]) as ctx:
                    self.helper["validate_evidence_file"](repo, "evidence.txt", "--dataset")
        self.assertEqual(ctx.exception.code, 130)

    def test_main_converts_engine_interrupted_to_exit_code(self) -> None:
        with mock.patch.dict(
            self.helper["main"].__globals__,
            {"main_impl": mock.Mock(side_effect=self.helper["EngineInterrupted"](130))},
        ):
            self.assertEqual(self.helper["main"](), 130)

    def test_source_tree_snapshot_detects_mutations(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            names = ["source.txt"]
            if os.name != "nt":
                names.extend(("source\r.txt", "source\r\n.txt"))
            for name in names:
                (repo / name).write_text("before\n", encoding="utf-8")
                git(repo, "add", "--", name)
            git(repo, "commit", "-qm", "initial")
            for name in names:
                with self.subTest(name=name):
                    source = repo / name
                    before = self.helper["source_tree_snapshot"](repo)
                    source.write_text("after\n", encoding="utf-8")
                    self.assertNotEqual(self.helper["source_tree_snapshot"](repo), before)
                    source.write_text("before\n", encoding="utf-8")
                    self.assertEqual(self.helper["source_tree_snapshot"](repo), before)

                    source.write_text("after\n", encoding="utf-8")
                    git(repo, "add", "--", name)
                    git(repo, "commit", "-qm", "mutated")
                    self.assertNotEqual(self.helper["source_tree_snapshot"](repo), before)

                    generated = repo / ("generated-" + name)
                    generated.write_text("generated\n", encoding="utf-8")
                    generated_before = self.helper["source_tree_snapshot"](repo)
                    generated.write_text("changed\n", encoding="utf-8")
                    self.assertNotEqual(self.helper["source_tree_snapshot"](repo), generated_before)

    def test_rejects_output_paths_inside_reviewed_repository(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            outside = root / "outside.json"

            with self.assertRaisesRegex(
                SystemExit,
                "--json-output must point outside",
            ):
                self.helper["prepare_output_paths"](
                    argparse.Namespace(
                        json_output=str(repo / "review.json"),
                        output=None,
                    ),
                    repo,
                )
            with self.assertRaisesRegex(
                SystemExit,
                "--output must point outside",
            ):
                self.helper["prepare_output_paths"](
                    argparse.Namespace(
                        json_output=None,
                        output=str(repo / "review.txt"),
                    ),
                    repo,
                )

            self.helper["prepare_output_paths"](
                argparse.Namespace(
                    json_output=str(outside),
                    output=None,
                ),
                repo,
            )
            alternate_repo = repo.with_name(repo.name.swapcase())
            with (
                mock.patch.object(
                    os.path,
                    "samefile",
                    side_effect=lambda left, right: (
                        str(left).casefold() == str(right).casefold()
                    ),
                ),
                self.assertRaisesRegex(
                    SystemExit,
                    "--json-output must point outside",
                ),
            ):
                self.helper["prepare_output_paths"](
                    argparse.Namespace(
                        json_output=str(alternate_repo / "review.json"),
                        output=None,
                    ),
                    repo,
                )

    def test_atomic_output_replaces_hard_link_without_touching_repo_file(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            tracked = repo / "tracked.txt"
            tracked.write_text("tracked\n", encoding="utf-8")
            outside = root / "review.txt"
            os.link(tracked, outside)

            self.helper["atomic_write_text"](outside, "review\n")

            self.assertEqual(
                tracked.read_text(encoding="utf-8"),
                "tracked\n",
            )
            self.assertEqual(
                outside.read_text(encoding="utf-8"),
                "review\n",
            )
            self.assertFalse(os.path.samefile(tracked, outside))

    def test_source_tree_snapshot_supports_staged_files_before_first_commit(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = repo / "source.txt"
            source.write_text("before\n", encoding="utf-8")
            git(repo, "add", "source.txt")

            before = self.helper["source_tree_snapshot"](repo)
            symbolic_head = git(repo, "symbolic-ref", "HEAD").strip()
            self.assertEqual(before[0], f"unborn:{symbolic_head}")

            git(repo, "symbolic-ref", "HEAD", "refs/heads/other")
            self.assertNotEqual(
                self.helper["source_tree_snapshot"](repo),
                before,
            )
            git(repo, "symbolic-ref", "HEAD", symbolic_head)

            source.write_text("after\n", encoding="utf-8")
            self.assertNotEqual(
                self.helper["source_tree_snapshot"](repo),
                before,
            )

    @unittest.skipIf(os.name == "nt", "the true command is POSIX-only")
    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_cli_detects_source_mutation(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("before\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            git(repo, "commit", "-qm", "initial")
            source.write_text("review me\n", encoding="utf-8")
            codex_bin = write_executable(
                root / "codex",
                fake_codex_script(),
            )
            record_path = root / "record.json"
            env = os.environ.copy()
            env.update(
                {
                    "AUTOREVIEW_FAKE_MUTATE": str(source),
                    "AUTOREVIEW_FAKE_RECORD": str(record_path),
                    "HOME": str(root),
                    "USERPROFILE": str(root),
                }
            )

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(codex_bin),
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout)
            self.assertIn(
                "source changed after the review bundle was created",
                result.stderr,
            )
            self.assertTrue(record_path.is_file())

    def test_source_tree_snapshot_hashes_binary_and_untracked_tail_bytes(
        self,
    ) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            tracked = repo / "tracked.bin"
            tracked.write_bytes(b"\0tracked-before")
            git(repo, "add", "tracked.bin")
            git(repo, "commit", "-qm", "initial")
            untracked = repo / "generated.bin"
            untracked.write_bytes(b"\0" + b"a" * 200_000)
            before = self.helper["source_tree_snapshot"](repo)

            tracked.write_bytes(b"\0tracked-after!")
            self.assertNotEqual(
                self.helper["source_tree_snapshot"](repo),
                before,
            )
            tracked.write_bytes(b"\0tracked-before")
            self.assertEqual(
                self.helper["source_tree_snapshot"](repo),
                before,
            )

            with untracked.open("r+b") as stream:
                stream.seek(-1, os.SEEK_END)
                stream.write(b"b")
            self.assertNotEqual(
                self.helper["source_tree_snapshot"](repo),
                before,
            )

    def test_source_tree_snapshot_includes_index_state(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            source = repo / "source.txt"
            source.write_text("before\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            git(repo, "commit", "-qm", "initial")
            before = self.helper["source_tree_snapshot"](repo)

            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            source.write_text("before\n", encoding="utf-8")
            self.assertNotEqual(
                self.helper["source_tree_snapshot"](repo),
                before,
            )

    def test_source_tree_snapshot_includes_tracked_submodule_contents(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            child = root / "child"
            child.mkdir()
            git(child, "init", "-q")
            source = child / "source.txt"
            source.write_text("before\n", encoding="utf-8")
            git(child, "add", "source.txt")
            git(child, "commit", "-qm", "initial")

            repo = init_repo(root)
            git(
                repo,
                "-c",
                "protocol.file.allow=always",
                "submodule",
                "add",
                "-q",
                str(child),
                "vendor/dependency",
            )
            git(repo, "commit", "-qam", "add submodule")
            before = self.helper["source_tree_snapshot"](repo)

            (repo / "vendor/dependency/source.txt").write_text(
                "after\n",
                encoding="utf-8",
            )
            self.assertNotEqual(
                self.helper["source_tree_snapshot"](repo),
                before,
            )

    def test_installed_java_rejects_launcher_without_runtime(self) -> None:
        launcher = "/usr/bin/java"
        unavailable = subprocess.CompletedProcess([launcher, "-version"], 1)
        with (
            mock.patch("shutil.which", return_value=launcher),
            mock.patch("subprocess.run", return_value=unavailable),
        ):
            self.assertIsNone(installed_java())

    def test_safe_proxy_url_accepts_credential_free_formats(self) -> None:
        for value in (
            "http://proxy.example.invalid:8080",
            "proxy.example.invalid:8080",
            "socks4://proxy.example.invalid",
            "socks4a://proxy.example.invalid",
            "http://[fe80::1%25en0]:8080",
        ):
            with self.subTest(value=value):
                self.assertTrue(self.helper["safe_proxy_url"](value))

        for value in (
            "http://review-user:review-password@proxy.example.invalid:8080",
            "socks5://review-user:review-password@proxy.example.invalid:1080",
        ):
            with self.subTest(value=value):
                self.assertTrue(self.helper["safe_proxy_url"](value))

    def test_safe_engine_env_rejects_malformed_proxy(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir, mock.patch.dict(
            os.environ,
            {
                "HTTPS_PROXY": (
                    "http://review-user:review-password@proxy.example.invalid:bad"
                )
            },
            clear=False,
        ):
            repo = init_repo(Path(tempdir))
            with self.assertRaisesRegex(SystemExit, "malformed proxy"):
                self.helper["safe_engine_env"](repo, engine="codex")

    def test_safe_temp_root_rejects_reviewed_repo_parent(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            hostile_temp = repo / "tmp"
            hostile_temp.mkdir()

            with mock.patch.object(
                tempfile,
                "gettempdir",
                return_value=str(hostile_temp),
            ), self.assertRaisesRegex(
                SystemExit,
                "temporary directory must be outside",
            ):
                self.helper["safe_temp_root"](repo)

    @unittest.skipIf(os.name == "nt", "POSIX Testbox temp-root behavior")
    def test_claude_fable_alias_requires_fable_safe_mode_version(self) -> None:
        args = argparse.Namespace(
            claude_bin="claude",
            fallback_model=None,
            model="fable",
        )
        version_result = subprocess.CompletedProcess(
            ["claude", "--version"],
            0,
            "2.1.169 (Claude Code)",
            "",
        )

        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            with mock.patch.dict(
                self.helper["ensure_claude_isolation_supported"].__globals__,
                {
                    "resolve_command": lambda *_args: "/usr/bin/claude",
                    "safe_engine_env": lambda *_args, **_kwargs: {},
                    "safe_temp_root": lambda _repo: Path(tempdir),
                    "run": lambda *_args, **_kwargs: version_result,
                },
            ), self.assertRaisesRegex(
                SystemExit,
                "2.1.170",
            ):
                self.helper["ensure_claude_isolation_supported"](args, repo)

    @unittest.skipIf(os.name == "nt", "POSIX executable fixture")
    def test_claude_probe_captures_help_from_pipe_sensitive_cli(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            cli = write_executable(root / "claude", r'''#!/usr/bin/env python3
import os
import stat
import sys

if "--version" in sys.argv:
    print("2.1.226 (Claude Code)")
else:
    text = "Usage: claude\n" + " " * 16384
    text += "--safe-mode --setting-sources --strict-mcp-config --disallowedTools --tools\n"
    if stat.S_ISFIFO(os.fstat(1).st_mode):
        text = text[:512]
    sys.stdout.write(text)
''')
            args = argparse.Namespace(claude_bin=str(cli), model=None, fallback_model=None)
            self.helper["ensure_claude_isolation_supported"](args, repo)
            cli.write_text(cli.read_text().replace("--safe-mode", "--unsafe-mode"))
            with self.assertRaisesRegex(SystemExit, "missing from --help: --safe-mode"):
                self.helper["ensure_claude_isolation_supported"](args, repo)

    def test_claude_canonical_fable_model_uses_portable_cli_selector(self) -> None:
        self.assertEqual(
            self.helper["claude_cli_model_selector"]("claude-fable-5"),
            "fable",
        )
        self.assertEqual(
            self.helper["claude_cli_fallback_models"](
                "claude-fable-5,claude-opus-5"
            ),
            "fable,claude-opus-5",
        )

    def test_claude_runs_outside_repo_with_auto_memory_disabled(self) -> None:
        args = argparse.Namespace(
            claude_allowed_tools=None,
            claude_bin="claude",
            fallback_model=None,
            model=None,
            stream_engine_output=False,
            thinking=None,
            tools=False,
            web_search=False,
        )
        observed: dict[str, object] = {}

        def fake_run(
            _cmd: list[str],
            cwd: Path,
            **kwargs: object,
        ) -> subprocess.CompletedProcess[str]:
            observed["cwd"] = cwd
            observed["env"] = kwargs["env"]
            observed["schema"] = json.loads(_cmd[_cmd.index("--json-schema") + 1])
            return subprocess.CompletedProcess([], 0, "{}", "")

        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            with mock.patch.dict(
                self.helper["run_claude"].__globals__,
                {
                    "ensure_claude_isolation_supported": lambda *_args: None,
                    "resolve_command": lambda *_args: "/usr/bin/claude",
                    "run_with_heartbeat": fake_run,
                    "safe_engine_env": lambda *_args, **_kwargs: {
                        "CLAUDE_CODE_DISABLE_AUTO_MEMORY": "1"
                    },
                },
            ):
                self.helper["run_claude"](args, repo, "prompt")

            self.assertFalse(
                self.helper["is_within"](observed["cwd"], repo.resolve())
            )
            self.assertEqual(
                observed["env"]["CLAUDE_CODE_DISABLE_AUTO_MEMORY"],
                "1",
            )
            self.assertEqual(observed["schema"], self.helper["PROVIDER_SCHEMA"])

    def test_codex_env_rejects_executable_dbus_transport(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            try:
                os.environ["DBUS_SESSION_BUS_ADDRESS"] = (
                    "unixexec:path=/tmp/hostile-helper"
                )
                env = self.helper["safe_engine_env"](repo, engine="codex")
                self.assertNotIn("DBUS_SESSION_BUS_ADDRESS", env)
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_multi_provider_engines_preserve_provider_auth(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir).resolve()
            repo = init_repo(root)
            try:
                os.environ["DEEPSEEK_API_KEY"] = "test-token-placeholder"
                os.environ["CEREBRAS_API_KEY"] = "test-token-placeholder"
                os.environ["CLOUDFLARE_ACCOUNT_ID"] = "test-account"
                os.environ["CLOUDFLARE_API_TOKEN"] = "test-token-placeholder"
                os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = (
                    str(root / "provider-credentials.json")
                )
                os.environ["AWS_ROLE_ARN"] = (
                    "arn:aws:iam::123456789012:role/autoreview"
                )
                os.environ["AWS_CONTAINER_AUTHORIZATION_TOKEN"] = (
                    "test-token-placeholder"
                )
                os.environ["AWS_CONTAINER_CREDENTIALS_FULL_URI"] = (
                    "http://169.254.170.2/credentials"
                )
                os.environ["AWS_WEB_IDENTITY_TOKEN_FILE"] = str(
                    root / "web-identity",
                )
                os.environ["AWS_CONFIG_FILE"] = str(root / "aws-config")
                os.environ["AWS_SHARED_CREDENTIALS_FILE"] = str(
                    root / "aws-credentials",
                )
                os.environ["NODE_EXTRA_CA_CERTS"] = str(root / "corporate-ca.pem")
                os.environ["SSL_CERT_FILE"] = str(root / "tls-ca.pem")
                os.environ["SSL_CERT_DIR"] = str(root / "tls-ca")
                os.environ["SNOWFLAKE_ACCOUNT"] = "test-account"
                os.environ["SNOWFLAKE_CORTEX_TOKEN"] = "test-token-placeholder"
                os.environ["AZURE_RESOURCE_NAME"] = "test-resource"
                os.environ["ANTHROPIC_OAUTH_TOKEN"] = "test-token-placeholder"
                os.environ["AWS_BEDROCK_FORCE_HTTP1"] = "1"
                os.environ["AWS_BEDROCK_SKIP_AUTH"] = "1"
                os.environ["AZURE_CLIENT_ID"] = "test-client"
                os.environ["AZURE_CLIENT_SECRET"] = "test-token-placeholder"
                os.environ["AZURE_TENANT_ID"] = "test-tenant"
                os.environ["GCLOUD_PROJECT"] = "test-project"
                os.environ["GOOGLE_CLOUD_PROJECT"] = "test-project"
                os.environ["CODEX_API_KEY"] = "test-token-placeholder"
                os.environ["CODEX_CA_CERTIFICATE"] = str(root / "codex-ca.pem")
                os.environ["COPILOT_GITHUB_TOKEN"] = "test-token-placeholder"
                os.environ["PI_OFFLINE"] = "1"
                os.environ["PI_SKIP_VERSION_CHECK"] = "1"
                os.environ["PI_TELEMETRY"] = "0"
                os.environ["NPM_TOKEN"] = "test-token-placeholder"
                os.environ["SENTRY_API_KEY"] = "test-token-placeholder"
                os.environ["SENTRY_AUTH_TOKEN"] = "test-token-placeholder"
                os.environ["DIGITALOCEAN_ACCESS_TOKEN"] = "test-token-placeholder"
                os.environ["GITLAB_TOKEN"] = "test-token-placeholder"
                os.environ["NODE_OPTIONS"] = "--require=/tmp/unsafe.js"
                os.environ["GOOGLE_EXTERNAL_ACCOUNT_ALLOW_EXECUTABLES"] = "1"
                env = self.helper["safe_engine_env"](repo, engine="pi")
                for key in (
                            "AWS_ROLE_ARN",
                            "AWS_CONTAINER_AUTHORIZATION_TOKEN",
                            "AWS_CONTAINER_CREDENTIALS_FULL_URI",
                            "AWS_BEDROCK_FORCE_HTTP1",
                            "AWS_BEDROCK_SKIP_AUTH",
                            "AWS_CONFIG_FILE",
                            "AWS_SHARED_CREDENTIALS_FILE",
                            "AWS_WEB_IDENTITY_TOKEN_FILE",
                            "CEREBRAS_API_KEY",
                            "CLOUDFLARE_ACCOUNT_ID",
                            "CLOUDFLARE_API_TOKEN",
                            "COPILOT_GITHUB_TOKEN",
                            "DEEPSEEK_API_KEY",
                            "GOOGLE_APPLICATION_CREDENTIALS",
                            "NODE_EXTRA_CA_CERTS",
                            "SSL_CERT_DIR",
                            "SSL_CERT_FILE",
                            "SNOWFLAKE_ACCOUNT",
                            "SNOWFLAKE_CORTEX_TOKEN",
                            "AZURE_RESOURCE_NAME",
                            "ANTHROPIC_OAUTH_TOKEN",
                ):
                    self.assertEqual(env[key], os.environ[key])
                self.assertNotIn("NODE_OPTIONS", env)
                self.assertNotIn("NPM_TOKEN", env)
                self.assertNotIn("SENTRY_API_KEY", env)
                self.assertNotIn("SENTRY_AUTH_TOKEN", env)
                self.assertNotIn("GOOGLE_EXTERNAL_ACCOUNT_ALLOW_EXECUTABLES", env)
                self.assertNotIn("DIGITALOCEAN_ACCESS_TOKEN", env)
                self.assertNotIn("GITLAB_TOKEN", env)
                self.assertEqual(env["PI_OFFLINE"], "1")
                self.assertEqual(env["PI_SKIP_VERSION_CHECK"], "1")
                self.assertEqual(env["PI_TELEMETRY"], "0")

                claude_env = self.helper["safe_engine_env"](repo, engine="claude")
                for key in (
                    "AZURE_CLIENT_ID",
                    "AZURE_CLIENT_SECRET",
                    "AZURE_TENANT_ID",
                    "GCLOUD_PROJECT",
                    "GOOGLE_CLOUD_PROJECT",
                    "AWS_ROLE_ARN",
                    "AWS_CONFIG_FILE",
                    "AWS_SHARED_CREDENTIALS_FILE",
                    "AWS_WEB_IDENTITY_TOKEN_FILE",
                    "GOOGLE_APPLICATION_CREDENTIALS",
                    "NODE_EXTRA_CA_CERTS",
                    "SSL_CERT_DIR",
                    "SSL_CERT_FILE",
                ):
                    self.assertEqual(claude_env[key], os.environ[key])
                self.assertNotIn("DEEPSEEK_API_KEY", claude_env)
                self.assertNotIn("NODE_OPTIONS", claude_env)
                codex_env = self.helper["safe_engine_env"](repo, engine="codex")
                for key in (
                    "CODEX_API_KEY",
                    "CODEX_CA_CERTIFICATE",
                    "SSL_CERT_DIR",
                    "SSL_CERT_FILE",
                ):
                    self.assertEqual(codex_env[key], os.environ[key])
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_multi_provider_custom_credentials_require_explicit_safe_names(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            try:
                os.environ["CORP_LLM_API_KEY"] = "test-token-placeholder"
                os.environ["CORP_AUTH_TOKEN"] = "test-token-placeholder"
                os.environ["AUTOREVIEW_PROVIDER_ENV_ALLOW"] = (
                    "CORP_LLM_API_KEY,CORP_AUTH_TOKEN"
                )

                env = self.helper["safe_engine_env"](repo, engine="pi")
                self.assertEqual(env["CORP_LLM_API_KEY"], os.environ["CORP_LLM_API_KEY"])
                self.assertEqual(env["CORP_AUTH_TOKEN"], os.environ["CORP_AUTH_TOKEN"])
                self.assertNotIn("AUTOREVIEW_PROVIDER_ENV_ALLOW", env)

                os.environ["AUTOREVIEW_PROVIDER_ENV_ALLOW"] = "NODE_OPTIONS"
                with self.assertRaisesRegex(
                    SystemExit,
                    "invalid AUTOREVIEW_PROVIDER_ENV_ALLOW entry",
                ):
                    self.helper["safe_engine_env"](repo, engine="pi")
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_provider_credential_paths_are_forwarded_as_absolute(self) -> None:
        old_env = os.environ.copy()
        old_cwd = Path.cwd()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            try:
                os.chdir(repo)
                os.environ["AWS_CONFIG_FILE"] = "../shared/aws-config"
                os.environ["SSL_CERT_DIR"] = os.pathsep.join(
                    ("../tls/one", "../tls/two"),
                )

                env = self.helper["safe_engine_env"](repo, engine="pi")

                self.assertEqual(
                    env["AWS_CONFIG_FILE"],
                    str((root / "shared" / "aws-config").resolve()),
                )
                self.assertEqual(
                    env["SSL_CERT_DIR"],
                    os.pathsep.join(
                        (
                            str((root / "tls" / "one").resolve()),
                            str((root / "tls" / "two").resolve()),
                        )
                    ),
                )
            finally:
                os.chdir(old_cwd)
                os.environ.clear()
                os.environ.update(old_env)

    def test_engines_reject_repo_local_config_roots(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            try:
                os.environ["CLAUDE_CONFIG_DIR"] = str(repo / ".claude")
                os.environ["CODEX_HOME"] = str(repo / ".codex")
                os.environ["PI_CODING_AGENT_DIR"] = str(repo / ".pi")
                os.environ["CODEX_CA_CERTIFICATE"] = str(repo / "codex-ca.pem")
                os.environ["SSL_CERT_FILE"] = str(repo / "tls-ca.pem")
                os.environ["HOME"] = str(repo)
                os.environ["USERPROFILE"] = str(repo)
                claude_env = self.helper["safe_engine_env"](repo, engine="claude")
                codex_env = self.helper["safe_engine_env"](repo, engine="codex")
                pi_env = self.helper["safe_engine_env"](repo, engine="pi")
                self.assertNotIn("CLAUDE_CONFIG_DIR", claude_env)
                self.assertNotIn("CODEX_HOME", codex_env)
                self.assertNotIn("CODEX_CA_CERTIFICATE", codex_env)
                self.assertNotIn("SSL_CERT_FILE", codex_env)
                self.assertNotIn("PI_CODING_AGENT_DIR", pi_env)
                self.assertNotIn("HOME", claude_env)
                self.assertNotIn("USERPROFILE", claude_env)
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_codex_auth_config_ignores_repo_local_home(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            config_dir = repo / ".codex"
            config_dir.mkdir()
            (config_dir / "config.toml").write_text(
                'forced_login_method = "api"\n',
                encoding="utf-8",
            )
            try:
                os.environ["CODEX_HOME"] = str(config_dir)
                self.assertEqual(self.helper["codex_auth_config_flags"](repo), [])
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_codex_runtime_home_links_only_auth_and_persists_refresh(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source_home = root / "host-home" / ".codex"
            runtime_home = root / "runtime" / "codex-home"
            source_home.mkdir(parents=True)
            source_auth = source_home / "auth.json"
            source_auth.write_text(
                '{"token":"test-token-placeholder"}',
                encoding="utf-8",
            )
            (source_home / "config.toml").write_text(
                'cli_auth_credentials_store = "file"\n',
                encoding="utf-8",
            )
            try:
                os.environ["CODEX_HOME"] = str(source_home)
                linked = self.helper["prepare_codex_runtime_auth"](repo, runtime_home)
                self.assertTrue(linked)
                self.assertTrue((runtime_home / "auth.json").is_file())
                self.assertTrue(
                    os.path.samefile(source_auth, runtime_home / "auth.json")
                )
                self.assertFalse((runtime_home / "config.toml").exists())
                self.assertIn(
                    'cli_auth_credentials_store="file"',
                    self.helper["codex_auth_config_flags"](
                        repo,
                        force_file=True,
                    ),
                )

                (runtime_home / "auth.json").write_text(
                    '{"token":"test-auth-token"}',
                    encoding="utf-8",
                )
                self.assertEqual(
                    json.loads(source_auth.read_text(encoding="utf-8"))["token"],
                    "test-auth-token",
                )
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_codex_runtime_home_does_not_promote_keyring_fallback_file(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source_home = root / "host-home" / ".codex"
            source_home.mkdir(parents=True)
            (source_home / "auth.json").write_text(
                '{"token":"test-token-placeholder"}',
                encoding="utf-8",
            )
            (source_home / "config.toml").write_text(
                'cli_auth_credentials_store = "keyring"\n',
                encoding="utf-8",
            )
            try:
                os.environ["CODEX_HOME"] = str(source_home)
                self.assertFalse(
                    self.helper["prepare_codex_runtime_auth"](
                        repo,
                        root / "runtime" / "codex-home",
                    )
                )
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_codex_runtime_home_fails_closed_when_linking_is_unavailable(
        self,
    ) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source_home = root / "host-home" / ".codex"
            source_home.mkdir(parents=True)
            source_auth = source_home / "auth.json"
            source_auth.write_text(
                '{"token":"test-token-placeholder"}',
                encoding="utf-8",
            )
            try:
                os.environ["CODEX_HOME"] = str(source_home)
                with (
                    mock.patch("os.link", side_effect=OSError("blocked")),
                    mock.patch.object(
                        Path,
                        "symlink_to",
                        side_effect=OSError("blocked"),
                    ),
                    self.assertRaisesRegex(
                        SystemExit,
                        "unable to isolate Codex file authentication",
                    ),
                ):
                    self.helper["prepare_codex_runtime_auth"](
                        repo,
                        root / "runtime" / "codex-home",
                    )
                self.assertEqual(
                    json.loads(source_auth.read_text(encoding="utf-8"))["token"],
                    "test-token-placeholder",
                )
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_codex_runtime_home_preserves_auto_keyring_namespace(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source_home = root / "host-home" / ".codex"
            runtime_home = root / "runtime" / "codex-home"
            source_home.mkdir(parents=True)
            (source_home / "auth.json").write_text(
                '{"token":"test-token-placeholder"}',
                encoding="utf-8",
            )
            (source_home / "config.toml").write_text(
                'cli_auth_credentials_store = "auto"\n',
                encoding="utf-8",
            )
            try:
                os.environ["CODEX_HOME"] = str(source_home)
                linked = self.helper["prepare_codex_runtime_auth"](
                    repo,
                    runtime_home,
                )
                self.assertFalse(linked)
                flags = self.helper["codex_auth_config_flags"](repo)
                self.assertIn('cli_auth_credentials_store="auto"', flags)
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_empty_codex_home_uses_external_default(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            default_home = root / "host-home" / ".codex"
            default_home.mkdir(parents=True)
            try:
                os.environ["CODEX_HOME"] = ""
                with mock.patch.object(
                    Path,
                    "home",
                    return_value=default_home.parent,
                ):
                    self.assertEqual(
                        self.helper["codex_source_home"](repo),
                        default_home.resolve(),
                    )
            finally:
                os.environ.clear()
                os.environ.update(old)

    def test_empty_codex_home_ignores_missing_default(self) -> None:
        old = os.environ.copy()
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            missing_home = root / "missing-home"
            try:
                os.environ["CODEX_HOME"] = ""
                with mock.patch.object(
                    Path,
                    "home",
                    return_value=missing_home,
                ):
                    self.assertIsNone(
                        self.helper["codex_source_home"](repo)
                    )
            finally:
                os.environ.clear()
                os.environ.update(old)

    @unittest.skipIf(os.name == "nt", "POSIX shared scratch roots")
    def test_codex_rejects_shared_scratch_before_runtime_setup(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            binary = write_executable(root / "codex", fake_codex_script())
            source_home = root / "synthetic-auth-home"
            source_home.mkdir()
            source_auth = source_home / "auth.json"
            source_auth.write_text('{"fixture":"synthetic"}')
            auth_before = source_auth.read_bytes()
            links_before = source_auth.stat().st_nlink
            args = argparse.Namespace(
                codex_bin=str(binary), model=None, tools=True, web_search=False,
                thinking=None, codex_config=[], codex_speed=None,
                stream_engine_output=False,
            )
            for scratch_root in ("/tmp", "/var/tmp"):
                for entry in ("ensure_codex_isolation_supported", "run_codex"):
                    with self.subTest(root=scratch_root, entry=entry), tempfile.TemporaryDirectory(
                        prefix="autoreview-scratch-order.", dir=scratch_root,
                    ) as scratch:
                        runtime_auth = mock.Mock(wraps=self.helper["prepare_codex_runtime_auth"])
                        with (
                            mock.patch.dict(os.environ, {
                                "PATH": os.environ["PATH"], "CODEX_HOME": str(source_home),
                                "HOME": str(root),
                            }, clear=True),
                            mock.patch.object(sys, "platform", "darwin"),
                            mock.patch.object(tempfile, "gettempdir", return_value=scratch),
                            mock.patch.object(tempfile, "TemporaryDirectory", wraps=tempfile.TemporaryDirectory) as directories,
                            mock.patch.object(tempfile, "NamedTemporaryFile", wraps=tempfile.NamedTemporaryFile) as files,
                            mock.patch.dict(self.helper[entry].__globals__, {
                                "prepare_codex_runtime_auth": runtime_auth,
                            }),
                        ):
                            self.assertEqual(self.helper["safe_temp_root"](repo), Path(scratch).resolve())
                            with self.assertRaisesRegex(SystemExit, "outside shared scratch"):
                                if entry == "run_codex":
                                    self.helper[entry](args, repo, "synthetic review input")
                                else:
                                    self.helper[entry](args, repo)
                            runtime_auth.assert_not_called()
                            directories.assert_not_called()
                            files.assert_not_called()
                        self.assertEqual(list(Path(scratch).iterdir()), [])
                        self.assertEqual(source_auth.read_bytes(), auth_before)
                        self.assertEqual(source_auth.stat().st_nlink, links_before)

    def test_codex_isolation_restricts_tool_environment(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            runtime_root = root / "runtime"
            flags = self.helper["codex_config_isolation_flags"](
                repo,
                runtime_root,
            )

        for required in (
            f"sqlite_home={json.dumps(str((runtime_root / 'state').resolve()))}",
            f"log_dir={json.dumps(str((runtime_root / 'log').resolve()))}",
            "features.shell_snapshot=false",
            "features.hooks=false",
            "features.plugins=false",
            "skills.include_instructions=false",
            "skills.config=[]",
            'shell_environment_policy.inherit="core"',
            "shell_environment_policy.ignore_default_excludes=false",
            "shell_environment_policy.experimental_use_profile=false",
            "allow_login_shell=false",
            'default_permissions="autoreview"',
        ):
            self.assertIn(required, flags)
        filesystem = '":minimal"="read",":workspace_roots"="read"'
        if sys.platform == "darwin":
            filesystem += ',"/tmp{,/**}"="deny","/private/tmp{,/**}"="deny","/var/tmp{,/**}"="deny","/private/var/tmp{,/**}"="deny"'
        self.assertIn(f"permissions.autoreview.filesystem={{{filesystem}}}", flags)
        set_flag = next(
            flag for flag in flags if flag.startswith("shell_environment_policy.set=")
        )
        for key, value in self.helper["codex_tool_git_env"]().items():
            self.assertIn(f"{key}={json.dumps(value)}", set_flag)

    def test_codex_isolation_overrides_round_trip_unicode_paths(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = root / "repo-🦞"
            repo.mkdir()
            runtime = root / "runtime-🦞"
            tool_env = {"GIT_CONFIG_VALUE_0": "value-🦞\x7f"}
            with mock.patch.dict(self.helper["codex_config_isolation_flags"].__globals__, {
                "codex_tool_git_env": lambda: tool_env,
            }):
                flags = self.helper["codex_config_isolation_flags"](repo, runtime)
            parsed = tomllib.loads("\n".join(flags[1::2]))
            self.assertEqual(parsed["sqlite_home"], str((runtime / "state").resolve()))
            self.assertEqual(parsed["log_dir"], str((runtime / "log").resolve()))
            self.assertEqual(parsed["projects"], {str(repo.resolve()): {"trust_level": "untrusted"}})
            self.assertEqual(parsed["shell_environment_policy"]["set"], tool_env)
            expected = {":minimal": "read", ":workspace_roots": "read"}
            if sys.platform == "darwin":
                expected.update({f"{path}{{,/**}}": "deny" for path in self.helper["CODEX_MACOS_SCRATCH_ROOTS"]})
            self.assertEqual(parsed["permissions"]["autoreview"]["filesystem"], expected)

    def test_safe_engine_env_excludes_repo_local_path_entries(self) -> None:
        old_path = os.environ.get("PATH", "")
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            os.environ["PATH"] = f"{repo}{os.pathsep}{old_path}"
            try:
                env = self.helper["safe_engine_env"](repo, engine="codex")
            finally:
                os.environ["PATH"] = old_path

            self.assertNotIn(str(repo.resolve()), env["PATH"].split(os.pathsep))

    def test_find_command_rejects_explicit_repo_local_executables(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            (repo / "tools").mkdir()
            (root / "trusted").mkdir()
            repo_bin = write_executable(
                repo / "tools" / "codex",
                "#!/bin/sh\nexit 0\n",
            )
            external_bin = write_executable(
                root / "trusted" / "codex",
                "#!/bin/sh\nexit 0\n",
            )

            self.assertIsNone(
                self.helper["find_command"]("tools/codex", repo),
            )
            self.assertIsNone(
                self.helper["find_command"](str(repo_bin), repo),
            )
            self.assertEqual(
                self.helper["find_command"](str(external_bin), repo),
                str(Path(os.path.abspath(external_bin))),
            )
            self.assertEqual(
                self.helper["find_command"]("../trusted/codex", repo),
                str(Path(os.path.abspath(external_bin))),
            )

            external_link = root / "trusted" / "external-codex"
            repo_link = repo / "tools" / "external-codex"
            try:
                external_link.symlink_to(repo_bin)
                repo_link.symlink_to(external_bin)
            except OSError as exc:
                if os.name == "nt" and getattr(exc, "winerror", None) == 1314:
                    return
                raise
            self.assertIsNone(
                self.helper["find_command"](str(external_link), repo),
            )
            self.assertIsNone(
                self.helper["find_command"](str(repo_link), repo),
            )

    def test_validate_report_normalizes_absolute_in_repo_finding_paths(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            report = {
                "findings": [
                    {
                        "title": "First",
                        "body": "Body",
                        "priority": "P1",
                        "confidence": 0.9,
                        "category": "bug",
                        "code_location": {
                            "file_path": str(repo / "src" / "index.ts"),
                            "line": 1,
                        },
                    },
                    {
                        "title": "Second",
                        "body": "Body",
                        "priority": "P2",
                        "confidence": 0.9,
                        "category": "bug",
                        "code_location": {"file_path": "src/other.ts", "line": 2},
                    },
                ],
                "overall_correctness": "patch is incorrect",
                "overall_explanation": "Explanation",
                "overall_confidence": 0.9,
            }

            self.helper["validate_report"](
                report, repo, {"src/index.ts", "src/other.ts"}, []
            )

            self.assertEqual(
                report["findings"][0]["code_location"]["file_path"], "src/index.ts"
            )
            self.assertEqual(
                [finding["title"] for finding in report["findings"]],
                ["First", "Second"],
            )

            for invalid in (
                Path(tempdir) / "elsewhere" / "outside.ts",
                repo.with_name(repo.name + "-neighbor") / "src" / "index.ts",
                repo / "src" / ".." / "src" / "index.ts",
            ):
                with self.subTest(invalid=invalid):
                    outside = copy.deepcopy(report)
                    outside["findings"][0]["code_location"]["file_path"] = str(invalid)
                    with self.assertRaisesRegex(SystemExit, "invalid file path"):
                        self.helper["validate_report"](
                            outside, repo, {"src/index.ts", "src/other.ts"}, []
                        )

            unscoped = copy.deepcopy(report)
            unscoped["findings"][0]["code_location"]["file_path"] = str(repo / "unchanged.ts")
            with contextlib.redirect_stderr(io.StringIO()):
                self.helper["validate_report"](
                    unscoped, repo, {"src/index.ts", "src/other.ts"}, []
                )
            self.assertEqual([item["title"] for item in unscoped["findings"]], ["Second"])
            self.assertEqual(unscoped["scope_rejected_findings"][0]["code_location"]["file_path"],
                             "unchanged.ts")
            self.assertEqual(self.helper["review_status"](unscoped, complete=True), "incomplete")

            if os.name != "nt":
                target = repo / "unchanged.ts"
                target.write_text("unchanged\n", encoding="utf-8")
                inside_link = repo / "changed-link.ts"
                inside_link.symlink_to(target.name)
                repo_alias = Path(tempdir) / "repo-alias"
                repo_alias.symlink_to(repo, target_is_directory=True)
                for root in (repo, repo_alias):
                    with self.subTest(symlink_root=root):
                        linked = copy.deepcopy(report)
                        linked["findings"][0]["code_location"]["file_path"] = str(root / inside_link.name)
                        self.helper["validate_report"](linked, repo, {inside_link.name, "src/other.ts"}, [])
                        self.assertEqual(linked["findings"][0]["code_location"]["file_path"], inside_link.name)

                (repo / "src").mkdir()
                (repo / "src" / inside_link.name).symlink_to("../unchanged.ts")
                subdir_alias = Path(tempdir) / "src-alias"
                subdir_alias.symlink_to(repo / "src", target_is_directory=True)
                file_alias = Path(tempdir) / "file-alias.ts"
                file_alias.symlink_to(target)
                for path, expected in (
                    (subdir_alias / "index.ts", "src/index.ts"),
                    (subdir_alias / inside_link.name, "src/changed-link.ts"),
                    (file_alias, "unchanged.ts"),
                ):
                    with self.subTest(alias=path):
                        aliased = copy.deepcopy(report)
                        aliased["findings"][0]["code_location"]["file_path"] = str(path)
                        self.helper["validate_report"](aliased, repo, {expected, "src/other.ts"}, [])
                        self.assertEqual(aliased["findings"][0]["code_location"]["file_path"], expected)

                (repo / "alias").symlink_to("src", target_is_directory=True)
                for path, expected in (
                    (repo / "alias" / "index.ts", "src/index.ts"),
                    (inside_link, "unchanged.ts"),
                ):
                    with self.subTest(unchanged_alias=path):
                        aliased = copy.deepcopy(report)
                        aliased["findings"][0]["code_location"]["file_path"] = str(path)
                        self.helper["validate_report"](aliased, repo, {expected, "src/other.ts"}, [])
                        self.assertEqual(aliased["findings"][0]["code_location"]["file_path"], expected)

                for name in (r"src\index.ts", " spaced \tname.ts"):
                    with self.subTest(literal=name):
                        literal = copy.deepcopy(report)
                        literal["findings"][0]["code_location"]["file_path"] = str(repo / name)
                        self.helper["validate_report"](literal, repo, {name, "src/other.ts"}, [])
                        self.assertEqual(literal["findings"][0]["code_location"]["file_path"], name)

                link = repo / "escape"
                link.symlink_to(Path(tempdir), target_is_directory=True)
                outside = copy.deepcopy(report)
                outside["findings"][0]["code_location"]["file_path"] = str(link / "outside.ts")
                with self.assertRaisesRegex(SystemExit, "invalid file path"):
                    self.helper["validate_report"](outside, repo, {"escape/outside.ts"}, [])

    def test_validate_report_normalizes_relative_finding_paths(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            report = {
                "findings": [
                    {
                        "title": "Finding",
                        "body": "Body",
                        "priority": "P1",
                        "confidence": 0.9,
                        "category": "bug",
                        "code_location": {"file_path": r".\src\index.ts", "line": 1},
                    }
                ],
                "overall_correctness": "patch is incorrect",
                "overall_explanation": "Explanation",
                "overall_confidence": 0.9,
            }

            self.helper["validate_report"](report, repo, {"src/index.ts"}, [])

            self.assertEqual(report["findings"][0]["code_location"]["file_path"], "src/index.ts")

            report["findings"][0]["code_location"]["file_path"] = r"src\index.ts"
            self.helper["validate_report"](report, repo, {r"src\index.ts"}, [])
            self.assertEqual(
                report["findings"][0]["code_location"]["file_path"],
                r"src\index.ts",
            )

            literal = copy.deepcopy(report)
            literal["findings"][0]["code_location"]["file_path"] = " "
            self.helper["validate_report"](literal, repo, {" "}, [])
            self.assertEqual(literal["findings"][0]["code_location"]["file_path"], " ")
            with contextlib.redirect_stderr(io.StringIO()):
                self.helper["validate_report"](literal, repo, {"src/index.ts"}, [])
            self.assertEqual(literal["findings"], [])
            self.assertEqual(self.helper["review_status"](literal, complete=True), "incomplete")

            for invalid_path in ("", 123, None, True):
                with self.subTest(invalid_path=invalid_path):
                    report["findings"][0]["code_location"] = {
                        "file_path": invalid_path,
                        "line": 1,
                    }
                    with self.assertRaisesRegex(SystemExit, "invalid location"):
                        self.helper["validate_report"](
                            report,
                            repo,
                            {"src/index.ts"},
                            [],
                        )

            report["findings"][0]["code_location"] = {
                "file_path": "src/index.ts",
                "line": True,
            }
            with self.assertRaisesRegex(SystemExit, "invalid location"):
                self.helper["validate_report"](report, repo, {"src/index.ts"}, [])

            report["findings"][0]["code_location"] = {
                "file_path": "src/index.ts",
                "line": 1,
                "extra": "ignored",
            }
            with self.assertRaisesRegex(
                SystemExit,
                "invalid code_location keys",
            ):
                self.helper["validate_report"](report, repo, {"src/index.ts"}, [])

    def test_print_report_escapes_terminal_controls(self) -> None:
        report = {
            "findings": [
                {
                    "title": "clear\x1b[2Jscreen",
                    "body": "first line\nsecond\u202eline café\udc9b",
                    "priority": "P1",
                    "confidence": 0.9,
                    "category": "security",
                    "code_location": {
                        "file_path": "src/\x9b2Jfile.py",
                        "line": 1,
                    },
                }
            ],
            "overall_correctness": "patch is incorrect",
            "overall_explanation": "explanation\x07",
            "overall_confidence": 0.9,
        }
        report["review_status"] = self.helper["review_status"](report, complete=True)
        output = io.StringIO()

        with contextlib.redirect_stdout(output):
            self.helper["print_report"](report, label="review\x00label")

        rendered = output.getvalue()
        for control in (
            "\x00",
            "\x07",
            "\x1b",
            "\x9b",
            "\u202e",
            "\udc9b",
        ):
            self.assertNotIn(control, rendered)
        for escaped in (
            r"review\x00label",
            r"clear\x1b[2Jscreen",
            r"src/\x9b2Jfile.py",
            r"second\u202eline café\udc9b",
            r"explanation\x07",
        ):
            self.assertIn(escaped, rendered)
        self.assertIn("first line\nsecond", rendered)

    def test_validate_report_escapes_controls_in_errors(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            report = {
                "findings": [
                    {
                        "title": "Finding",
                        "body": "Body",
                        "priority": "P1\x1b]52;c;VEVTVA==\x07",
                        "confidence": 0.9,
                        "category": "security",
                        "code_location": {
                            "file_path": "src/index.py",
                            "line": 1,
                        },
                    }
                ],
                "overall_correctness": "patch is incorrect",
                "overall_explanation": "Explanation",
                "overall_confidence": 0.9,
            }

            with self.assertRaises(SystemExit) as raised:
                self.helper["validate_report"](
                    report,
                    repo,
                    {"src/index.py"},
                    [],
                )

        message = str(raised.exception)
        self.assertNotIn("\x1b", message)
        self.assertNotIn("\x07", message)
        self.assertIn(r"P1\x1b]52;c;VEVTVA==\x07", message)

    def test_safe_engine_env_ignores_inaccessible_path_entries(self) -> None:
        old_path = os.environ.get("PATH", "")
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            blocked = root / "blocked"
            os.environ["PATH"] = f"{blocked}{os.pathsep}{old_path}"
            original_exists = Path.exists

            def fake_exists(path: Path) -> bool:
                if str(path) == str(blocked):
                    raise PermissionError("access denied")
                return original_exists(path)

            try:
                with mock.patch.object(Path, "exists", fake_exists):
                    env = self.helper["safe_engine_env"](repo, engine="codex")
            finally:
                os.environ["PATH"] = old_path

            self.assertNotIn(str(blocked), env["PATH"].split(os.pathsep))

    def test_run_with_heartbeat_replaces_undecodable_engine_output(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            result = self.helper["run_with_heartbeat"](
                [
                    sys.executable,
                    "-c",
                    "import sys; sys.stdout.buffer.write(b'\\x90\\n')",
                ],
                Path(tempdir),
                label="decode-test",
                heartbeat_seconds=1,
            )

        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("\ufffd", result.stdout)

    def test_run_with_heartbeat_bounds_a_silent_reviewer_when_configured(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            result = self.helper["run_with_heartbeat"](
                [sys.executable, "-c", "import time; time.sleep(2)"],
                Path(tempdir),
                label="silent-reviewer",
                heartbeat_seconds=0.01,
                max_runtime_seconds=0.05,
            )

        self.assertEqual(result.returncode, 124)
        self.assertIn("silent-reviewer engine timed out after 0.05s", result.stderr)

    def test_engine_timeout_accepts_only_positive_finite_seconds(self) -> None:
        parser = self.helper["positive_float"]
        self.assertEqual(parser("1800"), 1800)
        for value in ("0", "-1", "nan", "inf", "soon"):
            with self.subTest(value=value), self.assertRaises(argparse.ArgumentTypeError):
                parser(value)

    def test_reviewer_runtime_deadline_is_disabled_by_default(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            result = self.helper["run_with_heartbeat"](
                [sys.executable, "-c", "import time; time.sleep(0.05)"],
                Path(tempdir),
                label="compatible-reviewer",
                heartbeat_seconds=0.01,
            )

        self.assertEqual(result.returncode, 0, result.stderr)

    def test_reviewer_exit_after_output_eof_preserves_deadline_and_exit_status(self) -> None:
        script = (
            "import os,sys,time; from pathlib import Path; "
            "print('retained stdout', flush=True); "
            "print('retained stderr', file=sys.stderr, flush=True); "
            "Path(sys.argv[1]).touch(); os.close(1); os.close(2); "
            "time.sleep(float(sys.argv[2])); Path(sys.argv[3]).touch(); os._exit(7)"
        )
        cases = (
            ("no deadline", None, 0.75, 7),
            ("quick exit", 0.5, 0.05, 7),
            ("deadline exceeded", 0.5, 2, 124),
        )
        for stream_output in (False, True):
            for case, max_runtime_seconds, hold_seconds, expected_code in cases:
                with self.subTest(stream_output=stream_output, case=case), tempfile.TemporaryDirectory() as tempdir:
                    root = Path(tempdir)
                    ready = root / "ready"
                    finished = root / "finished"
                    deadline_context = (
                        deadline_after_reviewer_ready(self.helper, ready)
                        if max_runtime_seconds is not None else contextlib.nullcontext()
                    )
                    registered = mock.Mock(wraps=self.helper["register_owned_process"])
                    with deadline_context, mock.patch.dict(
                        self.helper["run_with_heartbeat"].__globals__,
                        {"register_owned_process": registered},
                    ):
                        result = self.helper["run_with_heartbeat"](
                            [sys.executable, "-c", script, str(ready), str(hold_seconds), str(finished)],
                            root,
                            label="early-eof-reviewer",
                            heartbeat_seconds=0.01,
                            max_runtime_seconds=max_runtime_seconds,
                            stream_output=stream_output,
                            stream_display=lambda _name, _line: None,
                        )

                    registered.assert_called_once()
                    proc = registered.call_args.args[0]
                    self.assertIsNotNone(proc.returncode)
                    self.assertNotIn(proc.pid, self.helper["_OWNED_PROCESSES"])
                    self.assertTrue(proc.stdout.closed)
                    self.assertTrue(proc.stderr.closed)
                    self.assertEqual(result.stdout, "retained stdout\n")
                    self.assertTrue(result.stderr.startswith("retained stderr\n"))
                    self.assertEqual(result.returncode, expected_code, result.stderr)
                    timed_out = expected_code == 124
                    self.assertEqual(isinstance(result, self.helper["TimedOutEngineProcess"]), timed_out)
                    self.assertEqual(finished.exists(), not timed_out)
                    if timed_out:
                        self.assertIn("early-eof-reviewer engine timed out after 0.5s", result.stderr)

    @unittest.skipUnless(os.name == "posix", "process groups require POSIX")
    def test_streaming_deadline_kills_sigterm_resistant_continuous_output(self) -> None:
        child = (
            "import signal,sys,time; from pathlib import Path; "
            "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
            "Path(sys.argv[1]).touch(); "
            "time.sleep(60)"
        )
        script = (
            "import signal,subprocess,sys,time; "
            "signal.signal(signal.SIGTERM, signal.SIG_IGN); "
            f"child=subprocess.Popen([sys.executable, '-c', {child!r}, sys.argv[1]]); "
            "print(child.pid, flush=True); "
            "\nwhile True: print('tick', flush=True); time.sleep(0.005)"
        )
        started = time.monotonic()
        with tempfile.TemporaryDirectory() as tempdir, deadline_after_reviewer_ready(
            self.helper, Path(tempdir) / "ready",
        ):
            result = self.helper["run_with_heartbeat"](
                [sys.executable, "-c", script, str(Path(tempdir) / "ready")],
                Path(tempdir),
                label="streaming-reviewer",
                heartbeat_seconds=0.01,
                # Allow interpreter startup before exercising continuous output.
                max_runtime_seconds=0.5,
                stream_output=True,
                stream_display=lambda _name, _line: None,
            )
        elapsed = time.monotonic() - started

        self.assertEqual(result.returncode, 124, result.stderr)
        self.assertIn("tick", result.stdout)
        self.assertIn("streaming-reviewer engine timed out after 0.5s", result.stderr)
        self.assertLess(elapsed, 5)
        child_pid = int(result.stdout.splitlines()[0])
        deadline = time.monotonic() + 1
        while posix_process_is_running(child_pid) and time.monotonic() < deadline:
            time.sleep(0.01)
        self.assertFalse(posix_process_is_running(child_pid))

    @unittest.skipUnless(os.name == "posix", "detached process groups require POSIX")
    def test_deadline_bounds_drain_when_descendant_retains_pipe(self) -> None:
        child = "import time; time.sleep(60)"
        script = (
            "import subprocess,sys; from pathlib import Path; "
            f"child=subprocess.Popen([sys.executable, '-c', {child!r}], start_new_session=True); "
            "print(child.pid, flush=True); Path(sys.argv[1]).touch()"
        )
        for stream_output in (False, True):
            with self.subTest(stream_output=stream_output):
                child_pid: int | None = None
                started = time.monotonic()
                try:
                    with tempfile.TemporaryDirectory() as tempdir, deadline_after_reviewer_ready(
                        self.helper, Path(tempdir) / "ready",
                    ), mock.patch.dict(
                        self.helper["EngineRuntimeDeadline"].terminate.__globals__,
                        {
                            "_TIMED_OUT_STREAM_DRAIN_SECONDS": 0.05,
                            # Model Windows' documented best-effort cleanup: the
                            # leader is reaped while its detached descendant and
                            # inherited output handle survive.
                            "terminate_process_group": lambda proc: proc.poll(),
                        },
                    ):
                        result = self.helper["run_with_heartbeat"](
                            [sys.executable, "-c", script, str(Path(tempdir) / "ready")],
                            Path(tempdir),
                            label="retained-pipe-reviewer",
                            heartbeat_seconds=0.01,
                            # Let the child publish its PID before the deadline.
                            max_runtime_seconds=0.5,
                            stream_output=stream_output,
                            stream_display=lambda _name, _line: None,
                        )
                    child_pid = int(result.stdout.strip())
                finally:
                    if child_pid is not None:
                        try:
                            os.kill(child_pid, signal.SIGKILL)
                        except ProcessLookupError:
                            pass

                self.assertEqual(result.returncode, 124, result.stderr)
                self.assertIn("retained-pipe-reviewer engine timed out", result.stderr)
                self.assertLess(time.monotonic() - started, 2)

    def test_large_prompt_and_dataset_files_are_captured_completely(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            repo = init_repo(Path(tempdir))
            evidence = repo / "evidence.txt"
            content = "界\r\n" * 120_000 + "COMPLETE_EVIDENCE_TAIL\n"
            evidence.write_bytes(content.encode("utf-8"))
            captured = self.helper["capture_evidence_inputs"](
                argparse.Namespace(prompt=[], prompt_file=["evidence.txt"], dataset=["evidence.txt"]), repo,
            )
            self.assertEqual(captured.prompt, "# Prompt file: evidence.txt\n" + content)
            self.assertEqual(captured.datasets[0].content, content)
            self.helper["verify_evidence"](repo, captured.files)

    def test_evidence_capture_rejects_files_changed_during_open_or_read(self) -> None:
        for operation in ("open", "read"):
            with self.subTest(operation=operation), tempfile.TemporaryDirectory() as tempdir:
                repo = init_repo(Path(tempdir))
                path = repo / "evidence.txt"
                path.write_bytes(b"review context\n" * 20_000)
                original = getattr(os, operation)
                changed = False

                def mutate(*args, **kwargs):
                    nonlocal changed
                    if operation == "open" and not changed:
                        replacement = repo / "replacement.txt"
                        replacement.write_bytes(path.read_bytes())
                        replacement.replace(path)
                    result = original(*args, **kwargs)
                    if operation == "read" and not changed:
                        with path.open("ab") as stream:
                            stream.write(b"new tail\n")
                    changed = True
                    return result

                with mock.patch.object(os, operation, side_effect=mutate):
                    with self.assertRaisesRegex(SystemExit, "file changed while opening|file changed while reading"):
                        self.helper["capture_evidence_file"](repo, "evidence.txt", "--dataset")

    def test_claude_inventory_is_bundle_and_web_only(self) -> None:
        args = argparse.Namespace(
            claude_allowed_tools="WebFetch(domain:docs.example.com),WebSearch",
            web_search=True,
        )

        self.assertEqual(
            self.helper["claude_allowed_tools"](args),
            "WebFetch(domain:docs.example.com),WebSearch",
        )
        self.assertEqual(
            self.helper["claude_tool_inventory"](args),
            "WebFetch,WebSearch",
        )

        args.web_search = False
        self.assertEqual(
            self.helper["claude_allowed_tools"](args),
            "",
        )

        args.claude_allowed_tools = "Read"
        with self.assertRaisesRegex(SystemExit, "not read-only"):
            self.helper["claude_tool_inventory"](args)

        args.web_search = True
        args.claude_allowed_tools = "WebFetch"
        with self.assertRaisesRegex(SystemExit, "one explicit domain"):
            self.helper["claude_tool_inventory"](args)

    def test_review_patch_allows_safe_multiline_call_hunks(self) -> None:
        patch = (
            "diff --git a/safe.py b/safe.py\n"
            "--- a/safe.py\n"
            "+++ b/safe.py\n"
            "@@ -0,0 +1,3 @@\n"
            "+"
            + "pass"
            + "word = getpass.getpass(\n"
            '+    "Password: ",\n'
            "+)\n"
        )

        self.assertEqual(
            self.helper["validate_review_patch"](
                ["safe.py"],
                patch,
            ),
            patch,
        )

    def test_stream_displays_escape_terminal_controls(self) -> None:
        control = chr(27) + "]52;c;VEVTVA==" + chr(7)
        codex = self.helper["CodexStreamDisplay"]()
        claude = self.helper["ClaudeStreamDisplay"]()
        codex_message = json.dumps(
            {
                "type": "item.completed",
                "item": {
                    "type": "agent_message",
                    "text": control,
                },
            }
        )

        for displayed in (
            codex("stdout", codex_message + "\n"),
            codex("stderr", control + "\n"),
            claude("stderr", control + "\n"),
        ):
            self.assertIsNotNone(displayed)
            assert displayed is not None
            self.assertNotIn(chr(27), displayed)
            self.assertNotIn(chr(7), displayed)
            self.assertIn(r"\x1b", displayed)
            self.assertIn(r"\x07", displayed)
            self.assertTrue(displayed.endswith("\n"))

    def test_run_with_stream_escapes_terminal_output_only(self) -> None:
        control = chr(27) + "]52;c;VEVTVA==" + chr(7)
        script = (
            "import sys;"
            "value=chr(27)+']52;c;VEVTVA=='+chr(7);"
            "sys.stdout.write(value+'\\n');"
            "sys.stderr.write(value+'\\n')"
        )
        stdout = io.StringIO()
        stderr = io.StringIO()

        with (
            contextlib.redirect_stdout(stdout),
            contextlib.redirect_stderr(stderr),
        ):
            result = self.helper["run_with_stream"](
                [sys.executable, "-c", script],
                Path.cwd(),
                input_text=None,
                label="stream-test",
                heartbeat_seconds=60,
                stream_display=None,
            )

        self.assertIn(control, result.stdout)
        self.assertIn(control, result.stderr)
        for displayed in (stdout.getvalue(), stderr.getvalue()):
            self.assertNotIn(chr(27), displayed)
            self.assertNotIn(chr(7), displayed)
            self.assertIn(r"\x1b", displayed)
            self.assertIn(r"\x07", displayed)
            self.assertTrue(displayed.endswith("\n"))

    def test_kimi_review_and_dry_run_refuse_before_preparation(self) -> None:
        names = ("preflight_git", "repo_root", "capture_evidence_inputs", "source_tree_snapshot",
                 "build_bundle", "prepare_review_prompts", "resolve_engine_binary", "run_engine")
        for environment in (False, True):
            for dry_run in (False, True):
                with self.subTest(environment=environment, dry_run=dry_run):
                    argv = [str(SCRIPT), "--kimi-bin", "synthetic-kimi"]
                    if not environment:
                        argv += ["--engine", "kimi"]
                    if dry_run:
                        argv += ["--dry-run"]
                    env = {"AUTOREVIEW_ENGINE": "kimi"} if environment else {}
                    guards = {name: mock.Mock(side_effect=AssertionError(f"refused engine reached {name}"))
                              for name in names}
                    with mock.patch.dict(self.helper["main_impl"].__globals__, guards), \
                            mock.patch.dict(os.environ, env, clear=True), mock.patch.object(sys, "argv", argv), \
                            contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
                        with self.assertRaises(SystemExit) as caught:
                            self.helper["main_impl"]()
                    self.assertIn("kimi review is unavailable", str(caught.exception.code).lower())
                    self.assertIn("private input channel", str(caught.exception.code).lower())
                    for guard in guards.values():
                        guard.assert_not_called()

    def test_resolve_engine_binary_rejects_codex_no_tools(self) -> None:
        # run_codex() unconditionally refuses --no-tools (see line ~10318);
        # the preflight must report that same rejection instead of reporting
        # codex available just because its binary resolves.
        resolve_engine_binary = self.helper["resolve_engine_binary"]
        reviewer = argparse.Namespace(engine="codex", tools=False, codex_bin="codex")
        available, reason = resolve_engine_binary(reviewer, Path("."))
        self.assertFalse(available)
        self.assertIn("--no-tools", reason)
        self.assertIn("not supported by the Codex engine", reason)

    def test_resolve_engine_binary_checks_path_resolution(self) -> None:
        resolve_engine_binary = self.helper["resolve_engine_binary"]
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            fake_bin_dir = root / "bin"
            fake_bin_dir.mkdir()
            write_executable(
                fake_bin_dir / "codex",
                "#!/usr/bin/env python3\nraise SystemExit(0)\n",
            )
            found = argparse.Namespace(engine="codex", codex_bin="codex")
            with mock.patch.dict(
                os.environ,
                {"PATH": f"{fake_bin_dir}{os.pathsep}{os.environ.get('PATH', '')}", "CODEX_HOME": str(root)},
            ):
                available, reason = resolve_engine_binary(found, repo)
            self.assertTrue(available, reason)
            self.assertIsNone(reason)

            missing = argparse.Namespace(
                engine="claude",
                claude_bin="definitely-not-a-real-claude-binary",
            )
            available, reason = resolve_engine_binary(missing, repo)
            self.assertFalse(available)
            self.assertIn("executable not found", reason)

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_rejects_codex_launcher_broken_by_isolated_home(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            source_home = root / "source-codex-home"
            direct_bin = (
                source_home
                / "packages"
                / "standalone"
                / "current"
                / "bin"
                / "codex"
            )
            direct_bin.parent.mkdir(parents=True)
            write_executable(direct_bin, fake_codex_script())
            source_auth = source_home / "auth.json"
            source_auth.write_text(
                '{"token":"test-token-placeholder"}',
                encoding="utf-8",
            )
            (source_home / "config.toml").write_text(
                'cli_auth_credentials_store = "file"\n',
                encoding="utf-8",
            )
            launcher_dir = root / "launcher-bin"
            launcher_dir.mkdir()
            launcher = write_executable(
                launcher_dir / "codex",
                r'''#!/usr/bin/env python3
import os
from pathlib import Path
import sys

target = Path(os.environ["CODEX_HOME"]) / "packages" / "standalone" / "current" / "bin" / "codex"
if not target.is_file():
    print("codex: official standalone CLI is missing", file=sys.stderr)
    raise SystemExit(127)
os.execv(target, [str(target), *sys.argv[1:]])
''',
            )
            env = os.environ.copy()
            env.update(
                {
                    # Select this PATH fixture even when the caller pins CODEX_BIN.
                    "CODEX_BIN": "codex",
                    "CODEX_HOME": str(source_home),
                    "PATH": f"{launcher_dir}{os.pathsep}{env['PATH']}",
                }
            )

            caller_probe = subprocess.run(
                [str(launcher), "--version"],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )
            self.assertEqual(caller_probe.returncode, 0, caller_probe.stderr)

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertRegex(result.stdout, r"engine check: codex[^\n]* UNAVAILABLE")
            self.assertIn(str(launcher), result.stdout)
            self.assertIn("--codex-bin", result.stdout)
            self.assertIn("CODEX_BIN", result.stdout)
            self.assertIn("correct PATH", result.stdout)

            invocations = root / "codex-invocations.jsonl"
            env["AUTOREVIEW_FAKE_CODEX_INVOCATIONS"] = str(invocations)
            normal_run = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(
                normal_run.returncode,
                1,
                normal_run.stdout + normal_run.stderr,
            )
            self.assertIn("Codex isolation preflight failed", normal_run.stderr)
            self.assertIn(str(launcher), normal_run.stderr)
            self.assertIn("--codex-bin", normal_run.stderr)
            self.assertFalse(invocations.exists())

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_codex_probe_matches_run_environment_without_mutating_auth(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            (root / "direct-bin").mkdir()
            direct_bin = write_executable(
                root / "direct-bin" / "codex",
                fake_codex_script(),
            )
            source_home = root / "source-codex-home"
            source_home.mkdir()
            source_auth = source_home / "auth.json"
            source_auth.write_text(
                '{"token":"test-token-placeholder"}',
                encoding="utf-8",
            )
            (source_home / "config.toml").write_text(
                'cli_auth_credentials_store = "file"\n',
                encoding="utf-8",
            )
            invocations = root / "codex-invocations.jsonl"
            record = root / "codex-record.json"
            env = os.environ.copy()
            env.update(
                {
                    "AUTOREVIEW_FAKE_CODEX_INVOCATIONS": str(invocations),
                    "AUTOREVIEW_FAKE_RECORD": str(record),
                    "CODEX_HOME": str(source_home),
                }
            )
            auth_before = source_auth.read_bytes()
            links_before = source_auth.stat().st_nlink

            dry_run = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(direct_bin),
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(dry_run.returncode, 0, dry_run.stdout + dry_run.stderr)
            self.assertRegex(dry_run.stdout, r"engine check: codex[^\n]* OK\b")
            self.assertEqual(source_auth.read_bytes(), auth_before)
            self.assertEqual(source_auth.stat().st_nlink, links_before)
            probe_invocations = [
                json.loads(line)
                for line in invocations.read_text(encoding="utf-8").splitlines()
            ]
            self.assertEqual(
                [entry["argv"] for entry in probe_invocations],
                [["--version"]],
            )

            invocations.unlink()
            review = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(direct_bin),
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(review.returncode, 0, review.stdout + review.stderr)
            run_invocations = [
                json.loads(line)
                for line in invocations.read_text(encoding="utf-8").splitlines()
            ]
            self.assertEqual(len(run_invocations), 2)
            self.assertEqual(run_invocations[0]["argv"], ["--version"])
            self.assertIn("exec", run_invocations[1]["argv"])

            def normalized_runtime_env(invocation: dict[str, object]) -> dict[str, str]:
                selected = invocation["env"]
                assert isinstance(selected, dict)
                home = Path(str(selected["HOME"]))
                runtime_root = home.parent
                normalized = {
                    key: str(Path(str(selected[key])).relative_to(runtime_root))
                    for key in (
                        "HOME",
                        "USERPROFILE",
                        "XDG_CACHE_HOME",
                        "XDG_CONFIG_HOME",
                        "XDG_DATA_HOME",
                        "XDG_STATE_HOME",
                        "CODEX_HOME",
                    )
                }
                normalized["PATH"] = str(selected["PATH"])
                return normalized

            self.assertEqual(
                normalized_runtime_env(probe_invocations[0]),
                normalized_runtime_env(run_invocations[0]),
            )
            self.assertEqual(
                normalized_runtime_env(run_invocations[0]),
                normalized_runtime_env(run_invocations[1]),
            )

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_zero_when_bundle_and_engine_resolve(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            codex_bin = write_executable(
                root / "codex",
                fake_codex_script(),
            )
            env = {**os.environ, "CODEX_HOME": str(root)}

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(codex_bin),
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("bundle: constructible", result.stdout)
            self.assertIn("inputs: OK", result.stdout)
            self.assertIn("prompt: OK", result.stdout)
            self.assertIn("OK", result.stdout)

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_rejects_temporary_root_inside_repo(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            codex_bin = write_executable(
                root / "codex",
                fake_codex_script(),
            )
            env = os.environ.copy()
            repo_temp = repo / "tmp"
            repo_temp.mkdir()
            env.update(
                {
                    "TMPDIR": str(repo_temp),
                    "TEMP": str(repo_temp),
                    "TMP": str(repo_temp),
                }
            )

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(codex_bin),
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn("prompt: OK", result.stdout)
            self.assertIn("must be outside the reviewed repository", result.stdout)
            self.assertRegex(
                result.stdout,
                r"engine check: codex[^\n]* UNAVAILABLE",
            )

    def test_dry_run_flag_exits_nonzero_when_codex_no_tools(self) -> None:
        # run_codex() unconditionally refuses --no-tools; --dry-run must
        # not report codex available just because its binary resolves.
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--no-tools",
                    "--dry-run",
                ],
                cwd=repo,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn("UNAVAILABLE", result.stdout)
            self.assertIn("--no-tools", result.stdout)

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_nonzero_when_engine_binary_missing(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "claude",
                    "--claude-bin",
                    "definitely-not-a-real-claude-binary",
                    "--dry-run",
                ],
                cwd=repo,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn("UNAVAILABLE", result.stdout)

    def test_dry_run_flag_exits_nonzero_when_bundle_construction_fails(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "commit",
                    "--commit",
                    "no-such-ref-xyz",
                    "--dry-run",
                ],
                cwd=repo,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn("bundle: FAILED", result.stdout)

    def test_dry_run_commit_mode_passes_commit_ref_to_prompt_construction(self) -> None:
        # Both paths must retain the commit label in the assembled prompt,
        # including its bytes in the aggregate prompt budget.
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            (repo / "source.txt").write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            git(repo, "commit", "-q", "-m", "seed")
            commit = git(repo, "rev-parse", "HEAD").strip()

            preflight = self.helper["dry_run_preflight"]
            original = preflight.__globals__["build_review_prompts"]
            captured: dict[str, object] = {}

            def capturing(repo_arg, target, target_ref, *rest, **kwargs):
                captured["target_ref"] = target_ref
                return original(repo_arg, target, target_ref, *rest, **kwargs)

            args = argparse.Namespace(
                commit=commit,
                prompt=[],
                prompt_file=[],
                dataset=[],
                max_prompt_bytes=self.helper["MAX_REVIEW_PROMPT_BYTES"],
                max_priority="P0",
            )
            stdout = io.StringIO()
            with mock.patch.dict(
                preflight.__globals__,
                {
                    "build_review_prompts": capturing,
                },
            ):
                with contextlib.redirect_stdout(stdout):
                    preflight(args, [], repo, "commit", None)

            self.assertEqual(captured.get("target_ref"), commit)
            self.assertIn("prompt: OK", stdout.getvalue())

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_zero_for_plain_commit_mode(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            git(repo, "commit", "-q", "-m", "seed")
            codex_bin = write_executable(
                root / "codex",
                fake_codex_script(),
            )
            env = {**os.environ, "CODEX_HOME": str(root)}

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "commit",
                    "--commit",
                    "HEAD",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(codex_bin),
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("bundle: constructible", result.stdout)
            self.assertIn("prompt: OK", result.stdout)

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_nonzero_when_pi_version_unsupported(self) -> None:
        # run_pi() calls ensure_pi_isolation_supported(), which requires
        # Pi >= 0.79.0 for --no-approve trust isolation before the CLI is
        # ever invoked for a review; --dry-run must reuse that same local
        # --version probe rather than reporting pi available just because
        # the binary resolves on PATH.
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            pi_bin = write_executable(
                root / "pi",
                fake_pi_script(),
            )
            env = os.environ.copy()
            env["AUTOREVIEW_FAKE_PI_VERSION"] = "0.50.0"

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "pi",
                    "--pi-bin",
                    str(pi_bin),
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertRegex(result.stdout, r"engine check: pi[^\n]* UNAVAILABLE")
            self.assertIn("0.79.0", result.stdout)

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_zero_when_pi_version_supported(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            pi_bin = write_executable(
                root / "pi",
                fake_pi_script(),
            )
            env = os.environ.copy()

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "pi",
                    "--pi-bin",
                    str(pi_bin),
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertRegex(result.stdout, r"engine check: pi[^\n]* OK\b")

    def test_dry_run_flag_exits_nonzero_when_claude_tool_not_read_only(self) -> None:
        # run_claude() computes its --tools inventory via
        # claude_allowed_tools()/claude_tool_inventory() before the CLI is
        # ever invoked for a review, and that raises when a configured
        # --claude-allowed-tools rule is not one of the read-only tools
        # (see claude_tool_inventory); --dry-run must reuse that same
        # pure, non-mutating computation rather than reporting claude
        # available just because the CLI binary, version, and isolation
        # flags resolved.
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            claude_bin = write_executable(
                root / "claude",
                fake_claude_script(),
            )
            env = os.environ.copy()

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "claude",
                    "--claude-bin",
                    str(claude_bin),
                    "--claude-allowed-tools",
                    "Bash",
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertRegex(result.stdout, r"engine check: claude[^\n]* UNAVAILABLE")
            self.assertIn("Claude review tool is not read-only: Bash", result.stdout)
            self.assertIn("prompt: OK", result.stdout)

    def test_dry_run_flag_exits_nonzero_when_prompt_unpartitionable(self) -> None:
        # Instructions remain whole in each pass. Dry-run must enforce the
        # per-pass prompt budget just like a real review.
        with self.preparation_fixture(
            "--engine", "pi", "--dry-run", "--prompt-file", "evidence/big-prompt.md",
        ) as (repo, sends, stdout, _stderr):
            (repo / "evidence/big-prompt.md").write_text("context line filler text here\n" * 20_000)
            self.assertEqual(self.helper["main_impl"](), 1)
            self.assertFalse(sends)
            self.assertIn("prompt: FAILED", stdout.getvalue())
            self.assertIn("too little room", stdout.getvalue())
            # The bundle, inputs, and engine still resolve; only the
            # assembled-prompt aggregate check fails.
            self.assertIn("bundle: constructible", stdout.getvalue())
            self.assertIn("inputs: OK", stdout.getvalue())
            self.assertRegex(stdout.getvalue(), r"engine check: pi[^\n]* OK\b")

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_nonzero_when_prompt_file_missing(self) -> None:
        # The real run loads --prompt-file via capture_evidence_inputs() before
        # ever contacting an engine (see main_impl just after
        # dry_run_preflight returns); --dry-run must reuse that same
        # validation instead of reporting readiness for an input that
        # would fail before an engine starts.
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            codex_bin = write_executable(
                root / "codex",
                fake_codex_script(),
            )
            env = {**os.environ, "CODEX_HOME": str(root)}

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(codex_bin),
                    "--prompt-file",
                    "missing.md",
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn("inputs: FAILED", result.stdout)
            self.assertIn("missing.md", result.stdout)
            # The bundle and engine still resolve; only the input fails.
            self.assertIn("bundle: constructible", result.stdout)
            self.assertRegex(result.stdout, r"engine check: codex[^\n]* OK\b")

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_zero_when_prompt_file_valid(self) -> None:
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            prompt_file = repo / "prompt.md"
            prompt_file.write_text("Focus on error handling.\n", encoding="utf-8")
            codex_bin = write_executable(
                root / "codex",
                fake_codex_script(),
            )
            env = {**os.environ, "CODEX_HOME": str(root)}

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(codex_bin),
                    "--prompt-file",
                    "prompt.md",
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertIn("inputs: OK", result.stdout)

    @unittest.skipIf(os.name == "nt", "the fake executable is POSIX-only")
    def test_dry_run_flag_exits_nonzero_when_dataset_missing(self) -> None:
        # Both evidence roles use capture_evidence_inputs(); confirm datasets
        # get the same pre-engine existence check as prompt files.
        with tempfile.TemporaryDirectory() as tempdir:
            root = Path(tempdir)
            repo = init_repo(root)
            source = repo / "source.txt"
            source.write_text("staged\n", encoding="utf-8")
            git(repo, "add", "source.txt")
            codex_bin = write_executable(
                root / "codex",
                fake_codex_script(),
            )
            env = os.environ.copy()

            result = subprocess.run(
                [
                    sys.executable,
                    str(SCRIPT),
                    "--mode",
                    "local",
                    "--engine",
                    "codex",
                    "--codex-bin",
                    str(codex_bin),
                    "--dataset",
                    "missing-dataset.json",
                    "--dry-run",
                ],
                cwd=repo,
                env=env,
                text=True,
                capture_output=True,
                check=False,
            )

            self.assertEqual(result.returncode, 1, result.stdout + result.stderr)
            self.assertIn("inputs: FAILED", result.stdout)
            self.assertIn("missing-dataset.json", result.stdout)

PROXY_KEYS = ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy")


class AuthenticatedProxyTests(unittest.TestCase):
    def setUp(self):
        self.helper = load_helper()

    def test_authenticated_proxy_urls_are_transport_not_openclaw_provenance(self):
        for value in (
            "http://user:password@proxy.example.invalid:8080",
            "https://user:password@[::1]:8443/",
            "socks5h://u:p%40ss%3Aword@proxy.example.invalid:1080",
            "user:password@proxy.example.invalid:8080",
            "http://user@proxy.example.invalid",
            "http://:password@proxy.example.invalid",
            "http://proxy.example.invalid:8080",
            "proxy.example.invalid:8080",
            "socks4a://proxy.example.invalid",
        ):
            with self.subTest(value=value):
                self.assertTrue(self.helper["safe_proxy_url"](value))

    def test_malformed_proxy_urls_still_fail_closed(self):
        for value in (
            "", "http://", "file:///proxy", "http://host:0", "http://host:65536",
            "http://host:bad", "http://[::1", "http://host/path", "http://host?q=1",
            "http://host#fragment", " http://host", "http://host\n", "http://ho\tst",
            "http://user:p%0Ass@host", "http://user:p%00ss@host", "http://user:p%zz@host",
            "http://user:p@ss@host", "http://user:p\\ass@host", "http://ho st",
            "http://host%0a.example", "http://host%2f.example",
        ):
            with self.subTest(value=value):
                self.assertFalse(self.helper["safe_proxy_url"](value))

    def test_engine_env_preserves_authenticated_transport_without_marker_or_api_leak(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            repo = root / "repo"
            repo.mkdir()
            proxy = "http://fixture:transport-password@127.0.0.1:8080"
            transport = {key: proxy for key in PROXY_KEYS}
            transport.update({"NO_PROXY": "localhost", "NODE_USE_ENV_PROXY": "1"})
            ca_keys = ("NODE_EXTRA_CA_CERTS", "SSL_CERT_FILE", "SSL_CERT_DIR",
                       "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE")
            transport.update({key: str(root / "trust.pem") for key in ca_keys})
            inherited = {**transport, "OPENAI_API_KEY": "provider-auth-fixture",
                         "UNRELATED_SECRET": "not-for-review", "NODE_OPTIONS": "--require hostile"}
            for engine in self.helper["ENGINES"]:
                with self.subTest(engine=engine), mock.patch.dict(os.environ, inherited, clear=True):
                    env = self.helper["safe_engine_env"](repo, engine=engine)
                    for key, value in transport.items():
                        # Windows os.environ canonicalizes names to uppercase;
                        # POSIX must retain each supplied casing independently.
                        lookup_key = key.upper() if os.name == "nt" else key
                        self.assertEqual(env.get(lookup_key), value, key)
                    self.assertNotIn("UNRELATED_SECRET", env)
                    self.assertNotIn("NODE_OPTIONS", env)
                    if engine == "codex":
                        self.assertEqual(env["OPENAI_API_KEY"], "provider-auth-fixture")
                    elif engine in {"claude", "amp"}:
                        self.assertNotIn("OPENAI_API_KEY", env)

    def test_repository_ca_paths_are_not_inherited(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            repo = root / "repo"
            repo.mkdir()
            certificate = repo / "trust.pem"
            certificate.touch()
            external_link = root / "trust-link.pem"
            for path in (certificate, external_link):
                with self.subTest(path=path.name):
                    if path == external_link:
                        try:
                            external_link.symlink_to(certificate)
                        except OSError as exc:
                            if getattr(exc, "winerror", None) != 1314:  # ERROR_PRIVILEGE_NOT_HELD
                                raise
                            self.skipTest("Windows symlink privilege is unavailable")
                    for engine in self.helper["ENGINES"]:
                        with self.subTest(engine=engine), mock.patch.dict(os.environ, {
                            key: str(path) for key in ("NODE_EXTRA_CA_CERTS", "SSL_CERT_FILE", "SSL_CERT_DIR",
                                                      "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE")
                        }, clear=True):
                            env = self.helper["safe_engine_env"](repo, engine=engine)
                            for key in ("NODE_EXTRA_CA_CERTS", "SSL_CERT_FILE", "SSL_CERT_DIR",
                                        "CURL_CA_BUNDLE", "REQUESTS_CA_BUNDLE"):
                                self.assertNotIn(key, env)

    def proxy_fixture(self):
        username = "u"
        password = 'synthetic-p@ss:/+%"\\word'
        userinfo = f"{username}:{password}"
        encoded = urllib.parse.quote(password, safe="")
        proxy = f"http://{username}:{encoded}@127.0.0.1:8080"
        basic = base64.b64encode(userinfo.encode()).decode()
        forms = (proxy, userinfo, f"{username}:{encoded}", password, encoded,
                 "Proxy-Authorization: Basic " + basic)
        return proxy, forms

    def test_proxy_credentials_are_redacted_in_diagnostics_not_short_user_labels(self):
        proxy, forms = self.proxy_fixture()
        with mock.patch.dict(os.environ, {"HTTPS_PROXY": proxy}, clear=True):
            for form in (*forms, *(json.dumps(form)[1:-1] for form in forms)):
                with self.subTest(form=form):
                    rendered = self.helper["display_escape"]("failure: " + form, 4000, multiline=True)
                    self.assertNotIn(form, rendered)
                    self.assertIn("[REDACTED]", rendered)
            self.assertEqual(self.helper["display_escape"]("user u requests an update", 100),
                             "user u requests an update")
            for display in (self.helper["CodexStreamDisplay"](), self.helper["ClaudeStreamDisplay"]()):
                self.assertNotIn(forms[0], display("stderr", "failure: " + forms[0]))

    def test_real_stream_and_buffered_failure_keep_exit_semantics_without_disclosure(self):
        proxy, forms = self.proxy_fixture()
        source = "import os,sys; print(os.environ['HTTPS_PROXY']); print(os.environ['HTTPS_PROXY'],file=sys.stderr); sys.exit(7)"
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(os.environ, {"HTTPS_PROXY": proxy}, clear=False):
            stdout, stderr = io.StringIO(), io.StringIO()
            with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
                result = self.helper["run_with_heartbeat"](
                    [sys.executable, "-c", source], Path(tmp), label="proxy-test", stream_output=True,
                    env={"HTTPS_PROXY": proxy},
                )
            self.assertEqual(result.returncode, 7)
            self.assertNotIn(proxy, stdout.getvalue() + stderr.getvalue())
            failure = self.helper["ReviewerUnavailable"]("failed (7): " + result.stderr, result=result)
            with mock.patch.dict(self.helper["sanitized_main"].__globals__, {
                "main": mock.Mock(side_effect=failure),
            }):
                with self.assertRaises(SystemExit) as caught:
                    self.helper["sanitized_main"]()
            self.assertNotIn(proxy, str(caught.exception))
            self.assertIn("failed (7)", str(caught.exception))
            self.assertEqual(failure.returncode, 7)

    def test_report_files_and_terminal_are_redacted_without_changing_verdict(self):
        proxy, forms = self.proxy_fixture()
        report = {"findings": [], "overall_correctness": "patch is incorrect",
                  "overall_explanation": "provider says " + " | ".join(forms), "overall_confidence": 0.8}
        report["review_status"] = self.helper["review_status"](report, complete=True)
        with tempfile.TemporaryDirectory() as tmp, mock.patch.dict(os.environ, {"HTTPS_PROXY": proxy}, clear=True):
            output = Path(tmp) / "report.json"
            self.helper["atomic_write_text"](output, json.dumps(self.helper["redact_proxy_report"](report)))
            saved = json.loads(output.read_text())
            terminal = io.StringIO()
            with contextlib.redirect_stdout(terminal):
                self.helper["print_report"](report)
            for form in forms:
                self.assertNotIn(form, saved["overall_explanation"])
                self.assertNotIn(form, terminal.getvalue())
            self.assertEqual(saved["overall_correctness"], "patch is incorrect")
            self.assertEqual(saved["findings"], [])
            self.assertEqual(report["overall_explanation"], "provider says " + " | ".join(forms))

    def test_codex_tools_do_not_inherit_transport_or_authentication(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            flags = self.helper["codex_config_isolation_flags"](root / "repo", root / "runtime")
            self.assertIn('shell_environment_policy.inherit="core"', flags)
            self.assertIn("shell_environment_policy.ignore_default_excludes=false", flags)
            self.assertFalse(set(PROXY_KEYS) & self.helper["codex_tool_git_env"]().keys())

    @unittest.skipIf(os.name == "nt", "POSIX executable fixture")
    def test_cli_preserves_transport_and_redacts_streams_reports_and_failures(self):
        proxy, forms = self.proxy_fixture()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            repo = root / "repo"
            repo.mkdir()
            git(repo, "init", "-q")
            (repo / "source.txt").write_text("before\n")
            git(repo, "add", ".")
            git(repo, "commit", "-qm", "fixture")
            (repo / "source.txt").write_text("after\n")
            fake = root / "codex-fixture"
            fake.write_text(f"#!{sys.executable}\n" + '''import json, os, sys
from pathlib import Path
if "--version" in sys.argv:
    print("codex-cli 0.0.0-test")
    raise SystemExit(0)
Path(os.environ["AUTOREVIEW_FAKE_PROXY_RECORD"]).write_text(json.dumps({
    "proxy": os.environ["HTTPS_PROXY"], "auth": os.environ.get("OPENAI_API_KEY"), "argv": sys.argv,
}))
print(os.environ["HTTPS_PROXY"])
print(os.environ["HTTPS_PROXY"], file=sys.stderr)
if os.environ.get("AUTOREVIEW_FAKE_PROXY_EXIT"):
    raise SystemExit(7)
flag = "--output-last-message" if "--output-last-message" in sys.argv else "-o"
Path(sys.argv[sys.argv.index(flag) + 1]).write_text(json.dumps({
    "findings": [], "overall_correctness": "patch is incorrect",
    "overall_explanation": "transport diagnostics: " + os.environ["HTTPS_PROXY"], "overall_confidence": 0.8,
    "review_completion": "complete",
}))
''')
            fake.chmod(0o755)
            home = root / "home"
            home.mkdir()
            record = root / "record.json"
            human, report, status = (root / name for name in ("report.txt", "report.json", "status.json"))
            env = {key: value for key, value in os.environ.items() if key in {"PATH", "TMPDIR", "TEMP", "TMP"}}
            env.update({"HOME": str(home), "HTTPS_PROXY": proxy, "OPENAI_API_KEY": "opaque-provider-fixture",
                        "AUTOREVIEW_FAKE_PROXY_RECORD": str(record)})
            command = [sys.executable, str(SCRIPT), "--mode", "local", "--codex-bin", str(fake),
                       "--output", str(human), "--json-output", str(report), "--status-output", str(status),
                       "--stream-engine-output"]
            result = subprocess.run(command, cwd=repo, env=env, capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertTrue(report.exists(), result.stdout + result.stderr)
            saved = json.loads(report.read_text())
            self.assertEqual(saved["overall_correctness"], "patch is incorrect")
            captured = json.loads(record.read_text())
            self.assertEqual(captured["proxy"], proxy)
            self.assertEqual(captured["auth"], "opaque-provider-fixture")
            self.assertIn('shell_environment_policy.inherit="core"', captured["argv"])
            published = result.stdout + result.stderr + human.read_text() + report.read_text()
            for form in forms:
                self.assertNotIn(form, published)
            self.assertEqual(json.loads(status.read_text())["exit_code"], result.returncode)
            env["AUTOREVIEW_FAKE_PROXY_EXIT"] = "1"
            failed = subprocess.run(command, cwd=repo, env=env, capture_output=True, text=True)
            self.assertNotEqual(failed.returncode, 0)
            self.assertNotIn(proxy, failed.stdout + failed.stderr)
            self.assertEqual(json.loads(status.read_text())["reviewer_exit_code"], 7)

    def test_serialized_redaction_does_not_turn_short_passwords_into_json_syntax(self):
        with mock.patch.dict(os.environ, {"HTTPS_PROXY": "http://u:1@localhost:8080"}, clear=True):
            report = {"code": 1, "accepted": True, "explanation": "password=1", "u": "user u"}
            saved = json.loads(json.dumps(self.helper["redact_proxy_report"](report)))
            self.assertEqual(saved["code"], 1)
            self.assertIs(saved["accepted"], True)
            self.assertEqual(saved["explanation"], "[REDACTED]")
            self.assertEqual(saved["u"], "user u")

    def test_short_password_does_not_corrupt_prose_or_serialized_enums(self):
        for password in ("a", "incorrect"):
            with self.subTest(password=password), mock.patch.dict(os.environ, {
                "HTTPS_PROXY": f"http://u:{password}@localhost:8080",
            }, clear=True):
                report = {"overall_correctness": "patch is incorrect", "review_status": "incomplete",
                          "overall_explanation": "a branch has a bug", "findings": [{
                              "priority": "P1", "category": "regression", "body": "password=" + password,
                          }]}
                saved = self.helper["redact_proxy_report"](report)
                self.assertEqual(saved["overall_correctness"], "patch is incorrect")
                self.assertEqual(saved["review_status"], "incomplete")
                self.assertEqual(saved["overall_explanation"], "a branch has a bug")
                self.assertEqual(saved["findings"][0]["priority"], "P1")
                self.assertEqual(saved["findings"][0]["category"], "regression")
                self.assertNotIn("password=" + password, saved["findings"][0]["body"])

    def test_username_only_and_empty_password_are_hidden_in_url_contexts(self):
        for suffix in ("", ":"):
            with self.subTest(suffix=suffix), mock.patch.dict(os.environ, {
                "HTTPS_PROXY": f"http://u%40name{suffix}@localhost:8080",
            }, clear=True):
                diagnostic = f"proxy=http://u@name{suffix}@LOCALHOST:8080/; user u@name is configured"
                redacted = self.helper["redact_proxy_credentials"](diagnostic)
                self.assertNotIn(f"u@name{suffix}@", redacted)
                self.assertIn("user u@name is configured", redacted)

    def test_long_username_only_tokens_are_redacted_outside_url_contexts(self):
        token = 'synthetic-user-token@/+"\\value'
        encoded = urllib.parse.quote(token, safe="")
        forms = (token, encoded, urllib.parse.quote(encoded, safe=""),
                 json.dumps(token)[1:-1])
        for suffix in ("", ":"):
            with self.subTest(suffix=suffix), mock.patch.dict(os.environ, {
                "HTTPS_PROXY": f"http://{encoded}{suffix}@localhost:8080",
            }, clear=True):
                for form in forms:
                    with self.subTest(form=form):
                        rendered = self.helper["display_escape"]("rejected credential " + form, 4000)
                        self.assertNotIn(form, rendered)
                        self.assertIn("[REDACTED]", rendered)
                        report = {"overall_correctness": "patch is incorrect",
                                  "overall_explanation": "rejected credential " + form}
                        saved = self.helper["redact_proxy_report"](report)
                        self.assertNotIn(form, saved["overall_explanation"])
                        self.assertEqual(saved["overall_correctness"], "patch is incorrect")

    def test_username_only_redaction_preserves_short_labels_and_report_enums(self):
        for username in ("u", "openclaw", "review-bot", "incorrect"):
            for suffix in ("", ":"):
                with self.subTest(username=username, suffix=suffix), mock.patch.dict(os.environ, {
                    "HTTPS_PROXY": f"http://{username}{suffix}@localhost:8080",
                }, clear=True):
                    prose = f"user {username} is configured"
                    self.assertEqual(self.helper["redact_proxy_credentials"](prose), prose)
                    for label in ("username", "proxy_user", "proxy-username"):
                        diagnostic = f'{label}="{username}"'
                        redacted = self.helper["redact_proxy_credentials"](diagnostic)
                        self.assertNotIn(diagnostic, redacted)
                        self.assertIn("[REDACTED]", redacted)
                    report = {"overall_correctness": "patch is incorrect",
                              "review_status": "incomplete", "overall_explanation": prose,
                              "findings": [{"priority": "P1", "category": "regression"}]}
                    self.assertEqual(self.helper["redact_proxy_report"](report), report)

    def test_output_redaction_covers_split_writes_and_final_unterminated_line(self):
        proxy, _forms = self.proxy_fixture()
        stream = io.StringIO()
        with mock.patch.dict(os.environ, {"HTTPS_PROXY": proxy}, clear=True):
            output = self.helper["ProxyRedactedOutput"](stream)
            for char in proxy:
                output.write(char)
                output.flush()
            self.assertEqual(stream.getvalue(), "")
            output.write("\n")
            self.assertEqual(stream.getvalue(), "[REDACTED]\n")
            output.write(proxy)
            output.finish()
            self.assertEqual(stream.getvalue(), "[REDACTED]\n[REDACTED]")

    def test_redacting_output_bounds_unterminated_lines_and_retains_stream_interface(self):
        proxy, _forms = self.proxy_fixture()
        stream = io.StringIO()
        with mock.patch.dict(os.environ, {"HTTPS_PROXY": proxy}, clear=True):
            output = self.helper["ProxyRedactedOutput"](stream)
            output.write("x" * 65_537 + proxy)
            self.assertLessEqual(len(output.pending), 65_536)
            output.write("still the suppressed line\nnext line\n")
            output.finish()
            self.assertEqual(stream.getvalue(),
                             "[output line suppressed: exceeds redaction buffer]\nnext line\n")
            self.assertFalse(output.isatty())
            self.assertEqual(output.encoding, stream.encoding)
            with self.assertRaises(io.UnsupportedOperation):
                output.fileno()


if __name__ == "__main__":
    unittest.main()
